#!/usr/bin/env bash
python services/ledger_service.py &
sleep 0.5
python services/user_service.py &
sleep 0.5
python services/wallet_service.py &
sleep 0.5
python services/c2d_executor.py &
sleep 0.5
python services/marketplace_api.py &
echo "Services started. Visit http://localhost:8009/docs"
wait
