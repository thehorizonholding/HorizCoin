from fastapi import FastAPI
app = FastAPI(title='c2d_executor')
@app.get('/ping') 
def ping(): return {'service':'c2d','status':'ok'}
if __name__=='__main__':
    import uvicorn
    uvicorn.run(app, host='0.0.0.0', port=8011)
