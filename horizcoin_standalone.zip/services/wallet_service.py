from fastapi import FastAPI
app = FastAPI(title='wallet_service')
@app.get('/ping') 
def ping(): return {'service':'wallet','status':'ok'}
if __name__=='__main__':
    import uvicorn
    uvicorn.run(app, host='0.0.0.0', port=8002)
