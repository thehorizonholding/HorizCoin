from fastapi import FastAPI
app = FastAPI(title='marketplace_api')
@app.get('/docs_redirect')
def docs_redirect():
    return {'message':'use /docs on each service'}
@app.get('/ping') 
def ping(): return {'service':'marketplace','status':'ok'}
if __name__=='__main__':
    import uvicorn
    uvicorn.run(app, host='0.0.0.0', port=8009)
