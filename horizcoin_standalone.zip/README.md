# HorizCoin — Standalone Local Bundle (macOS)

This bundle contains a minimal local-only development environment for HorizCoin.

Services (FastAPI):
- user_service (port 8001)
- wallet_service (port 8002)
- ledger_service (port 8003)
- marketplace_api (port 8009)
- c2d_executor (port 8011)

Run locally (no Docker):
  python3 -m venv .venv
  source .venv/bin/activate
  pip install -r requirements.txt
  # open 5 terminals or use the provided script:
  bash scripts/start_local.sh

The system is intentionally self-contained and does NOT require external registrations.
