# Demo orchestration worker - filesystem queue
import os, json, time
from audit.auditor import audit_append
TASK_DIR = os.environ.get('TASK_DIR','./tasks')
os.makedirs(TASK_DIR, exist_ok=True)
print('Worker watching', TASK_DIR)
while True:
    for fn in os.listdir(TASK_DIR):
        if not fn.endswith('.json'): continue
        path = os.path.join(TASK_DIR, fn)
        try:
            task = json.load(open(path))
            audit_append({'action':'dispatch','task':task})
            print('Dispatched task', task)
            os.remove(path)
        except Exception as e:
            print('task failed', e)
    time.sleep(2)
