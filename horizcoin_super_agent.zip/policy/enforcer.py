def check(action, meta):
    if action=='monetize_network' and not meta.get('provider_contract'):
        print('policy reject')
        return False
    return True
