import sys, json, os
from audit.auditor import audit_append
def scaffold(repo='./demo_repo'):
    os.makedirs(repo, exist_ok=True)
    with open(os.path.join(repo,'app.py'),'w') as f: f.write('print("demo app")')
    audit_append({'action':'scaffold','repo':repo})
    print('scaffolded', repo)
if __name__=='__main__':
    t = json.load(open(sys.argv[1])) if len(sys.argv)>1 else {'repo':'./demo_repo'}
    scaffold(t.get('repo'))
