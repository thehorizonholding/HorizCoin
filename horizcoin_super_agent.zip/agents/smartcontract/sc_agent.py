import sys, json, os
from audit.auditor import audit_append
def create_stub(repo='./demo_repo'):
    cdir = os.path.join(repo,'contracts'); os.makedirs(cdir, exist_ok=True)
    with open(os.path.join(cdir,'DataNFT.sol'),'w') as f: f.write('// SPDX-License-Identifier: MIT\npragma solidity ^0.8.19;\ncontract DataNFT { uint public x; }')
    audit_append({'action':'create_contract','repo':repo})
    print('created stub')
if __name__=='__main__':
    t = json.load(open(sys.argv[1])) if len(sys.argv)>1 else {'repo':'./demo_repo'}
    create_stub(t.get('repo'))
