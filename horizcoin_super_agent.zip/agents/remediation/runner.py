import yaml, sys
from audit.auditor import audit_append
def run(pb):
    audit_append({'action':'run_playbook','playbook':pb.get('id')})
    for step in pb.get('steps',[]):
        print('DRY RUN step:', step.get('id'))
if __name__=='__main__':
    pb = yaml.safe_load(open(sys.argv[1])) if len(sys.argv)>1 else {'id':'demo','steps':[{'id':'s1'}]}
    run(pb)
