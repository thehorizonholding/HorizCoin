import os, json, hmac, hashlib
SECRET = os.environ.get('ORACLE_HMAC_SECRET','demo')
def sign(payload):
    raw = json.dumps(payload, sort_keys=True)
    sig = hmac.new(SECRET.encode(), raw.encode(), hashlib.sha256).hexdigest()
    print(json.dumps({'payload':payload,'sig':sig}))
if __name__=='__main__':
    sign({'dataset_id':1,'score':900})
