import sys, json
from audit.auditor import audit_append
def suggest(desc):
    audit_append({'action':'suggest_fix','desc':desc})
    print('Suggested patch: // fix for', desc)
if __name__=='__main__':
    d = sys.argv[1] if len(sys.argv)>1 else 'demo'
    suggest(d)
