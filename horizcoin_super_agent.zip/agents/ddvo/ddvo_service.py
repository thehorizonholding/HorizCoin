# DDVO mock: very small HTTP-less demo callable script
import sys, json
def score(meta):
    prov = meta.get('provenance_score',0.5)
    excl = meta.get('exclusivity',0)
    usage = min(meta.get('usage_count',0),1000)/1000.0
    recency = max(0,1 - (meta.get('recency_days',30)/365.0))
    comp = meta.get('compliance_score',0.5)
    s = int(max(0,min(1000,(prov*0.25+excl*0.2+usage*0.3+recency*0.15+comp*0.1)*1000)))
    print(json.dumps({'score':s}))
if __name__=='__main__':
    meta = json.load(open(sys.argv[1])) if len(sys.argv)>1 else {'provenance_score':0.8,'usage_count':100}
    score(meta)
