import hashlib, json, time, os
APPROVALS = {}
REQUIRED = int(os.environ.get('REQUIRED_APPROVALS','2'))
def request_approval(action, meta):
    token = hashlib.sha256(f"{action}|{json.dumps(meta)}|{time.time()}".encode()).hexdigest()
    APPROVALS[token] = {'action':action,'meta':meta,'approvals':[],'granted':False}
    print('approval token', token)
    return token
def approve(token, approver):
    if token not in APPROVALS: raise Exception('unknown')
    if approver in APPROVALS[token]['approvals']: return False
    APPROVALS[token]['approvals'].append(approver)
    if len(APPROVALS[token]['approvals']) >= REQUIRED:
        APPROVALS[token]['granted'] = True
        print('granted', token)
    return APPROVALS[token]['granted']
def verify(token):
    return bool(APPROVALS.get(token,{}).get('granted',False))
