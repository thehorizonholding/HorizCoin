# HorizCoin Ultra+Infinity
This is a minimal skeleton for GitHub.