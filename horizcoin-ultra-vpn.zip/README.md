# HorizCoin Ultra VPN Version
Placeholder README.