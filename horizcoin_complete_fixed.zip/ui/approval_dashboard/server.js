const express = require('express'); const app = express(); app.use(express.json());
const approvals = {};
app.post('/request', (req,res)=>{ const token = 'tok-'+Date.now(); approvals[token] = {granted:false, meta:req.body, approvals:[]}; res.json({token}); });
app.post('/approve', (req,res)=>{ const {token, approver} = req.body; if(!approvals[token]) return res.status(404).json({error:'unknown'}); approvals[token].approvals.push(approver); if(approvals[token].approvals.length >= (req.body.required || 2)) approvals[token].granted = true; res.json({ok:true}); });
app.get('/status/:token',(req,res)=>{ res.json(approvals[req.params.token]||{}); });
app.listen(4000, ()=>console.log('Approval server demo on 4000'));
