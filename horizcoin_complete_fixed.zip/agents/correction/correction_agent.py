# Simple correction agent scaffold (demo)
import sys, subprocess
from audit.auditor import audit_append

def reproduce(cmd):
    p = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    audit_append({'action':'reproduce','cmd':cmd,'rc':p.returncode})
    print(p.stdout)

if __name__=='__main__':
    reproduce(sys.argv[1] if len(sys.argv)>1 else 'echo demo')
