from flask import Flask, request, jsonify
app = Flask(__name__)
@app.route('/score', methods=['POST'])
def score():
    meta = request.json.get('meta', {})
    # simple deterministic scoring demo
    s = int((meta.get('provenance',0.5) + meta.get('exclusivity',0))*500)
    return jsonify({'score': s})
if __name__=='__main__':
    app.run(host='0.0.0.0', port=8300)
