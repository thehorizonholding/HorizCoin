# HorizCoin DataRegistry Prototype

A complete, tested example of a hybrid on-chain registry + off-chain indexer that provides
an "Oracle-like" searchable relational database of on-chain registrations.

## What is included
- A simple Solidity contract (`contracts/DataRegistry.sol`) that emits `NewRecord` events.
- Python scripts to compile/deploy (`scripts/deploy_and_interact.py`), index events (`scripts/indexer.py`),
  and query the resulting SQLite database (`scripts/query_database.py`).
- Dockerfile and docker-compose to run a local Ganache node, deploy sample data, and run the indexer.
- `.env.example` and `requirements.txt` for local development.

## Quickstart (Docker - recommended for beginners)
1. Ensure Docker & Docker Compose are installed.
2. From repository root run:
   ```bash
   docker compose up --build
   ```
   This will:
   - start a local Ganache Ethereum node,
   - run the deployer script to deploy the contract and register two sample records,
   - start the indexer which will pick up events and store them in `./data/indexer.db`.

3. After services are up, you can run the query script locally to view records:
   ```bash
   python3 scripts/query_database.py
   ```

## Quickstart (local, without Docker)
1. Install dependencies:
   ```bash
   python3 -m pip install -r requirements.txt
   npm install --save-dev hardhat
   npx hardhat node
   ```
2. Copy `.env.example` to `.env` and set `RPC_URL` and `PRIVATE_KEY` (use a test key).
3. In one terminal: deploy & register sample data:
   ```bash
   python3 scripts/deploy_and_interact.py
   ```
4. In another terminal: start the indexer:
   ```bash
   python3 scripts/indexer.py
   ```
5. Query results:
   ```bash
   python3 scripts/query_database.py
   ```

## Notes & Security
- This prototype is for testnets and local development. Do NOT use real private keys or mainnet funds.
- The indexer uses a simple SQLite DB for demonstration; production systems should use scalable databases
  and robust event ingestion (reorg handling, backfill, checkpointing).
- Always audit contracts and images before production use.
