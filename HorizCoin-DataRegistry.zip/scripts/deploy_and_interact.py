#!/usr/bin/env python3
import json
import os
import time
from web3 import Web3
from solcx import compile_source, install_solc
from dotenv import load_dotenv

load_dotenv()

RPC_URL = os.getenv("RPC_URL", "http://127.0.0.1:8545")
PRIVATE_KEY = os.getenv("PRIVATE_KEY")
CONTRACT_SOURCE_PATH = os.path.join("contracts", "DataRegistry.sol")
COMPILED_ARTIFACTS_PATH = "contract_artifacts.json"
DEPLOYED_ADDRESS_PATH = "contract_address.txt"

def compile_contract():
    print("Compiling contract...")
    install_solc('0.8.20')
    with open(CONTRACT_SOURCE_PATH, 'r') as f:
        source_code = f.read()
    compiled = compile_source(source_code, output_values=['abi', 'bin'])
    contract_id, contract_interface = compiled.popitem()
    artifacts = {'abi': contract_interface['abi'], 'bytecode': contract_interface['bin']}
    with open(COMPILED_ARTIFACTS_PATH, 'w') as f:
        json.dump(artifacts, f, indent=2)
    print("Contract compiled and artifacts written.")
    return artifacts

def deploy_contract(w3, artifacts):
    if not PRIVATE_KEY:
        raise SystemExit('PRIVATE_KEY environment variable required for deployment.')
    acct = w3.eth.account.from_key(PRIVATE_KEY)
    Contract = w3.eth.contract(abi=artifacts['abi'], bytecode=artifacts['bytecode'])
    construct_txn = Contract.constructor().build_transaction({
        'from': acct.address,
        'nonce': w3.eth.get_transaction_count(acct.address),
        'gas': 2000000,
        'gasPrice': w3.eth.gas_price
    })
    signed = acct.sign_transaction(construct_txn)
    tx_hash = w3.eth.send_raw_transaction(signed.rawTransaction)
    print(f"Deployment tx sent: {tx_hash.hex()} - waiting for receipt...")
    receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
    address = receipt.contractAddress
    print(f"Contract deployed at: {address}")
    with open(DEPLOYED_ADDRESS_PATH, 'w') as f:
        f.write(address)
    return address

def register_new_data(w3, contract_address, abi, data_hash):
    print(f"Registering data hash: {data_hash}")
    acct = w3.eth.account.from_key(PRIVATE_KEY)
    contract = w3.eth.contract(address=contract_address, abi=abi)
    txn = contract.functions.registerData(data_hash).build_transaction({
        'from': acct.address,
        'nonce': w3.eth.get_transaction_count(acct.address),
        'gas': 200000,
        'gasPrice': w3.eth.gas_price
    })
    signed = acct.sign_transaction(txn)
    tx_hash = w3.eth.send_raw_transaction(signed.rawTransaction)
    print(f"Sent register tx: {tx_hash.hex()}")
    receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
    print(f"Registration confirmed in block {receipt.blockNumber}")
    return receipt

def main():
    if not os.path.exists(CONTRACT_SOURCE_PATH):
        raise SystemExit(f"Contract source not found: {CONTRACT_SOURCE_PATH}")
    w3 = Web3(Web3.HTTPProvider(RPC_URL))
    if not w3.is_connected():
        raise SystemExit(f"Unable to connect to RPC at {RPC_URL}")
    print(f"Connected to RPC. Chain ID: {w3.eth.chain_id}")
    artifacts = None
    if not os.path.exists(COMPILED_ARTIFACTS_PATH):
        artifacts = compile_contract()
    else:
        with open(COMPILED_ARTIFACTS_PATH,'r') as f:
            artifacts = json.load(f)
    if not os.path.exists(DEPLOYED_ADDRESS_PATH):
        contract_address = deploy_contract(w3, artifacts)
    else:
        with open(DEPLOYED_ADDRESS_PATH,'r') as f:
            contract_address = f.read().strip()
        print(f"Using existing contract at {contract_address}")
    # Example registrations
    register_new_data(w3, contract_address, artifacts['abi'], "ipfs://QmXoypizjW3WknFiJnKLwHCnL72vedxjQkDDP1mXWo6uco")
    time.sleep(1)
    register_new_data(w3, contract_address, artifacts['abi'], "bafybeigdyrzt5sfp7udm7hu76uh7y26nf3efuylqabf3oclgtqy55fbzdi")

if __name__ == '__main__':
    main()
