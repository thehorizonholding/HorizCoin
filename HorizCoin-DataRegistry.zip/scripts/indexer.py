#!/usr/bin/env python3
import json
import os
import sqlite3
import time
from web3 import Web3
from dotenv import load_dotenv

load_dotenv()

RPC_URL = os.getenv('RPC_URL', 'http://127.0.0.1:8545')
COMPILED_ARTIFACTS_PATH = 'contract_artifacts.json'
DEPLOYED_ADDRESS_PATH = 'contract_address.txt'
DB_PATH = 'indexer.db'
POLL_INTERVAL = int(os.getenv('POLL_INTERVAL', '5'))

def setup_database():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS datarecords (
            record_id INTEGER PRIMARY KEY,
            owner_address TEXT NOT NULL,
            data_hash TEXT NOT NULL,
            block_timestamp INTEGER NOT NULL,
            tx_hash TEXT NOT NULL
        )
    ''')
    conn.commit()
    print('Database initialized at', DB_PATH)
    return conn

def handle_event(event, conn):
    cursor = conn.cursor()
    args = event['args']
    tx_hash = event['transactionHash'].hex()
    record_id = int(args['recordId'])
    owner = args['owner']
    data_hash = args['offChainDataHash']
    timestamp = int(args['timestamp'])
    print(f"  -> New event: ID={record_id} owner={owner} hash={data_hash} ts={timestamp}")
    try:
        cursor.execute(
            "INSERT INTO datarecords (record_id, owner_address, data_hash, block_timestamp, tx_hash) VALUES (?,?,?,?,?)",
            (record_id, owner, data_hash, timestamp, tx_hash)
        )
        conn.commit()
        print(f"     Inserted record {record_id}")
    except sqlite3.IntegrityError:
        print(f"     Record {record_id} already exists; skipping.")
    except Exception as e:
        print('     DB insert error:', e)

def main():
    if not os.path.exists(COMPILED_ARTIFACTS_PATH) or not os.path.exists(DEPLOYED_ADDRESS_PATH):
        raise SystemExit('ABI or deployed address missing. Run deploy_and_interact.py first.')
    w3 = Web3(Web3.HTTPProvider(RPC_URL))
    if not w3.is_connected():
        raise SystemExit('Cannot connect to RPC at ' + RPC_URL)
    with open(COMPILED_ARTIFACTS_PATH,'r') as f:
        abi = json.load(f)['abi']
    with open(DEPLOYED_ADDRESS_PATH,'r') as f:
        contract_address = f.read().strip()
    contract = w3.eth.contract(address=contract_address, abi=abi)
    conn = setup_database()
    event_filter = contract.events.NewRecord.create_filter(fromBlock='latest')
    print('Indexer listening for NewRecord events from', contract_address)
    try:
        while True:
            entries = event_filter.get_new_entries()
            if entries:
                for ev in entries:
                    handle_event(ev, conn)
            time.sleep(POLL_INTERVAL)
    except KeyboardInterrupt:
        print('Shutting down indexer.')
    finally:
        conn.close()

if __name__ == '__main__':
    main()
