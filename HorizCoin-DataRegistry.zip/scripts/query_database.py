#!/usr/bin/env python3
import sqlite3, os
DB_PATH = 'indexer.db'

def query_all_records():
    if not os.path.exists(DB_PATH):
        print('Database not found. Run indexer.py first.')
        return
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT record_id, owner_address, data_hash, datetime(block_timestamp, 'unixepoch') as ts FROM datarecords ORDER BY record_id")
    rows = cur.fetchall()
    if not rows:
        print('No records found.')
    else:
        for r in rows:
            print(f'ID: {r[0]} | Owner: {r[1]} | Hash: {r[2]} | Time: {r[3]}')
    conn.close()

def query_by_owner(owner):
    if not os.path.exists(DB_PATH):
        print('Database not found. Run indexer.py first.')
        return
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute('SELECT record_id, data_hash FROM datarecords WHERE owner_address=? ORDER BY record_id', (owner,))
    rows = cur.fetchall()
    if not rows:
        print('No records for owner', owner)
    else:
        for r in rows:
            print(f'  - Record ID: {r[0]} | Hash: {r[1]}')
    conn.close()

if __name__ == '__main__':
    query_all_records()
    # example owner (replace as needed)
    # query_by_owner('0x...')
