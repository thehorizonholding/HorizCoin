const hre = require("hardhat");

async function main() {
  const [deployer] = await hre.ethers.getSigners();
  console.log("Deploying from:", deployer.address);

  const HorizCoin = await hre.ethers.getContractFactory("HorizCoin");
  const hzc = await HorizCoin.deploy();
  await hzc.waitForDeployment();
  console.log("HZC:", await hzc.getAddress());

  const DataToken = await hre.ethers.getContractFactory("DataToken");
  const dt = await DataToken.deploy();
  await dt.waitForDeployment();
  console.log("DataToken:", await dt.getAddress());
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
