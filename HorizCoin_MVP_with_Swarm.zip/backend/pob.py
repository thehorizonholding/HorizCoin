import hashlib
import time
from typing import Dict, Any

def generate_challenge(difficulty: int, target_size: int) -> Dict[str, Any]:
    start = time.time()
    nonce = 0
    puzzle_data = b"horizcoin_pob_challenge"

    while True:
        data = puzzle_data + str(nonce).encode()
        hash_result = hashlib.sha256(data).hexdigest()
        if hash_result.startswith('0' * difficulty):
            proof_data = (str(nonce) * (target_size // len(str(nonce)) + 1)).encode()[:target_size]
            solve_time = time.time() - start
            return {
                "nonce": nonce,
                "hash": hash_result,
                "proof_blob": proof_data.hex(),
                "solve_time": solve_time,
                "proof_size": len(proof_data)
            }
        nonce += 1

def verify_proof(proof: Dict[str, Any], difficulty: int, target_size: int) -> bool:
    data = b"horizcoin_pob_challenge" + str(proof["nonce"]).encode()
    hash_result = hashlib.sha256(data).hexdigest()
    blob_bytes = bytes.fromhex(proof["proof_blob"])
    return hash_result.startswith('0' * difficulty) and len(blob_bytes) == target_size
