const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("HorizCoin", function () {
  it("Mints total supply", async function () {
    const HorizCoin = await ethers.getContractFactory("HorizCoin");
    const hzc = await HorizCoin.deploy();
    await hzc.waitForDeployment();
    expect(await hzc.totalSupply()).to.equal(ethers.parseEther("10000000000"));
  });
});
