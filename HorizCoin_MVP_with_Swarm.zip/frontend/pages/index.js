import { useState } from 'react';
import axios from 'axios';
import Marketplace from '../components/Marketplace';

export default function Home() {
  const [data, setData] = useState({ description: '', size: 1024, hash: 'QmExampleCID' });

  const handleValuate = async () => {
    try {
      const res = await axios.post('http://localhost:8000/valuate', data);
      alert(`Value: $${res.data.value_usd} (~${res.data.hzc_equiv} HZC)`);
    } catch (err) {
      alert(`Error: ${err.message}`);
    }
  };

  return (
    <div style={{ padding: '20px' }}>
      <h1>HorizCoin MVP</h1>
      <input placeholder="Description" onChange={(e) => setData({ ...data, description: e.target.value })} />
      <input type="number" placeholder="Size" value={data.size} onChange={(e) => setData({ ...data, size: parseInt(e.target.value) })} />
      <input placeholder="Hash" value={data.hash} onChange={(e) => setData({ ...data, hash: e.target.value })} />
      <button onClick={handleValuate}>Valuate</button>
      <Marketplace />
    </div>
  );
}
