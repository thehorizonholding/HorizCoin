# HorizCoin: Tokenizing Bandwidth and Data for the Decentralized Future

This repository contains the HorizCoin MVP and an optional HorizAI Swarm orchestrator to automate development and testing tasks.

## Swarm Quick Start
1. `pip install networkx`
2. `python horizai_swarm.py init`
3. `python horizai_swarm.py test-mvp` or `python horizai_swarm.py audit contracts/DataToken.sol`

## Quick Start (MVP)
1. Copy `.env.example` to `.env` and fill required values.
2. Install root deps: `npm init -y && npm i hardhat @nomicfoundation/hardhat-toolbox @openzeppelin/contracts ethers dotenv`
3. Backend: `pip install -r backend/requirements.txt`
4. Frontend: `cd frontend && npm i`
5. Compile & deploy (testnet): `npx hardhat compile && npx hardhat run scripts/deploy.js --network mumbai`
6. Run backend: `cd backend && uvicorn app:app --reload`
7. Run frontend: `cd frontend && npm run dev`
