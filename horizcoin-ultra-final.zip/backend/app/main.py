from fastapi import FastAPI
from .routers import jobs

app = FastAPI(title="HorizCoin Ultra Control-Center")

app.include_router(jobs.router, prefix="/jobs", tags=["jobs"])

@app.get("/")
def root():
    return {"status": "ok", "message": "HorizCoin Ultra Control-Center API"}
