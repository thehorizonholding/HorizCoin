from web3 import Web3
from eth_account import Account
from ..config import get_settings

settings = get_settings()
w3 = Web3(Web3.HTTPProvider(settings.rpc_url))

# Minimal ABI for JobSettlementContract.settleJob
JOB_SETTLEMENT_ABI = [
    {
        "inputs": [
            {"internalType": "bytes32", "name": "jobId", "type": "bytes32"},
            {"internalType": "address", "name": "client", "type": "address"},
            {"internalType": "address", "name": "provider", "type": "address"},
            {"internalType": "uint256", "name": "totalAmount", "type": "uint256"}
        ],
        "name": "settleJob",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    }
]

def settle_job_onchain(job_id: str, client: str, provider: str, total_amount_husd: float) -> None:
    settlement = w3.eth.contract(
        address=Web3.to_checksum_address(settings.job_settlement),
        abi=JOB_SETTLEMENT_ABI
    )
    private_key = settings.private_key
    acct = Account.from_key(private_key)

    # Assume 18 decimals for hUSD
    amount_wei = int(total_amount_husd * 10**18)
    job_id_bytes32 = job_id.encode().ljust(32, b"\0")

    tx = settlement.functions.settleJob(
        job_id_bytes32,
        Web3.to_checksum_address(client),
        Web3.to_checksum_address(provider),
        amount_wei
    ).build_transaction({
        "from": acct.address,
        "nonce": w3.eth.get_transaction_count(acct.address),
        "chainId": settings.chain_id,
        "gas": 500_000,
        "gasPrice": w3.eth.gas_price,
    })

    signed = w3.eth.account.sign_transaction(tx, private_key=private_key)
    tx_hash = w3.eth.send_raw_transaction(signed.rawTransaction)
    print(f"[Settlement] Sent tx: {tx_hash.hex()}")
