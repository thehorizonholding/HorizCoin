from ..config import get_settings
from pydantic import BaseModel

settings = get_settings()

# In real deployment, this would call a Ray Serve endpoint or similar.

class JobRequest(BaseModel):
    client_address: str
    job_type: str
    complexity: float
    deadline_sla: float

def get_price_and_cost(req: JobRequest) -> tuple[float, float]:
    # Placeholder heuristic until RL policies are wired:
    base_cost = 10.0 * req.complexity
    urgency_factor = 1.0 + max(0.0, 1.0 - req.deadline_sla)
    price = base_cost * (1.5 * urgency_factor)
    return price, base_cost
