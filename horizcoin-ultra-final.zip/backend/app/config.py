from pydantic import BaseModel
from functools import lru_cache
import os
from dotenv import load_dotenv

load_dotenv()

class Settings(BaseModel):
    rpc_url: str
    horc_token: str
    husd_token: str
    job_settlement: str
    flywheel: str
    private_key: str
    chain_id: int

@lru_cache
def get_settings() -> Settings:
    return Settings(
        rpc_url=os.getenv("RPC_URL", ""),
        horc_token=os.getenv("HORC_TOKEN_ADDRESS", ""),
        husd_token=os.getenv("HUSD_TOKEN_ADDRESS", ""),
        job_settlement=os.getenv("JOB_SETTLEMENT_ADDRESS", ""),
        flywheel=os.getenv("FLYWHEEL_ADDRESS", ""),
        private_key=os.getenv("PRIVATE_KEY", ""),
        chain_id=int(os.getenv("CHAIN_ID", "84532")),
    )
