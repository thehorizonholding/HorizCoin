import ray
from ray.rllib.agents.ppo import PPOTrainer
import gym
import numpy as np

class AllocationEnv(gym.Env):
    def __init__(self, config=None):
        super().__init__()
        self.num_nodes = 32
        self.observation_space = gym.spaces.Box(
            low=0.0, high=1.0, shape=(10 + self.num_nodes,), dtype=np.float32
        )
        self.action_space = gym.spaces.Box(
            low=0.0, high=1.0, shape=(self.num_nodes,), dtype=np.float32
        )

    def reset(self, *, seed=None, options=None):
        super().reset(seed=seed)
        self.state = np.random.rand(self.observation_space.shape[0]).astype(np.float32)
        return self.state, {}

    def step(self, action):
        utilization = np.clip(action, 0.0, 1.0)
        avg_util = float(np.mean(utilization))
        qos_penalty = 0.0 if avg_util < 0.9 else (avg_util - 0.9) * 10.0
        cost = avg_util * 10.0

        reward = -(cost + qos_penalty)

        self.state = np.random.rand(self.observation_space.shape[0]).astype(np.float32)
        terminated = True
        truncated = False
        info = {}
        return self.state, reward, terminated, truncated, info

if __name__ == "__main__":
    ray.init(ignore_reinit_error=True)

    config = {
        "env": AllocationEnv,
        "framework": "torch",
        "num_workers": 2,
    }

    agent = PPOTrainer(config=config)
    for i in range(10):
        result = agent.train()
        print(f"[AllocationAgent] Iteration {i}, mean reward={result['episode_reward_mean']}")
