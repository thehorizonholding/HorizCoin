import ray
from ray.rllib.agents.dqn import DQNTrainer
import gym
import numpy as np

class PricingEnv(gym.Env):
    def __init__(self, config=None):
        super().__init__()
        self.action_space = gym.spaces.Discrete(100)
        self.observation_space = gym.spaces.Box(low=0.0, high=1.0, shape=(10,), dtype=np.float32)

    def reset(self, *, seed=None, options=None):
        super().reset(seed=seed)
        self.state = np.random.rand(10).astype(np.float32)
        return self.state, {}

    def step(self, action):
        price_multiplier = 0.5 + (action / 100.0)
        base_cost = 10.0
        client_accept_prob = max(0.0, 1.5 - price_multiplier)
        accepted = np.random.rand() < client_accept_prob

        if accepted:
            price = base_cost * price_multiplier
            reward = price - base_cost
        else:
            reward = 0.0

        self.state = np.random.rand(10).astype(np.float32)
        terminated = True
        truncated = False
        info = {}
        return self.state, reward, terminated, truncated, info

if __name__ == "__main__":
    ray.init(ignore_reinit_error=True)

    config = {
        "env": PricingEnv,
        "framework": "torch",
    }

    agent = DQNTrainer(config=config)
    for i in range(10):
        result = agent.train()
        print(f"[PricingAgent] Iteration {i}, mean reward={result['episode_reward_mean']}")
