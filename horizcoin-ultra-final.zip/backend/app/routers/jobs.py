from fastapi import APIRouter
from pydantic import BaseModel
from ..services import pricing_agent_client, allocation_agent_client, settlement_client

router = APIRouter()

class JobRequest(BaseModel):
    client_address: str
    job_type: str
    complexity: float
    deadline_sla: float

class JobQuote(BaseModel):
    price_husd: float
    estimated_cost_husd: float

@router.post("/quote", response_model=JobQuote)
def get_quote(req: JobRequest):
    price, cost = pricing_agent_client.get_price_and_cost(req)
    return JobQuote(price_husd=price, estimated_cost_husd=cost)

class JobAccept(BaseModel):
    job_id: str
    client_address: str
    provider_address: str
    price_husd: float

@router.post("/accept")
def accept_job(body: JobAccept):
    # 1. Schedule on providers via RL allocation agent (placeholder)
    allocation_agent_client.schedule_job(body.job_id, body.provider_address)

    # 2. Once off-chain validation says "done", settle on-chain
    settlement_client.settle_job_onchain(
        job_id=body.job_id,
        client=body.client_address,
        provider=body.provider_address,
        total_amount_husd=body.price_husd,
    )
    return {"status": "ok"}
