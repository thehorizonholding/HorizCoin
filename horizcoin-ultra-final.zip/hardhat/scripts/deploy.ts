import { ethers } from "hardhat";

async function main() {
  const [deployer] = await ethers.getSigners();
  console.log("Deploying with:", deployer.address);

  const initialSupply = ethers.parseUnits("1000000000", 18); // 1B HORC

  const HORC = await ethers.getContractFactory("HORCToken");
  const horc = await HORC.deploy(deployer.address, initialSupply);
  await horc.waitForDeployment();
  console.log("HORC deployed at:", await horc.getAddress());

  const fakeHusdAddress = ethers.ZeroAddress; // Replace with real hUSD on your network
  const flywheelAdmin = deployer.address;

  const Flywheel = await ethers.getContractFactory("RevenueFlywheelContract");
  const flywheel = await Flywheel.deploy(
    fakeHusdAddress,
    await horc.getAddress(),
    ethers.ZeroAddress, // router placeholder
    deployer.address,   // incentivePool placeholder = deployer
    5000,               // 50% burn
    flywheelAdmin
  );
  await flywheel.waitForDeployment();
  console.log("RevenueFlywheelContract deployed at:", await flywheel.getAddress());

  const Settlement = await ethers.getContractFactory("JobSettlementContract");
  const settlement = await Settlement.deploy(
    fakeHusdAddress,
    await flywheel.getAddress(),
    2000,               // 20% take rate
    deployer.address
  );
  await settlement.waitForDeployment();
  console.log("JobSettlementContract deployed at:", await settlement.getAddress());
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
