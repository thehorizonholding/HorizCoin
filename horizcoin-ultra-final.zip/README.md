# HorizCoin Ultra Version – Private DePIN Compute Network

This repository contains the **Ultra Version** of the HorizCoin architecture:

- Private, permissioned DePIN compute network (GPU + cloud + IoT + SIM extensions).
- Dual–token economics:
  - `HORC` – network / incentive token.
  - `hUSD` – stable settlement token used by B2B clients.
- Flywheel settlement layer:
  - `JobSettlementContract` – splits B2B payments into provider payout + protocol revenue.
  - `RevenueFlywheelContract` – swaps hUSD → HORC, burns a portion, and distributes the rest to an incentive pool.
- Backend + AI / RL control-plane:
  - Pricing RL agent (Agent 1) for dynamic pricing of jobs.
  - Allocation RL agent (Agent 2) for GPU / node scheduling.
  - FastAPI control-center that:
    - Accepts jobs from clients.
    - Calls the pricing agent.
    - Schedules workloads.
    - Calls the on-chain settlement contracts.

This codebase is a **reference implementation / starter kit**, not audited production code.
You **must** run your own audits and testing before deploying to mainnet.

## Layout

- `contracts/` – Solidity smart contracts.
- `hardhat/` – Hardhat project for deploying and verifying contracts.
- `foundry/` – Foundry scripts for power–users.
- `backend/` – FastAPI + Ray/RLlib control-center and RL agents.
- `docker/` – Example Dockerfiles + docker-compose for local orchestration.

## Quick Start (MacBook Pro Max)

Prerequisites:

- Node.js 20+
- pnpm or npm
- Python 3.11+
- Poetry *or* `pip` / virtualenv
- Docker (optional but recommended)
- `foundryup` (optional) for Foundry

### 1. Install contracts toolchain (Hardhat)

```bash
cd hardhat
pnpm install   # or: npm install
```

Copy the contracts into the Hardhat project (here we just reference `../contracts`):

```bash
# already wired in hardhat.config.ts via path mapping
```

Create `.env`:

```bash
cp .env.example .env
# then edit the values:
# PRIVATE_KEY=0x...
# BASE_MAINNET_RPC_URL=https://mainnet.base.org
# ETH_MAINNET_RPC_URL=https://eth-mainnet.alchemyapi.io/v2/...
# ETHERSCAN_API_KEY=...
# BASESCAN_API_KEY=...
```

Compile + deploy to a testnet (example: Base Sepolia, if configured):

```bash
pnpm hardhat compile
pnpm hardhat run scripts/deploy.ts --network baseSepolia
```

The deploy script prints the addresses for:

- `HORC`
- `JobSettlementContract`
- `RevenueFlywheelContract`

Save those addresses; you’ll need them in the backend `.env`.

### 2. Foundry (optional power–user path)

```bash
cd foundry
foundryup
forge build
# Example dry–run (simulated deploy):
forge script script/Deploy.s.sol --rpc-url $BASE_SEPOLIA_RPC --broadcast --dry-run
```

### 3. Backend + RL Control-Center

Create a Python virtualenv:

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

Create `.env` for backend:

```bash
cp .env.example .env
# Set:
#  RPC_URL=
#  HORC_TOKEN_ADDRESS=
#  HUSD_TOKEN_ADDRESS=
#  JOB_SETTLEMENT_ADDRESS=
#  FLYWHEEL_ADDRESS=
#  PRIVATE_KEY=0x...   # of the control-center wallet
```

Run the backend API:

```bash
uvicorn app.main:app --reload
```

Run Ray + RL agents locally (dev mode):

```bash
# In another terminal with the same venv:
python -m app.rl.train_pricing_agent
python -m app.rl.train_allocation_agent
```

In production, you would:

- Run Ray in a separate cluster (on-prem, cloud, or DePIN nodes).
- Periodically export trained policies and load them into the control-center.

### 4. Docker (optional)

From the repo root:

```bash
cd docker
docker compose up --build
```

This will build:

- `backend` service (FastAPI + RL clients)
- `hardhat-node` (local Hardhat chain, for dev / integration)
- `ray-head` (placeholder Ray node for experimentation – you may customize)

### 5. Important Notes

- **Security**: None of these contracts have been audited. Before mainnet:
  - Run full unit + fuzz + property tests.
  - Use tools like Slither, Mythril.
  - Hire a reputable audit firm.
- **Economics**: All parameters (take rate, burn split, supply) are examples.
  Tune them based on your own modeling.
- **Compliance**: Running a B2B compute marketplace and issuing tokens may
  trigger regulations (securities, commodities, money–services, data protection).
  Consult qualified legal counsel in your jurisdiction.

---

This repo is intentionally modular so you can:

- Swap the DEX router (Uniswap v2/v3, Sushiswap, Aerodrome, etc.).
- Attach more DePIN resources (SIM-based, IoT devices, storage).
- Extend the RL layer with more agents (fraud detection, anomaly scoring).
