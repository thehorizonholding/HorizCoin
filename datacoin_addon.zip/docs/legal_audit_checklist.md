Legal & Audit Checklist (summary)
---------------------------------
- Consult counsel for data rights, licensing, and token classification in your jurisdictions.
- Audit smart contracts (external firm) before mainnet deployment.
- Design oracle decentralization plan (minimum N nodes, geographic diversity).
- Establish provider agreements and attestation requirements for provenance.
- Implement privacy-preserving proofs (ZK) for compliance where needed.
