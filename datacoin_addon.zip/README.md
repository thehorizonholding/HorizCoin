DataCoin Add-on for Horizon Project
===================================
Generated: 2025-10-25T21:50:33.374846Z

Purpose:
- Adds a Data-as-Asset ("DataCoin") module to your existing Horizon project as an OPTIONAL add-on.
- This package contains starter smart contracts, a Dynamic Data Valuation Oracle (DDVO) mock,
  oracle-node scaffolds, a small Next.js dashboard skeleton, Terraform placeholders, and docs.

IMPORTANT:
- This is a developer starter kit for experimentation only. It is NOT production-ready.
- Do NOT deploy any smart contracts to mainnet without professional security audits and legal review.
- The DDVO here is a simulated model for demonstration; replace with robust, audited models before production.
- The oracle components are mock/Demo implementations and should be replaced by a DON (e.g., Chainlink) for production.

Contents:
- contracts/         : Solidity contract stubs (ERC-721, ERC-1155, DataTokenManager)
- ddvo/              : Dynamic Data Valuation Oracle (DDVO) mock (Python) + example scoring model
- oracle_node/       : Oracle node scaffold (fetcher + signer simulation)
- dashboard/         : Next.js skeleton and API stubs for token issuance & valuation display
- terraform/         : placeholders for node provisioning & L2 testnet components
- docs/              : integration guide, whitepaper-summary, legal & audit checklist
- examples/          : example dataset metadata and mock on-chain flows (local test)


Integration:
- Add this addon folder to your repo under `addons/datacoin/` and follow docs/integration.md.
- The add-on is designed to NOT modify your original project files; integration points are well-documented.

Next steps:
1. Review docs/legal.md and consult counsel before any token issuance.
2. Run unit tests and simulate the DDVO locally.
3. If satisfied, prepare audited contracts and plan a testnet deployment.
