# oracle node mock - queries local DDVO and outputs signed payload (demo HMAC)
import requests, json, os, time, hmac, hashlib, base64

DDVO_URL = os.environ.get('DDVO_URL','http://localhost:8200/score')
SECRET = os.environ.get('ORACLE_SECRET','demo-secret')

def sign_payload(payload_str):
    mac = hmac.new(SECRET.encode(), payload_str.encode(), hashlib.sha256).hexdigest()
    return mac

def fetch_and_sign(dataset_meta):
    r = requests.post(DDVO_URL, json=dataset_meta, timeout=10)
    r.raise_for_status()
    resp = r.json()
    payload = json.dumps(resp, sort_keys=True)
    sig = sign_payload(payload)
    out = {'payload': resp, 'sig': sig}
    print('Signed update:', out)
    return out

if __name__=='__main__':
    # demo loop
    meta = {"dataset_id":1, "meta": {"provenance_score":0.9,"exclusivity":0.2,"usage_count":120,"recency_days":2,"compliance_score":0.95}}
    while True:
        try:
            fetch_and_sign(meta)
        except Exception as e:
            print('error', e)
        time.sleep(10)
