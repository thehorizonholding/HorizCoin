Oracle Node Scaffold
--------------------
This is a local mock oracle node that queries the DDVO and signs updates for submission.
In production, use a DON (e.g., Chainlink) and run multiple geographically-distributed nodes.
