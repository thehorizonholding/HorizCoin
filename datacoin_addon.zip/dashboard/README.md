Next.js Dashboard Skeleton
--------------------------
- Minimal UI to mint DataNFTs, view DDVO scores, and manage providers.
- Run: `cd dashboard && npm install && npm run dev` (Node.js required)
