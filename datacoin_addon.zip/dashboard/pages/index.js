// Minimal Next.js page (demo)
import React from 'react'

export default function Home() {
  return (
    <div style={{padding:30}}>
      <h1>DataCoin Dashboard (Demo)</h1>
      <p>This is a skeleton. Integrate with smart contracts and DDVO endpoints.</p>
    </div>
  )
}
