Example Local Flow (Test/dev)
-----------------------------
1. Start DDVO mock: python3 ddvo/ddvo_service.py
2. Start oracle node mock: python3 oracle_node/node.py
3. Use hardhat/Foundry locally to deploy contracts in contracts/ to a local testnet
4. Oracle node outputs signed score payloads; an off-chain relayer can call ValuationConsumer.updateScore()
   or a DON would aggregate multiple oracle nodes and submit a validated update on-chain.
