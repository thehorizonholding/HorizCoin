# ddvo_service.py - simple DDVO mock service
# Usage: python ddvo/ddvo_service.py
from http.server import BaseHTTPRequestHandler, HTTPServer
import json, math, time, random

PORT = 8200

def score_dataset(meta):
    # meta: {provenance_score, exclusivity, usage_count, recency_days, compliance_score}
    # very simple weighted formula (demo only)
    w = {'prov':0.25,'excl':0.20,'usage':0.30,'recency':0.15,'comp':0.10}
    prov = meta.get('provenance_score',0.5)
    excl = meta.get('exclusivity',0.0)
    usage = min(meta.get('usage_count',0), 1000)/1000.0
    recency = max(0.0, 1.0 - (meta.get('recency_days',30)/365.0))
    comp = meta.get('compliance_score',0.5)
    score = (prov*w['prov'] + excl*w['excl'] + usage*w['usage'] + recency*w['recency'] + comp*w['comp'])
    # scale to 0..1000 integer
    return int(max(0,min(1000, score*1000)))

class Handler(BaseHTTPRequestHandler):
    def do_POST(self):
        if self.path == '/score':
            length = int(self.headers.get('content-length',0))
            body = self.rfile.read(length)
            data = json.loads(body)
            dataset_id = data.get('dataset_id',0)
            meta = data.get('meta',{})
            score = score_dataset(meta)
            resp = {'dataset_id': dataset_id, 'score': score, 'ts': int(time.time())}
            self.send_response(200)
            self.send_header('Content-Type','application/json')
            self.end_headers()
            self.wfile.write(json.dumps(resp).encode())
        else:
            self.send_response(404)
            self.end_headers()

if __name__ == '__main__':
    print('Starting DDVO mock on port', PORT)
    server = HTTPServer(('0.0.0.0', PORT), Handler)
    server.serve_forever()
