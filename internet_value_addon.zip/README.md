# Internet Value Add-on (Bandwidth, Data & Edge Monetization)

This add-on provides legal, safe, and non-invasive modules to monetize
bandwidth, compute at the edge, and data products of the HorizCoin project.
It is designed to be **additive**: drop it into a feature branch and it will
not change existing project settings.

Major components:
- services/bandwidth_marketplace/  : API + marketplace skeleton for renting bandwidth & connectivity
- services/data_monetization/     : APIs and ledger for selling anonymized analytics/data products
- services/edge_optimizer/        : tools to schedule workloads to cheapest/closest edge nodes
- docs/                           : plans, compliance notes, revenue models
- CI workflows and CODEOWNERS for review

Safety:
- Dry-run by default; blocks disallowed keywords and illegal activity.
- Requires Vault/KMS for secrets; never commit keys.
- Requires legal review before enabling monetization or customer onboarding.
