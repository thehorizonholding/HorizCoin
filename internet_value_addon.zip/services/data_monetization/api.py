# data_monetization/api.py - safe skeleton for dataset registration and API key issuance
from flask import Flask, request, jsonify
import os, json, uuid, time
from decimal import Decimal

app = Flask(__name__)

DATASETS = {}
API_KEYS = {}
LEDGER = {}

BLOCKED = ['mine','mining','cryptominer','steal','exploit','coin','mint','botnet']

def contains_blocked(s):
    return any(b in str(s).lower() for b in BLOCKED)

@app.route('/datasets/register', methods=['POST'])
def register_dataset():
    body = request.get_json() or {}
    if contains_blocked(body):
        return jsonify({'error':'blocked content'}), 400
    dsid = str(uuid.uuid4())
    DATASETS[dsid] = {'id':dsid,'name':body.get('name'),'desc':body.get('desc'),'license':body.get('license'),'created':int(time.time())}
    return jsonify(DATASETS[dsid]), 201

@app.route('/apikeys/create', methods=['POST'])
def create_apikey():
    body = request.get_json() or {}
    acct = body.get('account')
    # require KYC flag in request in real system
    apikey = str(uuid.uuid4())
    API_KEYS[apikey] = {'account':acct,'created':int(time.time())}
    return jsonify({'api_key':apikey}), 201

@app.route('/access/request', methods=['POST'])
def access_request():
    body = request.get_json() or {}
    apikey = body.get('api_key')
    dsid = body.get('dataset_id')
    if contains_blocked(body):
        return jsonify({'error':'blocked content'}), 400
    if apikey not in API_KEYS:
        return jsonify({'error':'invalid api key'}), 401
    # create an access invoice (simulation)
    amount = Decimal('10.00')  # flat fee demo
    invoice = {'invoice_id':str(uuid.uuid4()),'account':API_KEYS[apikey]['account'],'dataset':dsid,'amount':str(amount),'ts':int(time.time())}
    LEDGER.setdefault(API_KEYS[apikey]['account'],[]).append(invoice)
    return jsonify({'access':'granted','invoice':invoice}), 200

@app.route('/billing/<account>', methods=['GET'])
def billing(account):
    return jsonify(LEDGER.get(account, []))

@app.route('/health', methods=['GET'])
def health():
    return jsonify({'status':'ok','ts': int(time.time())})

if __name__ == '__main__':
    port = int(os.getenv('PORT','8083'))
    app.run(host='0.0.0.0', port=port)
