# optimizer.py - simple ranking function for edge nodes
from dataclasses import dataclass
from typing import List
@dataclass
class EdgeNode:
    id: str
    provider: str
    region: str
    price_per_gb: float
    latency_ms: float
    reliability: float

def rank_nodes(nodes: List[EdgeNode]):
    scored = []
    for n in nodes:
        score = (1.0 / max(0.0001, n.price_per_gb)) * 0.7 + (1.0 / max(1.0,n.latency_ms))*0.3 + n.reliability*0.5
        scored.append((score,n))
    scored.sort(reverse=True, key=lambda x: x[0])
    return [n for _,n in scored]
