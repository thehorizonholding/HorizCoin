# Edge Optimizer

Small toolkit to rank edge locations and suggest placement to reduce bandwidth costs and latency.
Designed to feed the AI Orchestrator for legal workload placement decisions.
