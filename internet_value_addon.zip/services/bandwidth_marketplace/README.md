# Bandwidth Marketplace (Add-on)

Simple, legal marketplace to advertise and lease spare bandwidth or connectivity.
Designed to be dry-run and non-invasive. Replace the stubs with real connectors only
for accounts you own and after legal/compliance sign-off.
