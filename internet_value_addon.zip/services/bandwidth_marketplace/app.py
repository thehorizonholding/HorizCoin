"""Bandwidth Marketplace - safe, dry-run skeleton
- Advertise bandwidth offers
- Simulate lease agreements and billing (JSON)
- KYC and policy stubs; blocks disallowed activity
"""
from flask import Flask, request, jsonify
import os, json, uuid, time
from decimal import Decimal

app = Flask(__name__)

OFFERS = {}
LEASES = {}
LEDGER = {}

API_KEYS = {"admin-key": "admin"}

DISALLOWED = ["mine","mining","cryptominer","botnet","steal","exploit","coin","mint"]

def require_api_key(fn):
    def wrapper(*args, **kwargs):
        key = request.headers.get("X-Api-Key") or request.args.get("api_key")
        if not key or key not in API_KEYS:
            return jsonify({"error":"unauthorized"}), 401
        return fn(*args, **kwargs)
    wrapper.__name__ = fn.__name__
    return wrapper

def contains_disallowed(payload):
    p = str(payload).lower()
    return any(d in p for d in DISALLOWED)

@app.route('/offers', methods=['POST'])
@require_api_key
def create_offer():
    data = request.get_json() or {}
    if contains_disallowed(json.dumps(data)):
        return jsonify({'error':'disallowed content in offer'}), 400
    offer_id = str(uuid.uuid4())
    offer = {
        'offer_id': offer_id,
        'provider_node': data.get('provider_node'),
        'bandwidth_mbps': int(data.get('bandwidth_mbps', 0)),
        'region': data.get('region'),
        'price_per_hour_usd': str(data.get('price_per_hour_usd','0.00')),
        'available_hours': int(data.get('available_hours',0)),
        'status': 'available',
        'created_at': int(time.time())
    }
    OFFERS[offer_id] = offer
    return jsonify(offer), 201

@app.route('/offers', methods=['GET'])
@require_api_key
def list_offers():
    return jsonify(list(OFFERS.values()))

@app.route('/lease', methods=['POST'])
@require_api_key
def create_lease():
    data = request.get_json() or {}
    if contains_disallowed(json.dumps(data)):
        return jsonify({'error':'disallowed content in lease'}), 400
    offer_id = data.get('offer_id')
    hours = int(data.get('hours',1))
    acct = data.get('billing_account','test-cust')
    offer = OFFERS.get(offer_id)
    if not offer or offer['status']!='available' or offer['available_hours']<hours:
        return jsonify({'error':'offer not available'}), 404
    lease_id = str(uuid.uuid4())
    lease = {'lease_id':lease_id,'offer_id':offer_id,'hours':hours,'acct':acct,'status':'simulated','ts':int(time.time())}
    LEASES[lease_id] = lease
    offer['available_hours'] -= hours
    amount = Decimal(offer['price_per_hour_usd']) * Decimal(hours)
    invoice = {'invoice_id':str(uuid.uuid4()),'lease_id':lease_id,'account':acct,'amount_usd':str(amount),'ts':int(time.time())}
    LEDGER.setdefault(acct,[]).append(invoice)
    return jsonify({'lease':lease,'invoice':invoice}), 201

@app.route('/billing/<account>', methods=['GET'])
@require_api_key
def billing(account):
    return jsonify(LEDGER.get(account,[]))

@app.route('/health', methods=['GET'])
def health():
    return jsonify({'status':'ok','ts':int(time.time())})

if __name__ == '__main__':
    port = int(os.getenv('PORT','8082'))
    app.run(host='0.0.0.0', port=port)
