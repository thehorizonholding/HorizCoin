Kubernetes manifests placeholder. Use sealed secrets and private ingress.
