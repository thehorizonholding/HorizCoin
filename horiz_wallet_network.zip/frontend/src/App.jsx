import React, {useEffect, useState} from 'react'
import {ethers} from 'ethers'

export default function App(){
  const [provider, setProvider] = useState(null)
  const [address, setAddress] = useState(null)
  const [balance, setBalance] = useState(null)

  async function connectMetaMask(){
    if (!window.ethereum) return alert('Install MetaMask')
    const p = new ethers.providers.Web3Provider(window.ethereum)
    await p.send('eth_requestAccounts', [])
    const signer = p.getSigner()
    const addr = await signer.getAddress()
    setProvider(p)
    setAddress(addr)
  }

  useEffect(()=>{
    if (provider && address){
      provider.getBalance(address).then(b => setBalance(ethers.utils.formatEther(b)))
    }
  }, [provider, address])

  return (
    <div style={{padding:20}}>
      <h1>Horiz Wallet (Scaffold)</h1>
      <button onClick={connectMetaMask}>Connect MetaMask</button>
      {address && <div>Address: {address}</div>}
      {balance && <div>Balance: {balance} ETH</div>}
    </div>
  )
}
