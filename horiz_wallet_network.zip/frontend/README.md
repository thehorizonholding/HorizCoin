Frontend scaffold. Use your preferred React tooling (Vite, CRA). This file is a minimal example.
