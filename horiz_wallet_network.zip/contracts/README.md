Smart contract examples. Use Hardhat/Truffle and audited contracts for production.
