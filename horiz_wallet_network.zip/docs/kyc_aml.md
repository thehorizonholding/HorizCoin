# KYC/AML Guidance

- Integrate a KYC provider (Onfido, Jumio) for custodial onboarding.
- Implement transaction monitoring and sanctions screening.
