# Deployment Guide (scaffold)

- Use Terraform to create networking, VPCs, and KMS keys.
- Deploy backend to private subnets and expose API through authenticated gateway.
- Use systemd or Kubernetes for process management.
