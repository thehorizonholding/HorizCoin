# Architecture Overview

Components:
- frontend/ : React wallet UI (non-custodial + custodial UX)
- backend/  : Node.js API server (custodial ledger, KYC hooks, relayer)
- contracts/: Example smart contracts (ERC-20, Vault multisig)
- infra/    : Terraform / k8s placeholders for secure deployment
- docs/     : Security, compliance and operational runbooks

See README for getting started.
