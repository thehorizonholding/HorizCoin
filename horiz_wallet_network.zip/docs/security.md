# Security & Compliance Notes

- Do not commit private keys or production secrets.
- Use KMS/HSM for custodial keys; use WebCrypto for client-side keys.
- Implement KYC/AML for custodial accounts; integrate sanctions screening.
- Require security audits before going to production.
