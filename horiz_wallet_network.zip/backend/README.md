Backend scaffold (Node.js/Express). This demo uses in-memory accounts. Replace with a persistent DB (Postgres) and proper ledger service before production.
