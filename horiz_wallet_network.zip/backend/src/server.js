const express = require('express');
const bodyParser = require('body-parser');
const app = express();
app.use(bodyParser.json());

// Health
app.get('/health', (req,res) => res.json({status:'ok'}));

// Simple ledger endpoints (demo only)
const accounts = {}; // in-memory demo; replace with DB

app.post('/api/accounts/create', (req,res)=>{
  const id = 'acct-' + Math.random().toString(36).slice(2,9);
  accounts[id] = {balance:0};
  res.json({account_id:id});
});

app.post('/api/custodial/transfer', (req,res)=>{
  const {from, to, amount} = req.body;
  if(!accounts[from] || !accounts[to]) return res.status(400).json({error:'invalid account'});
  accounts[from].balance -= amount;
  accounts[to].balance += amount;
  return res.json({status:'ok'});
});

const port = process.env.PORT || 3000;
app.listen(port, ()=> console.log('Server listening on', port));
