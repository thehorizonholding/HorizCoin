# Horiz Wallet Network (Scaffold)

This repository scaffold provides a starter implementation and architecture for a production-grade wallet network.
It includes a React frontend, Node.js backend, example smart contracts, infra placeholders, and documentation.

IMPORTANT SAFETY NOTE:
- This scaffold is for lawful, compliant use only. It does NOT include production keys or enable illicit activities.
- Replace placeholder secrets, endpoints, and test contracts with audited, production-grade equivalents before going live.
- Custodial functionality must be used only with appropriate KYC/AML, banking partnerships, and legal review.
