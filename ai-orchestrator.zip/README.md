# AI Cloud Orchestrator — Prototype

This repository is a prototype AI-driven orchestrator to manage multi-cloud infrastructure
(including AWS, GCP, Alibaba), with planner/verifier/executor flow and a human approval UI.

**Safety first**: This is a tool to automate *your own* infrastructure only. Do not use it
to access servers you do not control. Money-moving features require legal/compliance review.

## Quickstart (local dev)

1. Copy `.env.example` -> `.env` and fill your keys (OpenAI, cloud SDK creds, exchange keys).
   Use secrets manager in production; do not commit `.env`.

2. Create Python virtualenv:
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   pip install -r requirements.txt
   ```

3. Start UI (approvals) service (node):
   ```bash
   cd ui
   npm install
   node server.js
   ```

4. Run planner/executor dry-run:
   ```bash
   python planner.py --goal "deploy horizcoin dev cluster in aws us-east-1"
   ```

5. To execute plan (dry-run disabled), use executor:
   ```bash
   python executor.py --plan-file plan.json --dry=false
   ```

## Components

- `planner.py` - calls LLM to generate structured JSON plans
- `verifier.py` - policy & cost checks
- `executor.py` - executes steps via connectors (dry-run first)
- `connectors/*` - cloud provider connectors
- `terraform_helper.py` - helper to run terraform (init/plan/apply)
- `exchange/ccxt_wrapper.py` - wrapper to interact with exchanges (requires api keys)
- `ui/` - simple approval HTTP server for human-in-loop approvals
- `infra/` - place for your Terraform modules

## CI
A sample GitHub Actions workflow is provided in `.github/workflows/ci.yml`.

## License
MIT — use responsibly and legally.
