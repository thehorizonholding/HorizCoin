# executor.py
import argparse, json, time, os
from verifier import verify_plan
from terraform_helper import TerraformHelper
from connectors import aws_connector, gcp_connector, alibaba_connector

TF = TerraformHelper()

CONNECTOR_MAP = {
    'aws': aws_connector,
    'gcp': gcp_connector,
    'alibaba': alibaba_connector
}

def execute_plan(plan, dry=True, require_approval=True):
    # verify plan first
    v = verify_plan(plan)
    print("Verifier:", v)
    if not v['ok']:
        print("Plan blocked by policy; failing execution.")
        return {'status':'blocked','verifier':v}

    # if total cost large and require_approval, ask for human approval
    if require_approval and v['total_cost'] > float(os.getenv('APPROVAL_COST_THRESHOLD','1000')):
        print(f"Plan cost {v['total_cost']} exceeds approval threshold.")
        # In production: send to approval webhook / UI and wait
        approved = request_approval_stub(plan, v)
        if not approved:
            return {'status':'not_approved'}

    results = []
    for step in plan:
        provider = step.get('provider')
        action = step.get('action')
        params = step.get('params',{})
        print(f"Executing step {step.get('id')}: {action} on {provider} (dry={dry})")
        if dry:
            results.append({'id':step.get('id'),'status':'dry-run'})
            continue
        try:
            if action.startswith('terraform_'):
                # expect params.dir
                dirpath = params.get('dir')
                TF.run(dirpath, vars_dict=params.get('vars',{}))
                results.append({'id':step.get('id'),'status':'ok','detail':'terraform applied'})
            elif action == 'deploy_container':
                conn = CONNECTOR_MAP.get(provider)
                if conn:
                    out = conn.deploy_container(params)
                    results.append({'id':step.get('id'),'status':'ok','result':out})
                else:
                    results.append({'id':step.get('id'),'status':'no-connector'})
            else:
                # generic pass-through to connector
                conn = CONNECTOR_MAP.get(provider)
                if conn:
                    out = conn.handle(action, params)
                    results.append({'id':step.get('id'),'status':'ok','result':out})
                else:
                    results.append({'id':step.get('id'),'status':'unknown-provider'})
        except Exception as e:
            results.append({'id':step.get('id'),'status':'error','error':str(e)})
        time.sleep(0.3)
    return {'status':'ok','results':results}

def request_approval_stub(plan, verifier_report):
    """
    In production, POST plan to approval service/UI and wait for approver.
    Here we check an environment variable or simple file flag for demo.
    """
    import os, time
    approver_token = os.getenv('APP_APPROVER_TOKEN')
    # For prototype: require the approver to create a file named 'approved.txt'
    print("Waiting for manual approval. Create a file named 'approved.txt' in repo root to simulate.")
    for _ in range(60):
        if os.path.exists('approved.txt'):
            print("Approval detected.")
            os.remove('approved.txt')
            return True
        time.sleep(1)
    print("Approval timed out.")
    return False

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan-file', default='plan.json')
    parser.add_argument('--dry', action='store_true', default=True)
    parser.add_argument('--require-approval', action='store_true', default=True)
    args = parser.parse_args()
    with open(args.plan_file) as f:
        plan = json.load(f)
    result = execute_plan(plan, dry=args.dry, require_approval=args.require_approval)
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()
