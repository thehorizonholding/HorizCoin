// ui/server.js
const express = require('express');
const bodyParser = require('body-parser');
const app = express();
app.use(bodyParser.json());

const APPROVER_TOKEN = process.env.APP_APPROVER_TOKEN || 'my-approver-shared-secret';

// Simple approval endpoint. In production secure and authenticate.
app.post('/orchestrator/approve', (req, res) => {
  const { token, planId, approve } = req.body;
  if (!token || token !== APPROVER_TOKEN) {
    return res.status(401).json({ error: 'unauthorized' });
  }
  if (approve) {
    // In prototype: create a file for executor to detect
    const fs = require('fs');
    fs.writeFileSync('approved.txt','approved');
    return res.json({ result: 'approved' });
  } else {
    return res.json({ result: 'rejected' });
  }
});

app.get('/healthz', (req, res) => res.json({ status: 'ok' }));
const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Approval UI listening ${PORT}`));
