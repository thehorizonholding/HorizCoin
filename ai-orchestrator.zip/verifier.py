# verifier.py
import json
import os

COST_THRESHOLD_DAILY = float(os.getenv('COST_THRESHOLD_DAILY', '5000'))

def verify_step_policy(step, allow_delete=False):
    # Basic policy checks
    action = step.get('action','')
    cost = float(step.get('cost_estimate_usd', 0))
    if action.startswith('delete') and not allow_delete:
        return False, "Deletes are blocked by policy"
    if cost > COST_THRESHOLD_DAILY:
        return False, f"Estimated cost {cost} exceeds threshold {COST_THRESHOLD_DAILY}"
    return True, None

def verify_plan(plan, allow_delete=False):
    results = []
    total_cost = 0.0
    for s in plan:
        ok, reason = verify_step_policy(s, allow_delete=allow_delete)
        total_cost += float(s.get('cost_estimate_usd',0))
        results.append({'id':s.get('id'),'ok':ok,'reason':reason})
    return {'ok': all(r['ok'] for r in results), 'details':results, 'total_cost':total_cost}
