# terraform_helper.py
import subprocess, os

class TerraformHelper:
    def __init__(self):
        pass

    def run(self, dirpath, vars_dict=None):
        if not dirpath or not os.path.exists(dirpath):
            raise FileNotFoundError(f"Terraform dir not found: {dirpath}")
        cwd = os.path.abspath(dirpath)
        print("Terraform init in", cwd)
        subprocess.check_call(['terraform','init','-input=false'], cwd=cwd)
        # build apply command
        cmd = ['terraform','apply','-auto-approve','-input=false']
        if vars_dict:
            for k,v in vars_dict.items():
                cmd += ['-var', f"{k}={v}"]
        print("Running:", " ".join(cmd))
        subprocess.check_call(cmd, cwd=cwd)
