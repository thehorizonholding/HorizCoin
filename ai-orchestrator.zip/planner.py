# planner.py
import os
import argparse
import json
import re
from dotenv import load_dotenv

load_dotenv()
OPENAI_API_KEY = os.getenv('OPENAI_API_KEY')
if not OPENAI_API_KEY:
    print("Warning: OPENAI_API_KEY not set, planner will not call LLM (fallback local).")

def llm_plan(goal_text):
    """
    Call OpenAI to convert a natural-language goal into an ordered JSON plan.
    Each step must include: id, action, provider, params, description, cost_estimate_usd
    """
    # Safe fallback: simple heuristics if key not present
    if not OPENAI_API_KEY:
        # heuristic plan
        return [
            {"id":"1","action":"terraform_deploy","provider":"aws","params":{"dir":"infra/aws","region":"us-east-1"},"description":"deploy AWS infra","cost_estimate_usd":100},
            {"id":"2","action":"deploy_container","provider":"aws","params":{"image":"gcr.io/my/image:latest","k8s_manifest":"infra/k8s/deploy.yaml"},"description":"deploy service","cost_estimate_usd":20}
        ]
    # call OpenAI (chat completions)
    try:
        import openai
        openai.api_key = OPENAI_API_KEY
        prompt = f"""You are an expert cloud orchestration planner.
Convert the following goal into an ordered JSON array of primitive steps.
Goal: {goal_text}
Each step must be an object with keys: id, action, provider, params (object), description, cost_estimate_usd.
Only output valid JSON array.
"""
        resp = openai.ChatCompletion.create(
            model="gpt-4o-mini",
            messages=[{"role":"user","content":prompt}],
            temperature=0.0,
            max_tokens=800
        )
        text = resp['choices'][0]['message']['content']
        m = re.search(r'(\[.*\])', text, re.S)
        if not m:
            raise ValueError("No JSON array found in LLM response")
        plan = json.loads(m.group(1))
        return plan
    except Exception as e:
        print("LLM plan failed:", e)
        raise

def save_plan(plan, out="plan.json"):
    with open(out, "w") as f:
        json.dump(plan, f, indent=2)
    print("Plan saved to", out)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--goal', required=True)
    parser.add_argument('--out', default='plan.json')
    args = parser.parse_args()
    plan = llm_plan(args.goal)
    print(json.dumps(plan, indent=2))
    save_plan(plan, args.out)

if __name__ == "__main__":
    main()
