# infra

Place Terraform modules and Kubernetes manifests here.
This repo intentionally contains no production Terraform; add your IaC here.

Best practice:
- Use separate state backends per environment
- Use remote state (S3, GCS, OSS) with locking
- Do not commit secrets
