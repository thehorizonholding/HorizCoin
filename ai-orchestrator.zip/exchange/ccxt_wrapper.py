# exchange/ccxt_wrapper.py
import ccxt, os

def get_exchange():
    ex_id = os.getenv('EXCHANGE_ID')
    api_key = os.getenv('EXCHANGE_API_KEY')
    secret = os.getenv('EXCHANGE_API_SECRET')
    if not ex_id or not api_key or not secret:
        raise RuntimeError("Exchange credentials not configured")
    ex_cls = getattr(ccxt, ex_id)
    ex = ex_cls({'apiKey': api_key, 'secret': secret})
    ex.load_markets()
    return ex

def market_sell(symbol, amount):
    ex = get_exchange()
    return ex.create_market_sell_order(symbol, amount)

def market_buy(symbol, amount):
    ex = get_exchange()
    return ex.create_market_buy_order(symbol, amount)
