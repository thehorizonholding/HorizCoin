# HorizCoin — Complete Real-World Package (Local + Cloud)

See docs/ for usage.
