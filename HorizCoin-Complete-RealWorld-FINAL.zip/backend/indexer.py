import os,json,sqlite3,time
from web3 import Web3
RPC=os.getenv('RPC_URL','http://127.0.0.1:8545'); REG_ADDR=os.getenv('REGISTRY_ADDR','')
w3=Web3(Web3.HTTPProvider(RPC))
def setup_db(): conn=sqlite3.connect('indexer.db'); c=conn.cursor(); c.execute('CREATE TABLE IF NOT EXISTS records (record_id INTEGER PRIMARY KEY, owner TEXT, data_hash TEXT, timestamp INTEGER, tx_hash TEXT)'); conn.commit(); return conn
def main():
    if not REG_ADDR: raise RuntimeError('REGISTRY_ADDR not set')
    abi=json.load(open('backend/artifacts/DataRegistry.json'))['abi']
    contract=w3.eth.contract(address=REG_ADDR,abi=abi); conn=setup_db(); f=contract.events.NewRecord.createFilter(fromBlock='latest')
    try:
        while True:
            for ev in f.get_new_entries():
                args=ev['args']; txh=ev['transactionHash'].hex()
                conn.execute('INSERT OR IGNORE INTO records (record_id, owner, data_hash, timestamp, tx_hash) VALUES (?,?,?,?,?)', (args['recordId'], args['owner'], args['offChainDataHash'], args['timestamp'], txh)); conn.commit()
            time.sleep(5)
    except KeyboardInterrupt:
        pass
if __name__=='__main__': main()
