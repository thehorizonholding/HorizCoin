import random
def value_asset(features): return 1000 + int(random.random()*1000)
if __name__=='__main__': print('Sample value:', value_asset({'size':1024,'freshness_days':10}))