from fastapi import FastAPI
from pydantic import BaseModel
from web3 import Web3
import os, json
app = FastAPI()
w3 = Web3(Web3.HTTPProvider(os.environ.get('POLYGON_RPC','http://127.0.0.1:8545')))
ABI_PATH = os.path.join(os.path.dirname(__file__), 'artifacts', 'DataMarketplace.json')
MARKETPLACE_ADDR = os.environ.get('MARKETPLACE_ADDR','')
def get_contract():
    if not MARKETPLACE_ADDR:
        raise RuntimeError('MARKETPLACE_ADDR not set')
    abi = json.load(open(ABI_PATH))['abi']
    return w3.eth.contract(address=MARKETPLACE_ADDR, abi=abi)
class ListRequest(BaseModel):
    description: str; supply: int; uri: str; price_usd: float
@app.post('/list')
async def list_data(req: ListRequest):
    contract = get_contract()
    account = w3.eth.account.from_key(os.environ.get('PRIVATE_KEY'))
    txn = contract.functions.mintDataToken(account.address, req.supply, req.uri, int(req.price_usd * 1e18)).build_transaction({'from':account.address,'nonce':w3.eth.get_transaction_count(account.address),'gas':500000,'gasPrice':w3.eth.gas_price})
    signed = account.sign_transaction(txn)
    txh = w3.eth.send_raw_transaction(signed.rawTransaction)
    return {'tx_hash': txh.hex()}
