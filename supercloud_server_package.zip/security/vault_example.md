HashiCorp Vault usage (example)
- Use Vault for storing cloud provider credentials, SSH keys, and signing keys.
- Use dynamic credentials where possible (short-lived IAM tokens).
- Example: generate AWS IAM credentials on-demand for terraform apply using Vault AWS secret engine.
