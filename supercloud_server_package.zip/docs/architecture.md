SuperCloud Architecture (high-level)
-----------------------------------
Goal: Create a scalable, secure, multi-node GPU cluster optimized for high-throughput AI training and inference.

Components:
- Control Plane: Terraform for infra provisioning, Kubernetes cluster (managed or self-managed), Helm for apps.
- Compute Plane: GPU nodes (H100 / A100 / equivalent) in dedicated node pools, high-bandwidth networking.
- Storage: Object storage (S3/GCS/OSS), parallel file systems (Lustre/BeeGFS), NVMe pools.
- Networking & Security: VPC with private subnets, bastion host, Security Groups, NetworkPolicy.
- Orchestration & Jobs: Kubernetes + Ray / Kubeflow / KServe for distributed ML jobs.
- Monitoring & Observability: Prometheus + Grafana, nvml-exporter for GPU metrics.
- Secrets & Key Management: HashiCorp Vault or cloud KMS for secrets and signing keys.
- Cost & Autoscaling: Cluster Autoscaler, spot/preemptible strategies for non-critical tasks.
