    Legal & Ethics (summary)
- Obtain data usage rights for datasets and satellite feeds.
- Ensure energy use and sustainability commitments where applicable.
- Do not use the infrastructure for unauthorized monetization of networks.
