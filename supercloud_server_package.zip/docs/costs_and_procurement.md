    Costs & Procurement (high level)
--------------------------------
- H100-class GPUs rent for high hourly rates; verify with your chosen provider.
- Example: 64 H100 GPUs at $40/hr * 24*30 = ~$73,728 per month.
- Consider committed use discounts or bare-metal procurement for long-term cost savings.
