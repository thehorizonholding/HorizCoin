Usage & Ethics Policy (mandatory)
--------------------------------
This infrastructure MUST NOT be used for:
- Unauthorized cryptocurrency mining on third-party/cloud tenant resources.
- Any activity that violates cloud provider Terms of Service (ToS).
- Unauthorized access, data exfiltration, or illicit monetization of networks.

Approved uses:
- AI model training and inference, ML research, scientific compute, video rendering, and legitimate high-performance workloads.
- Data analytics from authorized datasets and satellite feeds where you have explicit permission.
- Edge/IoT processing for consenting participants and contracted providers.

Enforcement:
- Metering, billing, and workload classification must be enabled.
- Any job requesting sustained > X GPUs for > Y hours will require manual approval and billing escrow.
