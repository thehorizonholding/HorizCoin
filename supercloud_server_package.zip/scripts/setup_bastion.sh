#!/usr/bin/env bash
set -euo pipefail
echo 'Configure bastion host for admin access (example).'
