#!/usr/bin/env bash
echo 'Use kubeadm join or cloud provider managed node groups to add GPU nodes.'
