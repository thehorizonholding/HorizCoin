GPU NVML exporter notes:
- Use NVIDIA DCGM Exporter or nvml-exporter to expose GPU metrics to Prometheus.
- Deploy as DaemonSet on GPU nodes for per-GPU telemetry (utilization, memory, temperature).
