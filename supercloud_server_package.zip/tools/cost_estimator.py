# Simple cost estimator (very rough). Replace with current provider prices.
def estimate_aws_gpus(num_gpus, hours_per_month=24*30, price_per_gpu_hr=40.0):
    return num_gpus * hours_per_month * price_per_gpu_hr

if __name__=='__main__':
    num_gpus = 64
    est = estimate_aws_gpus(num_gpus)
    print(f'Estimated monthly GPU cost for {num_gpus} GPUs: ${est:,.2f}')
