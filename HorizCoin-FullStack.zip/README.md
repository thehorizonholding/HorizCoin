HorizCoin - Full Stack Package (Blockchain + Tokenomics + DePIN + AI)
===================================================================

This package contains a developer-ready scaffold for HorizCoin:
- Solidity contracts (Data registry, ERC1155 data tokens, PoB verifier, TokenizedFiat, ConversionOracle)
- Hardhat deploy scripts and example deployer
- Backend off-chain services: deploy_and_interact.py, indexer, swap helpers
- AI Integration Layer (orchestrator, valuation models, RL scheduler)
- DePIN connectors (Hivemapper, Filecoin) and ingestion pipeline examples
- Docker and docker-compose for local dev
- .env.example and docs

This is a developer scaffold and **not** production-ready. Security, audits, KYC/AML, and legal review are required for any real-money operations.
