HorizCoin AI Integration Layer - Implementation Plan (Summary)
--------------------------------------------------------------

This directory contains the detailed technical implementation plan for the AI Integration Layer.
Refer to the full manual in the main project docs for context.

Key components:
- Orchestrator (CrewAI): plans workflows and suggests actions (mocked here).
- RL Scheduler (PPO): learns task scheduling policies to prioritize complex tasks.
- Valuation Model: PyTorch skeleton for predicting data asset value.
- Connectors: Example ingestion connectors for DePINs (Hivemapper, Filecoin).
- MLOps pointers: feature store, model registry, training pipeline suggestions.

Follow the README for quickstart instructions. The code here is intentionally modular so it can be integrated into your existing HorizCoin repo.
