Runbook - AI Integration (dev)

1. Setup venv and install requirements:
   python3 -m venv .venv && source .venv/bin/activate
   pip install -r ai_integration/requirements.txt

2. Start model API (mock):
   uvicorn ai_integration.api:app --reload --port 9001 &

3. Start mock connectors:
   python ai_integration/connectors/hivemapper_connector.py &
   python ai_integration/connectors/filecoin_connector.py &

4. Start orchestrator:
   uvicorn ai_integration.orchestrator_server:app --reload --port 8002 &

5. Trigger a workflow:
   curl -X POST http://localhost:8002/trigger -H 'Content-Type: application/json' -d '{ "trigger_type": "asset_register", "payload": {"asset":"asset-xyz","owner":"0xabc"}}'
