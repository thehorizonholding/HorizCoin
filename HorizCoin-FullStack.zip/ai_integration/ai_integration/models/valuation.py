import torch
import torch.nn as nn
import torch.nn.functional as F

class ValuationNet(nn.Module):
    def __init__(self, input_dim, hidden=256):
        super().__init__()
        self.fc1 = nn.Linear(input_dim, hidden)
        self.fc2 = nn.Linear(hidden, hidden//2)
        self.out = nn.Linear(hidden//2, 1)
    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        val = self.out(x)
        return val

# Simple inference helper
def infer_value(model, features_tensor):
    model.eval()
    with torch.no_grad():
        out = model(features_tensor)
    return out.squeeze().item()
