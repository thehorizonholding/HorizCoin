from fastapi import FastAPI
from pydantic import BaseModel
import random

app = FastAPI(title='HorizCoin Valuation API (Mock)')

class InferReq(BaseModel):
    model: str
    asset: str

@app.post('/infer')
def infer(req: InferReq):
    # Mock response: value and confidence
    return {'asset': req.asset, 'model': req.model, 'value': round(random.random() * 100, 4), 'confidence': 0.75}

@app.get('/health')
def health():
    return {'ok': True}
