from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import uuid, json, os
from ai_integration.crew_tools import CrewClient, ToolClients
from ai_integration.scheduler_client import SchedulerClient

app = FastAPI(title="HorizCoin AI Orchestrator (Mock)")

crew = CrewClient()
tools = ToolClients()
scheduler = SchedulerClient()

class Trigger(BaseModel):
    trigger_type: str
    payload: dict

@app.post('/trigger')
def trigger_workflow(t: Trigger):
    # Ask CrewAI to propose a plan
    plan = crew.plan_workflow(t.trigger_type, t.payload)
    plan_id = str(uuid.uuid4())
    # Save plan for audit
    os.makedirs('/tmp/horiz_plans', exist_ok=True)
    with open(f'/tmp/horiz_plans/{plan_id}.json', 'w') as f:
        json.dump(plan, f, indent=2)
    # Rank tasks using scheduler
    ordered = scheduler.rank_tasks(plan)
    results = []
    for step in ordered:
        if step.get('sensitive'):
            results.append({'step': step['id'], 'status': 'awaiting_confirmation'})
            continue
        tool = step.get('tool')
        res = tools.exec(tool, step.get('params', {}))
        results.append({'step': step['id'], 'status': 'ok', 'result': res})
    return {'plan_id': plan_id, 'results': results, 'ordered': ordered}
