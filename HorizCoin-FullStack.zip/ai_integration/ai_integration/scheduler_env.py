import gym
from gym import spaces
import numpy as np

class HorizSchedulerEnv(gym.Env):
    def __init__(self, config=None):
        super().__init__()
        self.max_tasks = 32
        obs_dim = self.max_tasks * 3 + 10
        self.observation_space = spaces.Box(low=0, high=1, shape=(obs_dim,), dtype=np.float32)
        self.action_space = spaces.Discrete(self.max_tasks)
        self.reset()
    def reset(self):
        self.tasks = []
        return self._get_obs()
    def _get_obs(self):
        return np.zeros(self.observation_space.shape, dtype=np.float32)
    def step(self, action):
        # Simulate task execution reward
        reward = 0.0
        done = False
        info = {}
        return self._get_obs(), reward, done, info
