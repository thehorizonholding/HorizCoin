import os, json, requests, time

class CrewClient:
    def __init__(self):
        self.provider = os.getenv('LLM_PROVIDER', 'mock')
    def plan_workflow(self, trigger_type, payload):
        if self.provider == 'mock':
            # Deterministic simple plan
            return {
                'trigger': trigger_type,
                'steps': [
                    {'id': 'feat-1', 'tool': 'model', 'cmd':'infer', 'params':{'model':'valuation','asset': payload.get('asset')}, 'sensitive': False},
                    {'id': 'mint-1', 'tool': 'onchain', 'cmd':'mint', 'params':{'to': payload.get('owner'), 'amount': 100}, 'sensitive': True}
                ]
            }
        # Placeholder for real CrewAI/LLM integration
        raise NotImplementedError('CrewAI integration not configured')

class ToolClients:
    def __init__(self):
        pass
    def exec(self, toolname, params):
        if toolname == 'model':
            try:
                r = requests.post('http://localhost:9001/infer', json=params, timeout=10)
                return r.json()
            except Exception as e:
                return {'error': 'model_call_failed', 'exc': str(e)}
        if toolname == 'onchain':
            # Queue or simulate on-chain action; require multisig in prod
            return {'ok': 'queued', 'params': params}
        return {'error': 'unknown_tool'}
