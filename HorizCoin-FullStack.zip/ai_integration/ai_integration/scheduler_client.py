import os, json

class SchedulerClient:
    def __init__(self, policy_path=None):
        self.policy_path = policy_path or os.getenv('SCHEDULER_POLICY','./ai_integration/policies/mock_policy.json')
    def rank_tasks(self, plan):
        # Simple ordering: put non-sensitive first
        steps = plan.get('steps', [])
        ordered = sorted(steps, key=lambda s: (1 if s.get('sensitive') else 0, ))
        return ordered
