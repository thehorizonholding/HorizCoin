from stable_baselines3 import PPO
from ai_integration.scheduler_env import HorizSchedulerEnv

def train(total_timesteps=100000):
    env = HorizSchedulerEnv()
    model = PPO('MlpPolicy', env, verbose=1)
    model.learn(total_timesteps=total_timesteps)
    model.save('ai_integration/policies/scheduler_ppo')

if __name__ == '__main__':
    train(20000)
