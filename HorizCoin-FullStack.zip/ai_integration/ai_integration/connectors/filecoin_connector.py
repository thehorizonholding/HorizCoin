import time, requests, os
API_BASE = os.getenv('FILECOIN_API','https://api.node.glif.io')

def fetch_deals():
    # placeholder for Filecoin API interactions
    return []

if __name__ == '__main__':
    while True:
        deals = fetch_deals()
        print('deals', len(deals))
        time.sleep(60)
