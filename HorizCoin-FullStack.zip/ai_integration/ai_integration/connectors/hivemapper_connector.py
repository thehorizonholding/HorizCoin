import os, time, requests
API_BASE = os.getenv('HIVEMAPPER_URL','https://api.hivemapper.com')
API_KEY = os.getenv('HIVEMAPPER_KEY','')

def fetch_recent(since_ts):
    headers = {'Authorization': f'Bearer {API_KEY}'}
    try:
        r = requests.get(API_BASE + '/v1/recent-tiles', params={'since': since_ts}, headers=headers, timeout=20)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        print('hivemapper fetch error', e)
        return []

if __name__ == '__main__':
    last = int(time.time()) - 3600
    while True:
        data = fetch_recent(last)
        print('fetched', len(data))
        last = int(time.time())
        time.sleep(60)
