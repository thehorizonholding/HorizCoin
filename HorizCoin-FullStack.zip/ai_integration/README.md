HorizCoin AI Integration Layer
==============================

This package contains the AI Integration Layer for HorizCoin: orchestration templates, RL scheduler, valuation model skeletons,
connectors for DePIN sources, API server templates, and dev/run instructions for macOS/Linux.

Contents (AI-only):
- ai_integration/
  - orchestrator_server.py       # FastAPI orchestrator (CrewAI wrapper + scheduler)
  - crew_tools.py                # CrewAI wrapper (mock + adapter hooks)
  - scheduler_env.py             # Gym environment for RL scheduler
  - scheduler_train.py           # Training script (Stable-Baselines3 PPO example)
  - scheduler_client.py          # Inference client for trained scheduler policy
  - models/valuation.py          # PyTorch valuation model skeleton
  - connectors/                  # Example DePIN connectors (hivemapper, filecoin)
  - api.py                       # Simple API endpoints for valuation & quotes
  - requirements.txt             # Python deps
- docker/                        # Dockerfiles and compose for dev
- docs/                          # Design docs and runbook

Security: This code is a developer scaffold and contains mock providers by default. DO NOT add real API keys to this repo. Use environment variables and secrets management for production.

Quickstart (macOS):
1. python3 -m venv .venv && source .venv/bin/activate
2. pip install -r ai_integration/requirements.txt
3. Start mock connectors: python ai_integration/connectors/hivemapper_connector.py &
4. Start model API: uvicorn ai_integration.api:app --reload --port 9001 &
5. Start orchestrator: uvicorn ai_integration.orchestrator_server:app --reload --port 8002 &

See docs/IMPLEMENTATION_PLAN.md for the full technical plan.
