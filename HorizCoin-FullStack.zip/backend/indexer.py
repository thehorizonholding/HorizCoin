import os, json, sqlite3, time
from web3 import Web3
from dotenv import load_dotenv
load_dotenv()
RPC_URL = os.getenv('RPC_URL','http://127.0.0.1:8545')
DB = os.getenv('DATABASE_URL','sqlite:///./horizcoin.db').replace('sqlite:///','')
ARTIFACT = 'contract_artifacts.json'
ADDRESS = 'contract_address.txt'
def setup_db():
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS datarecords (record_id INTEGER PRIMARY KEY, owner TEXT, data_hash TEXT, timestamp INTEGER, tx_hash TEXT)''')
    conn.commit()
    return conn
def main():
    if not os.path.exists(ARTIFACT) or not os.path.exists(ADDRESS):
        raise SystemExit('Deploy artifacts missing. Run deploy script first.')
    with open(ARTIFACT,'r') as f: abi = json.load(f)['abi']
    with open(ADDRESS,'r') as f: addr = f.read().strip()
    w3 = Web3(Web3.HTTPProvider(RPC_URL))
    contract = w3.eth.contract(address=addr, abi=abi)
    conn = setup_db()
    print('Indexer started, listening...')
    try:
        while True:
            # poll latest events (simple)
            # In production use websocket and proper filters
            events = contract.events.NewRecord().getLogs(fromBlock='latest', toBlock='latest')
            for ev in events:
                args = ev['args']
                tx = ev['transactionHash'].hex()
                print('event', args)
                try:
                    conn.execute('INSERT INTO datarecords (record_id, owner, data_hash, timestamp, tx_hash) VALUES (?,?,?,?,?)', (args['recordId'], args['owner'], args['offChainDataHash'], args['timestamp'], tx))
                    conn.commit()
                except Exception as e:
                    print('insert err', e)
            time.sleep(5)
    except KeyboardInterrupt:
        conn.close()
if __name__ == '__main__':
    main()
