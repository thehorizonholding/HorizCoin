import requests, os
# Placeholder swap helper (use 1inch or other in prod)
COINGECKO = 'https://api.coingecko.com/api/v3/simple/price'
def quote(hzc_amount):
    # Mock: assume 1 HZC => $1
    return {'hzc': hzc_amount, 'usd': hzc_amount * 1.0, 'route':'mock' }
