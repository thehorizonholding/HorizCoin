# Pulumi sample: create a single EC2 (conceptual)
import pulumi
import pulumi_aws as aws
config = pulumi.Config()
instance = aws.ec2.Instance('horiz-node', instance_type='t3.medium', ami='ami-0c55b159cbfafe1f0')
pulumi.export('ip', instance.public_ip)
