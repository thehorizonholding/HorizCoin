See the Implementation & Operations Manual (full) included in previous package sections.
This package contains the AI integration layer and blockchain scaffolding to integrate with the full HorizCoin platform.
Follow the README and docs/ for step-by-step setup.
