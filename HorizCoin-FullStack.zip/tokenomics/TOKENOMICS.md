HorizCoin Tokenomics (Summary)
------------------------------

- Total Supply: 10,000,000,000 HZC (example)
- Allocation:
  - Foundation & Treasury: 30%
  - Ecosystem Grants & Partnerships: 20%
  - Team & Advisors (4-year vesting): 15%
  - Community & Airdrops: 10%
  - Mining/Validators rewards: 25% (PoB/PoS hybrid)
- Emission schedule: inflationary for first 5 years, then gradual reduction
- Utility:
  - Pay for data valuation fees
  - Stake for bandwidth/validator roles
  - Governance voting (future DAO)
- Conversion:
  - On-chain conversion uses ConversionOracle + off-chain DEX aggregation for swaps
