import os, json, time
from web3 import Web3
from solcx import compile_source, install_solc
from dotenv import load_dotenv
load_dotenv()
RPC_URL = os.getenv('RPC_URL','http://127.0.0.1:8545')
PRIVATE_KEY = os.getenv('PRIVATE_KEY','')
COMPILED = 'contract_artifacts.json'
ADDRESS_FILE = 'contract_address.txt'
def compile_contract(path):
    install_solc('0.8.19')
    with open(path,'r') as f:
        src = f.read()
    compiled = compile_source(src, output_values=['abi','bin'])
    return compiled
def deploy_simple(sol_path, contract_name):
    w3 = Web3(Web3.HTTPProvider(RPC_URL))
    acct = w3.eth.account.from_key(PRIVATE_KEY)
    compiled = compile_contract(sol_path)
    contract_id = list(compiled.keys())[0]
    abi = compiled[contract_id]['abi']
    bytecode = compiled[contract_id]['bin']
    Contract = w3.eth.contract(abi=abi, bytecode=bytecode)
    tx = Contract.constructor().build_transaction({'from':acct.address,'nonce':w3.eth.get_transaction_count(acct.address),'gas':3000000,'gasPrice':w3.eth.gas_price})
    signed = acct.sign_transaction(tx)
    txh = w3.eth.send_raw_transaction(signed.rawTransaction)
    print('sent', txh.hex())
    r = w3.eth.wait_for_transaction_receipt(txh)
    print('deployed at', r.contractAddress)
    return abi, r.contractAddress
if __name__ == '__main__':
    # Deploy DataRegistry as an example
    abi, addr = deploy_simple('contracts/DataRegistry.sol','DataRegistry')
    with open(COMPILED,'w') as f: json.dump({'abi':abi},f)
    with open(ADDRESS_FILE,'w') as f: f.write(addr)
    print('done')
