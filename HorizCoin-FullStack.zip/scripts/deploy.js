const hre = require("hardhat");
async function main() {
  const [deployer] = await hre.ethers.getSigners();
  console.log("Deploying from:", deployer.address);
  const DataToken = await hre.ethers.getContractFactory("HorizCoinDataToken");
  const dataToken = await DataToken.deploy("https://metadata.horizcoin.io/{id}.json");
  await dataToken.deployed();
  console.log("DataToken:", dataToken.address);
  const PoB = await hre.ethers.getContractFactory("PoBVerifier");
  const pob = await PoB.deploy();
  await pob.deployed();
  console.log("PoBVerifier:", pob.address);
  const Token = await hre.ethers.getContractFactory("TokenizedFiat");
  const token = await Token.deploy("HorizCoin USD", "HZC-USD");
  await token.deployed();
  console.log("TokenizedFiat:", token.address);
  const Oracle = await hre.ethers.getContractFactory("DataRegistry");
  const oracle = await Oracle.deploy();
  await oracle.deployed();
  console.log("DataRegistry:", oracle.address);
}
main().catch(console.error);
