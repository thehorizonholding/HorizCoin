DePIN Connectors
----------------
This folder contains example connectors for DePIN sources like Hivemapper and Filecoin.
See ai_integration/connectors for runnable connector examples.
