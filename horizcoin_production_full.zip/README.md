# HorizCoin — Production Skeleton Bundle

This archive is a production-ready **skeleton** for the HorizCoin project. It contains:
- Solidity contracts (ERC-1155 marketplace, DataNFT + Datatoken)
- Backend API (FastAPI) and Dockerfile
- Oracle engine (Node.js) with job runner
- Kubernetes manifests (example)
- CI (GitHub Actions) workflow for build & release
- Security checklist and deployment guidance

**Important**: This is a scaffold. Replace placeholders and secret values with your real code and credentials before deploying to production.
