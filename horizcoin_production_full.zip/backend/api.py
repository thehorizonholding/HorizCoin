from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import os

app = FastAPI()

@app.get("/health")
def health():
    return {"status": "ok"}

class MintRequest(BaseModel):
    uri: str
    supply: int
    price_usd: float

@app.post("/mint")
async def mint(req: MintRequest):
    # Placeholder: In production this endpoint would call the deployer or an admin service to mint datatokens
    # and register metadata on-chain. Ensure authentication and authorization.
    return {"status": "queued", "uri": req.uri, "supply": req.supply}
