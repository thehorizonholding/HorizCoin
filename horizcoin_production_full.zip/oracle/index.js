/*
Oracle engine skeleton for production use.
Security notes:
- In production, run this inside k8s with limited RBAC and secrets from Vault.
- Jobs should be executed in sandboxed containers or WASM to avoid code injection.
*/
const { ethers } = require("ethers");
const fs = require("fs");
const JOB_DIR = "/app/jobs";

async function main() {
  const provider = new ethers.providers.JsonRpcProvider(process.env.ETH_RPC_URL);
  const wallet = new ethers.Wallet(process.env.ORACLE_PRIVATE_KEY, provider);
  const consumerAbi = JSON.parse(fs.readFileSync('/app/consumer_abi.json'));
  const consumerAddr = process.env.CONSUMER_CONTRACT_ADDRESS;
  const contract = new ethers.Contract(consumerAddr, consumerAbi, wallet);

  console.log("Oracle engine started...");
  // Example: listen for OracleRequest event (consumer contract must emit)
  contract.on("OracleRequest", async (requestId, jobName, requester) => {
    try {
      console.log("Request", requestId.toString(), jobName);
      const jobPath = `${JOB_DIR}/${jobName}.js`;
      if (!fs.existsSync(jobPath)) {
        console.error("Job not found:", jobPath);
        return;
      }
      const jobModule = require(jobPath);
      const result = await jobModule.run({ requestId: requestId.toString(), requester });
      // Simplified: call fulfill function on consumer contract
      const tx = await contract.fulfillRequest(requestId, result);
      await tx.wait();
      console.log("Fulfilled", requestId.toString());
    } catch (err) {
      console.error("Job failed", err);
    }
  });
}

main().catch(e => { console.error(e); process.exit(1); });
