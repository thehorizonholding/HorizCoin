# Production Security Checklist

- [ ] Use Vault or cloud KMS for all secrets; do NOT store secrets in repo.
- [ ] Use HSM signing for high-value keys when possible.
- [ ] Run Slither + MythX + Echidna on smart contracts in CI.
- [ ] Run Trivy on container images and fail CI on critical vulns.
- [ ] Use network policies and RBAC in Kubernetes.
- [ ] Monitor with Prometheus/Grafana and alerting.
- [ ] Third-party audit: ConsenSys Diligence / Trail of Bits / OpenZeppelin.
- [ ] Penetration test and SRE runbook.
