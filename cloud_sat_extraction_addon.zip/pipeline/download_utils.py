# pipeline/download_utils.py - small helpers for safe downloads and verification (dry-run)
import os, hashlib, time
def ensure_dir(path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
def write_placeholder(path, size=0):
    ensure_dir(path)
    with open(path,'wb') as f:
        f.write(b'')

def checksum(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        while True:
            b=f.read(8192)
            if not b: break
            h.update(b)
    return h.hexdigest()

