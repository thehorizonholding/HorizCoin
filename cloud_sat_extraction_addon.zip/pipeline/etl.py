# pipeline/etl.py - placeholder ETL transforms (NDVI sim, convert to parquet)
import os, json, time
def compute_ndvi_stub(path):
    # simulate processing time and output
    time.sleep(0.1)
    return {'path': path, 'ndvi_mean':0.42, 'ndvi_median':0.39}

def convert_to_parquet_stub(src, dest):
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    with open(dest,'w') as f:
        json.dump({'src':src,'note':'parquet-simulated'}, f)

