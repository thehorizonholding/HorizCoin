# Operational Runbook (dry-run-first)

- Simulation: run `python controller/orchestrator.py --simulate --config examples/sample_config.yaml`
- Real run prerequisites:
  - Store provider credentials in Vault or cloud secret manager
  - Ensure billing alerts and spending caps configured
  - Apply provider ToS review for resale/aggregation
- Bandwidth tips:
  - Use multipart downloads and resume support (rclone or SDK multipart)
  - Use regional storage buckets close to sources to reduce egress
  - Apply lifecycle rules and compression (zstd/parquet)
