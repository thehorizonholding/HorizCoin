# Legal & Compliance Checklist

- Confirm data license for each dataset (public, paid, restricted).
- Do NOT ingest private third-party data without explicit consent.
- Maintain audit logs for every download and access (who, when, why).
- Use KYC and contracts for customers purchasing derived data products.
- Respect export controls, sanctions, and privacy laws (GDPR, CCPA).
