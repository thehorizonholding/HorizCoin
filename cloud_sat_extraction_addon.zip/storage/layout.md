# Recommended Centralized Storage Layout (single folder)

/data_central/
├── raw/                    # raw files as downloaded (preserve original filenames)
│   ├── aws/                # AWS downloads, by bucket and prefix
│   ├── gcp/                # GCP downloads, by bucket
│   ├── alibaba/            # Alibaba datasets
│   └── satellite/          # satellite scenes (Sentinel, Landsat) metadata + files
├── manifests/              # JSON/YAML manifests for each ingest run
├── processed/              # post-ETL outputs (parquet, ndvi, csv)
├── logs/                   # orchestrator and pipeline logs
└── tmp/                    # temporary files and partial downloads

Keep `raw/` immutable; use `processed/` for downstream consumers. Enforce retention & lifecycle policies.
