# connectors/alibaba_stub.py - stub for Alibaba OSS
def list_oss_objects(bucket, prefix):
    return [{'key':'a1.tif','size':1234},{'key':'a2.tif','size':5678}]
def download_oss_object(bucket, key, dest):
    with open(dest,'wb') as f:
        f.write(b'')

