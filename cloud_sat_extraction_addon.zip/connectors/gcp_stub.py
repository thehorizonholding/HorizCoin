# connectors/gcp_stub.py - stub for GCS listing & download
def list_gcs_objects(bucket, prefix):
    return [{'name':'sceneA.tif','size':4096},{'name':'sceneB.tif','size':8192}]
def download_gcs_object(bucket, name, dest):
    with open(dest,'wb') as f:
        f.write(b'')

