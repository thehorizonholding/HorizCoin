# connectors/aws_stub.py - stub for AWS S3 listing & download
# Replace with real boto3 implementation when enabling real runs.
def list_s3_objects(bucket, prefix):
    return [{'Key':'scene1.tif','Size':1024,'ETag':'aaa'},{'Key':'scene2.tif','Size':2048,'ETag':'bbb'}]
def download_s3_object(bucket, key, dest):
    # implement boto3 download_fileobj(...) in production
    with open(dest,'wb') as f:
        f.write(b'')

