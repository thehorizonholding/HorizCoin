# connectors/satellite_stub.py - stub for satellite public datasets (Sentinel/Landsat)
def search_sentinel(query):
    return [{'id':'SENT-001','cloud':12,'size_mb':1500},{'id':'SENT-002','cloud':5,'size_mb':1200}]
def fetch_metadata(scene_id):
    return {'id':scene_id,'acquired':'2024-08-01','bands': ['B01','B02','B03']}

