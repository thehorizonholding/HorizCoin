#!/usr/bin/env python3
"""controller/orchestrator.py
Centralized orchestrator for dry-run and real ingestion of cloud + satellite data.
- Dry-run by default. Use --execute to attempt real downloads (requires secrets and approvals).
- Config-driven: YAML config specifies datasets, providers, and destinations.
- Enforces policy checks to block disallowed operations.
"""
from __future__ import annotations
import argparse, os, yaml, json, time, uuid
from dataclasses import dataclass, asdict
from typing import List, Dict, Any, Tuple

DISALLOWED = ['mine','mining','cryptominer','botnet','steal','exploit','coin','mint']

def contains_disallowed(text: str)->bool:
    t = (text or '').lower()
    return any(k in t for k in DISALLOWED)

@dataclass
class DatasetSpec:
    id: str
    provider: str
    source: str
    path: str
    type: str

@dataclass
class RunManifest:
    run_id: str
    created_at: int
    datasets: List[Dict[str,Any]]
    status: str

class ConnectorStub:
    def __init__(self, provider):
        self.provider = provider
    def list_objects(self, spec: DatasetSpec)->List[Dict[str,Any]]:
        # stub: in real implementation, list objects via SDK
        return [
            {'key':'sample1.bin', 'size':12345, 'etag':'abc', 'modified':int(time.time())},
            {'key':'sample2.bin', 'size':54321, 'etag':'def', 'modified':int(time.time())}
        ]
    def download_object(self, spec: DatasetSpec, object_meta:Dict[str,Any], dest_path:str)->Dict[str,Any]:
        # stub: simulate download time & create empty file
        time.sleep(0.1)
        os.makedirs(os.path.dirname(dest_path), exist_ok=True)
        with open(dest_path, 'wb') as f:
            f.write(b'')  # placeholder
        return {'path': dest_path, 'size': object_meta['size'], 'status':'ok'}

class Orchestrator:
    def __init__(self, cfg:Dict[str,Any], dry_run=True):
        self.cfg = cfg
        self.dry_run = dry_run
        self.connectors = {}
        for p in set([d['provider'] for d in cfg.get('datasets',[])]):
            self.connectors[p] = ConnectorStub(p)
    def run(self)->RunManifest:
        run_id = 'run-' + uuid.uuid4().hex[:8]
        manifest = RunManifest(run_id, int(time.time()), [], 'pending')
        base = self.cfg.get('storage_root','data_central')
        for d in self.cfg.get('datasets',[]):
            spec = DatasetSpec(id=d.get('id'), provider=d.get('provider'), source=d.get('source'), path=d.get('path'), type=d.get('type'))
            if contains_disallowed(json.dumps(asdict(spec))):
                manifest.status = 'blocked'
                manifest.datasets.append({'id':spec.id, 'status':'blocked', 'reason':'disallowed keywords'})
                continue
            connector = self.connectors.get(spec.provider)
            objs = connector.list_objects(spec)
            for o in objs:
                rel = os.path.join(base,'raw',spec.provider, spec.id, o['key'])
                manifest.datasets.append({'id':spec.id,'object':o['key'],'dest':rel,'status':'simulated' if self.dry_run else 'queued'})
                if not self.dry_run:
                    res = connector.download_object(spec,o,rel)
                    manifest.datasets[-1]['status'] = res.get('status')
                    manifest.datasets[-1]['path'] = res.get('path')
        manifest.status = 'completed' if any(ds['status']!='blocked' for ds in manifest.datasets) else 'failed'
        # write manifest
        os.makedirs(base, exist_ok=True)
        with open(os.path.join(base,'manifests', f"{run_id}.json"), 'w') as mf:
            json.dump(asdict(manifest), mf, indent=2)
        return manifest

def load_config(path:str)->Dict[str,Any]:
    with open(path) as f:
        return yaml.safe_load(f)

def main():
    parser = argparse.ArgumentParser(description='Cloud+Satellite Ingest Orchestrator (dry-run default)')
    parser.add_argument('--config', required=True, help='YAML config path')
    parser.add_argument('--simulate', action='store_true', help='Run in simulation mode (dry-run)')
    parser.add_argument('--execute', action='store_true', help='Execute real downloads (requires secrets & approval)')
    args = parser.parse_args()
    cfg = load_config(args.config)
    dry_run = args.simulate and not args.execute
    orch = Orchestrator(cfg, dry_run=dry_run)
    manifest = orch.run()
    print('Run manifest:')
    print(json.dumps(asdict(manifest), indent=2))

if __name__ == "__main__":
    main()
