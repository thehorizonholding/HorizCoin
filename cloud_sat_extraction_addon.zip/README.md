# Cloud & Satellite Extraction Add-on (Centralized Ingest)

This package provides a safe, legal, and dry-run-first scaffold to **ingest and centralize**
bandwidth-intensive datasets from multiple cloud providers and public satellite data sources
into a single folder/repository for processing.

**Important safety notes**
- Use only cloud/satellite accounts and data you are authorized to access.
- Never embed secrets in the repo. Use environment variables and a secrets manager (HashiCorp Vault, AWS Secrets Manager, GCP Secret Manager).
- This scaffold is **dry-run by default** and uses connector stubs. Replace stubs with real connectors only after security review.
- Mining, unauthorized data exfiltration, or accessing accounts you don't own is prohibited.

## What this package contains
- `controller/` : Orchestrator that schedules connectors and ETL pipelines (dry-run first)
- `connectors/` : Provider connector stubs for AWS, GCP, Alibaba, and Satellite (public datasets)
- `pipeline/` : ETL scripts (download, verify, transform) and storage layout helper
- `storage/layout.md` : recommended directory layout for centralized data
- `docs/` : operation runbook, bandwidth & cost considerations, legal checklist
- `.github/workflows/ci.yml` : dry-run CI to validate configs and run simulation
- `examples/` : example config files and sample metadata manifests

## Quick start (dry-run)
1. Inspect files and read docs/LEGAL.md and docs/ops_runbook.md
2. Create a feature branch in your repo and add this folder.
3. Run the orchestrator in simulate mode:
   ```bash
   python controller/orchestrator.py --simulate --config examples/sample_config.yaml
   ```
4. Once approved and secrets stored in Vault/Secrets Manager, implement and enable real connectors per provider.

## Support & Next steps
- I can generate provider-specific connector templates (boto3 for AWS, google-cloud-storage for GCP, aliyun-python-sdk for Alibaba) if you want — I will not include credentials or code that accesses accounts without authorization.
- I can add rclone / multipart transfer helpers and a Terraform template to provision storage buckets (dry-run templates).
