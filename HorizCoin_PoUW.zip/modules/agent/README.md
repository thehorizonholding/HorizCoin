Agent README

This agent is a minimal Python prototype demonstrating the expected behavior:
- Poll marketplace for work
- Execute workload in a sandbox
- Collect energy samples (OS or external meter)
- Submit signed results to verifier/marketplace

To progress to a production-quality agent:
- Replace `sample_energy()` with macOS powermetrics parsing or integrate a USB-C meter API
- Add cryptographic signing using an Ethereum-compatible private key
- Implement rate-limited retries, secure storage of keys, and sandboxing for workloads
