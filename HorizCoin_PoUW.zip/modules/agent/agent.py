# HorizCoin PoUW Agent (Python stub)
# -- This is a prototype agent that demonstrates the expected interfaces.
# -- Replace powermetrics stubs with real macOS powermetrics parsing or an external USB-C meter API.

import time
import json
import uuid
from datetime import datetime

# Configuration
AGENT_ID = str(uuid.uuid4())
JOB_POLL_INTERVAL = 10  # seconds (demo)

def sample_energy():
    # Stub: replace with powermetrics parsing or hardware meter reading.
    # Return sample as dict with timestamp and estimated_watts
    return {"ts": datetime.utcnow().isoformat() + 'Z', "watts": 25.0}

def fetch_job():
    # Stub: contact marketplace API to fetch work
    # For demo we simulate a job
    job = {"jobId": "demo-1", "task": "matrix-multiply", "duration_s": 30, "reward": 100}
    return job

def run_job(job):
    # Simulated CPU-bound job
    print(f"Agent {AGENT_ID} running job {job['jobId']}")
    start = time.time()
    # simple busy loop to simulate work
    total = 0
    while time.time() - start < job.get("duration_s", 5):
        for i in range(1000):
            total += i*i
    return {"jobId": job["jobId"], "resultHash": hex(total & 0xFFFFFFFF), "work": total}

def submit_result(job, result, energy_samples):
    payload = {
        "agentId": AGENT_ID,
        "jobId": job["jobId"],
        "result": result,
        "energy": energy_samples
    }
    # In production: sign payload with worker private key and POST to marketplace/verifier
    print("Submitting result (demo):")
    print(json.dumps(payload, indent=2))

def main_loop():
    while True:
        job = fetch_job()
        if job:
            energy_samples = []
            # sample before
            energy_samples.append(sample_energy())
            result = run_job(job)
            # sample after
            energy_samples.append(sample_energy())
            submit_result(job, result, energy_samples)
        time.sleep(JOB_POLL_INTERVAL)

if __name__ == '__main__':
    print("Starting HorizCoin PoUW Agent (demo).")
    try:
        main_loop()
    except KeyboardInterrupt:
        print("Agent stopped.")
