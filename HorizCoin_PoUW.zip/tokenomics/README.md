Tokenomics (starter notes)

- HZN token used as primary reward currency
- Supply model: capped or controlled minting by governance
- Rewards = task_payment + energy_bonus (optional)
- Reputation-adjusted payouts; staking required for higher-value tasks
