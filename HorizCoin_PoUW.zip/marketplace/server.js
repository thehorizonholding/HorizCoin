// Marketplace stub (Node.js + Express)
// Usage: `npm init -y && npm install express body-parser`
// Run: node server.js
const express = require('express');
const bodyParser = require('body-parser');

const app = express();
app.use(bodyParser.json());

let jobs = {};
let nextJobId = 1;

app.post('/postJob', (req, res) => {
  const { reward, task } = req.body;
  const jobId = nextJobId++;
  jobs[jobId] = { jobId, reward, task, open: true };
  res.json({ jobId });
});

app.get('/fetchJob', (req, res) => {
  // naive: return first open job
  for (const id in jobs) {
    if (jobs[id].open) {
      return res.json(jobs[id]);
    }
  }
  return res.status(404).json({ error: 'no job' });
});

app.post('/submitResult', (req, res) => {
  const { agentId, jobId, result } = req.body;
  if (!jobs[jobId]) return res.status(404).json({ error: 'job not found' });
  jobs[jobId].open = false;
  // In production: push to verifier/oracle, escrow release
  console.log('Result received for job', jobId, 'from agent', agentId);
  res.json({ status: 'accepted' });
});

app.listen(3000, () => console.log('Marketplace stub listening on :3000'));
