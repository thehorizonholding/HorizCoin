# Whitepaper Summary — PoUW for HorizCoin

## Executive Summary
This module implements a Proof-of-Useful-Work (PoUW) monetization path for personal devices.
Devices run useful compute, report verifiable outputs and energy telemetry, and receive HZN tokens
or stablecoin payouts via a job-market smart contract.

## Key Components
- Local agent: executes tasks, collects telemetry (OS metrics or external meter), signs results.
- Verifier/oracle: validates results (redundancy, cross-checks) and energy readings.
- Smart contracts: utility token (HZN) and job escrow/payout contract.
- Marketplace: posts jobs, price discovery, escrow.
- Dashboard: user-facing earnings, device reputation, telemetry.

## Security & Anti-Cheat
- Redundant execution & majority voting
- Hardware-backed metering recommended for high-assurance payouts
- Reputation + staking model to deter cheating

## Next steps
- Implement robust agent with macOS powermetrics integration and optional USB-C meter support.
- Implement verifier with optional zk/commit-reveal proofs for workloads that support succinct verification.
- Audit smart contracts and harden marketplace endpoints.
