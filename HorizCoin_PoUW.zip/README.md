# HorizCoin — PoUW Module (Project Scaffold)

This repository contains a PoUW (Proof-of-Useful-Work) integration scaffold for the HorizCoin project.
It provides a functional starting point to monetize computational energy consumption on personal devices
by selling useful compute and rewarding energy-backed tokens.

## Contents
- `contracts/` — Smart contracts (ERC-20 utility token + job market contract)
- `modules/agent/` — Local agent stub (Python) to fetch and execute jobs, record energy telemetry
- `marketplace/` — Marketplace stub (Node.js/Express) to post jobs and escrow payments
- `dashboard/` — Dashboard stub & README
- `docs/` — Whitepaper summary & design notes
- `LICENSE` — Apache-2.0 (recommended)

## How to use
1. Unzip the package.
2. Review `contracts/` and deploy to a testnet (e.g., Goerli) using Hardhat or Truffle.
3. Run the agent stub in `modules/agent/` and configure a meter or powermetrics source.
4. Start the marketplace server for an end-to-end local demo.

This scaffold is provided as a starting point. Detailed implementation, security hardening,
and production deployment are required before any real-value usage.
