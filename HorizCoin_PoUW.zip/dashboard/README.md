# Dashboard (stub)

This directory is a placeholder for a web dashboard that displays:
- Device telemetry (energy usage, temperature)
- Jobs completed and earnings
- Reputation score and staking controls

Recommended stack:
- React + Tailwind + Vite for frontend
- Connect to marketplace API for job & earnings data
- Wallet connect (MetaMask) for contract interactions
