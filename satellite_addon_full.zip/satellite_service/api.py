# satellite_service/api.py - safe API for satellite add-on
from flask import Flask, request, jsonify
import os, json, time, uuid
from typing import Dict, Any
app = Flask(__name__)

# Simple in-memory stores for demo
DATASETS = {}
PROCESSED = {}

# Policy blocklist to avoid misuse
BLOCKED = ['mine','mining','cryptominer','exploit','steal','coin','mint','botnet']

def contains_blocked(payload: str) -> bool:
    p = payload.lower()
    return any(b in p for b in BLOCKED)

@app.route('/health', methods=['GET'])
def health():
    return jsonify({'status':'ok','ts':int(time.time())})

@app.route('/datasets/register', methods=['POST'])
def register_dataset():
    body = request.get_json() or {}
    name = body.get('name')
    source = body.get('source')
    if not name or not source:
        return jsonify({'error':'name & source required'}), 400
    if contains_blocked(json.dumps(body)):
        return jsonify({'error':'payload contains blocked keywords'}), 400
    dsid = str(uuid.uuid4())
    DATASETS[dsid] = {'id':dsid,'name':name,'source':source,'registered_at':int(time.time()),'status':'registered'}
    return jsonify(DATASETS[dsid]), 201

@app.route('/ingest/simulate', methods=['POST'])
def ingest_simulate():
    body = request.get_json() or {}
    dsid = body.get('dataset_id')
    if not dsid or dsid not in DATASETS:
        return jsonify({'error':'dataset_id required and must be registered'}), 400
    # simulate ingestion metadata without downloading imagery
    run_id = str(uuid.uuid4())
    PROCESSED[run_id] = {'run_id':run_id,'dataset_id':dsid,'status':'simulated','records': 100,'ts':int(time.time())}
    return jsonify(PROCESSED[run_id]), 200

@app.route('/process/ndvi', methods=['POST'])
def process_ndvi():
    body = request.get_json() or {}
    run_id = body.get('run_id')
    if not run_id or run_id not in PROCESSED:
        return jsonify({'error':'run_id required'}), 400
    # simulate NDVI result (stats only)
    result = {'run_id':run_id,'ndvi_mean':0.42,'ndvi_median':0.39,'units':'index','ts':int(time.time())}
    PROCESSED[run_id]['ndvi'] = result
    return jsonify(result), 200

@app.route('/results/<run_id>', methods=['GET'])
def get_results(run_id):
    return jsonify(PROCESSED.get(run_id, {'error':'not found'}))

if __name__ == '__main__':
    port = int(os.getenv('PORT', '8090'))
    app.run(host='0.0.0.0', port=port)
