# Satellite Service (Add-on)

This microservice ingests satellite imagery (public datasets), performs light processing (NDVI, change detection),
and exposes APIs for querying processed results. It is designed as a **drop-in addon** with:

- collector/ : data ingestion stubs (NASA, ESA, AWS Open Data)
- processor/ : basic image processing utilities (NDVI, cloud masking stubs)
- api.py     : Flask API exposing endpoints (dry-run by default)
- requirements.txt : Python deps for the service

Important:
- By default the service simulates heavy operations to avoid large downloads and costs.
- Any real ingestion must be authorized and run in accounts you control.
