# processor.py - light processing stubs (NDVI, change detection)
def compute_ndvi(red_band, nir_band):
    # placeholder: returns simulated mean ndvi
    return {'mean': 0.42, 'median': 0.39}
def detect_change(baseline, current):
    return {'change_score': 0.12, 'areas_changed': 10}
