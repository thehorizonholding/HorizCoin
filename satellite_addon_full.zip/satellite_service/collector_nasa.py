# collector_nasa.py - stub for NASA Landsat/MODIS collector (dry-run)
# In production, use earthdata credentials and the appropriate APIs (e.g., USGS EarthExplorer, AWS public datasets)
def fetch_metadata(query):
    # returns simulated metadata for matching scenes
    return [{'scene_id':'LANDSAT_SIM_001','acquired':'2023-08-01','cloud_pct':12,'size_mb':1500}]
