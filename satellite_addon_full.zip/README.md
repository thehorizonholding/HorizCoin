# Satellite Data Add-on (Full)

This package is an **add-on** for the HorizCoin project. It adds legal, auditable satellite data
ingestion and analytics capabilities and is explicitly **non-destructive**: it does not modify
existing project settings. Drop it into your repo under a feature branch (e.g. `feat/satellite-addon`).

Contents:
- docs/                       : plans, datasets, and integration notes
- satellite_service/          : microservice skeleton (collector, processor, API)
- .github/workflows/          : CI for dry-run tests
- LICENSE, CODEOWNERS, .gitignore

Safety & compliance:
- Uses public/open datasets by default (NASA, ESA, NOAA) unless you integrate paid providers.
- Blocks any requests or processing that mention disallowed activity (mining, exploitation).
- Requires secrets (API keys) to be stored in Vault or environment and NOT committed.
- All execution is dry-run by default; replace connectors only for accounts you own and with legal sign-off.
