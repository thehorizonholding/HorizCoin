# Datasets & Access Notes

- Landsat/Sentinel are free but require correct attribution and following terms of use.
- AWS hosts many public datasets; consider using AWS S3 with lifecycle policies.
- For high-frequency or high-resolution commercial imagery, negotiate licenses and delivery SLAs.
- For carbon/verification products, ensure compatibility with standards (Verra, Gold Standard).
