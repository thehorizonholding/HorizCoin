# Satellite Data Add-on Plan

## Purpose
Add satellite data ingestion, processing, and analytics to HorizCoin as an additive module.
Focus areas: EO imagery ingestion, time-series analytics, vegetation/agriculture indices, disaster detection,
and carbon/land-use monitoring for monetizable analytics products.

## Design Principles
- **Non-invasive**: no edits to existing core repo files.
- **Dry-run by default**: external downloads and paid API calls simulated unless explicitly enabled.
- **Privacy & legal first**: follow data licenses, no PII processing, and require contractual agreements for paid data.
- **Audit & provenance**: sign datasets & processing runs with KMS and store provenance metadata.

## Data Sources (examples)
- NASA: Landsat, MODIS (open data)

- ESA: Sentinel-1 (radar), Sentinel-2 (optical) via Copernicus Open Access Hub

- NOAA: weather and environmental datasets
- AWS Open Data Program: public satellite datasets (S3)

- Commercial providers: Maxar, Airbus (paid; require licensing)

## Monetizable Products
- Crop health and yield forecasts (subscription)
- Flood and disaster rapid assessment (per-event fees)
- Carbon/land-use verification for carbon credits
- Ship/traffic analytics for logistics partners
- Custom analytics & consulting

## Deployment Notes
- Use separate cloud storage buckets for raw & processed data per environment (staging/production).
- Use Kubernetes or batch workers for heavy processing; tie into existing AI orchestrator for job scheduling.
- Store credentials in Vault; never commit keys.
- Require legal & compliance approvals before selling/contracting services.

## Next steps
1. Add the `satellite_service` to a feature branch.

2. Test ingestion using public datasets (dry-run).

3. Build models for analytics and backtest.
4. Contract with customers and set up billing & KYC for monetization.
