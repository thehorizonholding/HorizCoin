const express=require('express');const app=express();app.use(express.json());
const approvals={};
app.post('/request',(req,res)=>{const token='tok-'+Date.now();approvals[token]={granted:false,meta:req.body};res.json({token});});
app.post('/approve',(req,res)=>{const t=req.body.token;approvals[t].granted=true;res.json({ok:true});});
app.get('/status/:token',(req,res)=>{res.json(approvals[req.params.token]||{});});
app.listen(4000,()=>console.log('Approval backend demo on 4000'));
