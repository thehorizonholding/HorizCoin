def check(action, meta):
    if action=='monetize_network' and not meta.get('provider_contract'):
        return False
    if action=='deploy_mainnet' and not meta.get('audited'):
        return False
    return True
