Deployment runbook (summary):
- Ensure legal & audit signoff
- Ensure approval tokens and multisig readiness
- Deploy to staging then do canary tests
- Only after approvals, deploy to production
