from flask import Flask, request, jsonify
app=Flask(__name__)

def score_meta(meta):
    prov=meta.get('provenance_score',0.5)
    excl=meta.get('exclusivity',0)
    usage=min(meta.get('usage_count',0),1000)/1000.0
    recency=max(0,1-(meta.get('recency_days',30)/365.0))
    comp=meta.get('compliance_score',0.5)
    s=int(max(0,min(1000,(prov*0.25+excl*0.2+usage*0.3+recency*0.15+comp*0.1)*1000)))
    return s

@app.route('/score',methods=['POST'])
def score():
    data=request.get_json() or {}
    s=score_meta(data.get('meta',{}))
    return jsonify({'dataset_id':data.get('dataset_id'),'score':s})

if __name__=='__main__':
    app.run(host='0.0.0.0',port=8300)
