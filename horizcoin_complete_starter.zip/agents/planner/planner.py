import sys, json
from audit.auditor import audit_append

def plan(prompt):
    tasks=[{'id':'t1','title':'scaffold backend','type':'dev'},{'id':'t2','title':'create contract','type':'sc'}]
    audit_append({'action':'plan_generated','prompt':prompt,'tasks':tasks})
    print(json.dumps({'tasks':tasks},indent=2))

if __name__=='__main__':
    p=open(sys.argv[1]).read() if len(sys.argv)>1 else 'demo'
    plan(p)
