async function main(){
  const [deployer]=await ethers.getSigners();
  console.log('deploying',deployer.address);
  const DataNFT=await ethers.getContractFactory('DataNFT');
  const nft=await DataNFT.deploy();
  await nft.deployed();
  console.log('DataNFT:', nft.address);
}
main().catch(e=>{console.error(e);process.exit(1)});
