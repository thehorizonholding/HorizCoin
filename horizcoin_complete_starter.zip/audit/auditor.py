import os,json,time,hmac,hashlib
AUDIT_DIR=os.environ.get('AUDIT_DIR','./audit_logs')
SECRET=os.environ.get('AUDIT_HMAC_SECRET','demo')
os.makedirs(AUDIT_DIR,exist_ok=True)
def audit_append(record):
    record['ts']=int(time.time())
    raw=json.dumps(record,sort_keys=True,ensure_ascii=False)
    sig=hmac.new(SECRET.encode(),raw.encode(),hashlib.sha256).hexdigest()
    fn=f"audit_{record['ts']}_{hashlib.sha256(raw.encode()).hexdigest()[:8]}.json"
    with open(os.path.join(AUDIT_DIR,fn),'w',encoding='utf-8') as f:
        json.dump({'record':record,'sig':sig},f,indent=2)
    print('[AUDIT] wrote',fn)
