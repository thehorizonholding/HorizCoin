Policy examples (OPA) - README
------------------------------
Includes a simple Rego policy example and a Python wrapper that performs a lightweight check.
In production, run OPA server and query it from agents.
