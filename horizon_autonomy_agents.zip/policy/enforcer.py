# simple policy enforcer (demo) that loads rego text and checks minimal rules
import json, re, subprocess, os
def check_policy(obj):
    # naive check: if playbook contains monetize_network and meta.has_contract false -> reject
    s = json.dumps(obj)
    if 'monetize_network' in s and ('has_contract' in s and 'false' in s):
        print('policy reject: monetize without contract')
        return False
    return True
