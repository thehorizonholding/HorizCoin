# simple orchestration worker (demo, no external dependencies required)
import time, json, os, subprocess
from audit.auditor import audit_append

TASKS_DIR = os.environ.get('TASKS_DIR','./tasks')

def poll_and_dispatch():
    while True:
        for fn in os.listdir(TASKS_DIR):
            if not fn.endswith('.json'): continue
            path = os.path.join(TASKS_DIR, fn)
            try:
                task = json.load(open(path))
                audit_append({'action':'dispatch_task','task':task})
                ttype = task.get('type')
                if ttype == 'rca':
                    subprocess.run(f'python agents/rca/rca_agent.py {path}', shell=True)
                elif ttype == 'remediation':
                    tok = task.get('approval_token')
                    subprocess.run(f'python agents/remediation/runner.py agents/remediation/playbooks/{task.get("playbook")}.yaml {tok or ""}', shell=True)
                elif ttype == 'correction':
                    subprocess.run(f'python agents/correction/correction_agent.py {task.get("repo")} "{task.get("desc", "")}"', shell=True)
                else:
                    print('unknown task', ttype)
                os.unlink(path)
            except Exception as e:
                print('task failed', e)
        time.sleep(3)

if __name__=='__main__':
    os.makedirs('./tasks', exist_ok=True)
    print('Polling tasks dir ./tasks ... place JSON tasks there to simulate')
    poll_and_dispatch()
