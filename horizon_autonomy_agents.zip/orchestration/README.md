Orchestration Hub (demo)
------------------------
A simple Redis-based task queue stub is included. In production use Redis Streams, RabbitMQ, or Kafka.
The worker demonstrates consuming tasks and dispatching to local agent scripts.
