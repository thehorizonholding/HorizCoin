# resubmit_signed.py - demo stub
import sys, json, os
from audit.auditor import audit_append
def resubmit(file):
    data = json.load(open(file))
    # demo: print and audit
    audit_append({'action':'resubmit_signed','file':file,'data_summary':str(data)[:200]})
    print('Resubmitted (demo):', file)
if __name__=='__main__':
    if len(sys.argv) < 2:
        print('usage: resubmit_signed.py file.json')
    else:
        resubmit(sys.argv[1])
