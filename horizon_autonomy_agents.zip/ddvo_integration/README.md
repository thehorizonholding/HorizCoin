DDVO Integration - README
------------------------
Stubs to call local DDVO service and resubmit signed payloads to chain or to a relayer.
Replace with real signing (KMS/HSM) and DON integration for production.
