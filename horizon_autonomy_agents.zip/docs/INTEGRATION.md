Integration notes
-----------------
- Drop this folder under your monorepo (e.g., addons/autonomy_agents/)
- Configure environment variables for secrets (AUDIT_HMAC_SECRET, LLM_KEY)
- Replace HMAC auditor with KMS/HSM signing in production
- Hook orchestration worker to your real task queue (Redis Streams, RabbitMQ, Kafka)
- Ensure policy engine is hardened (deploy OPA and use rego rules)
- Use multi-sig / KMS approvals before enabling terraform apply or any monetization action
