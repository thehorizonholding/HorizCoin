Playbook authoring guidance
---------------------------
- Each playbook is a YAML file with id, title, risk, description and steps.
- Steps types: shell, script, check. For production add types: k8s, terraform, restore, db-migration.
- Include dry_run flags for risky steps and clear rollback instructions.
- Map each playbook to required approvals and required human roles.
