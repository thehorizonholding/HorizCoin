Remediation Agent - README
--------------------------
This module runs remediation playbooks (scripts) in a controlled sandbox. Playbooks are YAML files that
map an incident cause to a sequence of steps (dry-run, run, verify, rollback).

The runner enforces policy and requires an approval token for high-risk actions.
