# remediation runner - executes playbooks with policy checks and approval gating (demo)
import os, sys, yaml, json, subprocess, time
from policy.enforcer import check_policy
from approval_service.approval import verify_approval_token
from audit.auditor import audit_append

def run_step(step, dry=False):
    t = step.get('type')
    if t == 'shell':
        cmd = step.get('cmd')
        if dry or step.get('dry_run'):
            audit_append({'action':'dry_shell','cmd':cmd})
            print('[DRY]', cmd)
        else:
            audit_append({'action':'exec_shell','cmd':cmd})
            r = subprocess.run(cmd, shell=True, capture_output=True, text=True)
            print('return', r.returncode)
            return {'rc': r.returncode, 'stdout': r.stdout, 'stderr': r.stderr}
    elif t == 'script':
        script = step.get('script')
        audit_append({'action':'exec_script','script':script})
        # for demo, just echo
        print('[SCRIPT]', script)
        return {'rc':0}
    elif t == 'check':
        cmd = step.get('cmd')
        audit_append({'action':'exec_check','cmd':cmd})
        print('[CHECK]', cmd)
        return {'rc':0, 'ok': True}
    else:
        audit_append({'action':'unknown_step','step':step})
        print('unknown step', step)
        return {'rc':1}

def run_playbook(path, approval_token=None, allow_autorun=False):
    pb = yaml.safe_load(open(path))
    audit_append({'action':'playbook_run_request','id':pb.get('id'),'title':pb.get('title'),'approval_token':approval_token})
    # policy check
    if not check_policy(pb):
        raise RuntimeError('policy rejected playbook')
    # require approval for medium/high risk
    risk = pb.get('risk','low')
    if risk in ('medium','high') and not verify_approval_token(approval_token):
        raise RuntimeError('approval required for risk='+risk)
    results = []
    for step in pb.get('steps',[]):
        r = run_step(step)
        results.append(r)
    audit_append({'action':'playbook_run_result','id':pb.get('id'),'results':results})
    return results

if __name__=='__main__':
    if len(sys.argv) < 2:
        print('Usage: python runner.py playbook.yaml [approval_token]')
        sys.exit(1)
    token = sys.argv[2] if len(sys.argv) > 2 else None
    res = run_playbook(sys.argv[1], approval_token=token)
    print('done', res)
