Correction Agent - README
-------------------------
This scaffold demonstrates how to:
- reproduce a failing test case (local sandbox)
- ask an LLM to suggest a patch (demo stub)
- create a branch and PR skeleton (local git)
- attach test evidence and open a PR (manual merge policy)

Automated merges should only occur after human/CI approval.
