# correction_agent.py - suggests code fixes and creates PR skeletons (demo)
import os, sys, json, subprocess, tempfile, time
from audit.auditor import audit_append

def suggest_fix(failure_trace):
    # demo: returns a fake patch
    audit_append({'action':'suggest_fix','trace':failure_trace})
    return {'patch':'# apply fix\n', 'explanation':'Demo patch suggested by agent'}

def create_pr_skeleton(repo_dir, branch, patch, title):
    # make branch and patch file
    subprocess.run(f'git -C {repo_dir} checkout -b {branch}', shell=True)
    patch_file = os.path.join(repo_dir, 'AUTO_PATCH.md')
    with open(patch_file, 'w') as f:
        f.write(patch)
    subprocess.run(f'git -C {repo_dir} add {patch_file} && git -C {repo_dir} commit -m "{title}"', shell=True)
    audit_append({'action':'pr_skeleton_created','repo':repo_dir,'branch':branch,'patch_file':patch_file})
    print('PR skeleton created in branch', branch)
    return branch

if __name__=='__main__':
    if len(sys.argv) < 3:
        print('Usage: python correction_agent.py repo_dir "failure description"')
        sys.exit(1)
    repo = sys.argv[1]; desc = sys.argv[2]
    p = suggest_fix(desc)
    create_pr_skeleton(repo, f'auto/fix-{int(time.time())}', p['patch'], f'Auto-fix: {desc[:40]}')
