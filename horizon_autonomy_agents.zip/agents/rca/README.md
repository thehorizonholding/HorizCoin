RCA Agent (LLM-assisted) - README
--------------------------------
This agent receives an incident context (logs, traces, recent commits), calls an LLM (or uses local heuristics),
and returns ranked hypotheses of root cause with confidence scores and suggested actions.

For demo purposes it contains a simple Python script that accepts a JSON context and outputs hypotheses.
