# rca_agent.py - simple LLM-assisted RCA agent (demo)
import os, sys, json, time

LLM_KEY = os.environ.get('LLM_KEY','')
def simple_rca(context):
    # context: {alerts:[], logs:[], recent_commits:[], metrics:{}}
    # This demo uses heuristics; replace with LLM calls and parsers.
    reasons = []
    logs = '\n'.join(context.get('logs',[])[:50])
    if 'signature verification failed' in logs.lower():
        reasons.append({'cause':'oracle_signature_failure','confidence':0.9,'suggestion':'check provider key, resubmit signed telemetry'})
    if 'out of memory' in logs.lower() or context.get('metrics',{}).get('memory_rss',0) > 0.9:
        reasons.append({'cause':'oom','confidence':0.85,'suggestion':'increase memory, restart pod, investigate leak'})
    if not reasons:
        reasons.append({'cause':'unknown','confidence':0.4,'suggestion':'collect more traces and run deeper analysis'})
    return {'timestamp':int(time.time()), 'hypotheses':reasons}

if __name__=='__main__':
    if len(sys.argv) < 2:
        print('Usage: python rca_agent.py context.json')
        sys.exit(1)
    ctx = json.load(open(sys.argv[1]))
    out = simple_rca(ctx)
    print(json.dumps(out, indent=2))
