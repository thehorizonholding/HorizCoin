# Demo: fetch ddvo mock and on-chain value - simulate
import json, sys
ddvo = {'dataset':1,'score':850}
onchain = {'dataset':1,'value':830}
out = {'ddvo':ddvo,'onchain':onchain}
fn = sys.argv[2] if len(sys.argv) > 2 and sys.argv[1]=='--out' else '/tmp/ddvo_onchain.json'
json.dump(out, open(fn,'w'), indent=2)
print('wrote', fn)
