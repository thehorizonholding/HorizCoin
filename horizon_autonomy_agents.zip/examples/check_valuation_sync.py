import sys, json
data = json.load(open(sys.argv[1]))
ddvo = data.get('ddvo',{})
onchain = data.get('onchain',{})
diff = abs(ddvo.get('score',0) - onchain.get('value',0))
print('diff', diff)
if diff > 20:
    print('Not in sync')
    sys.exit(2)
print('In sync')
