# approval token simple service (in-memory demo)
import hashlib, time, json
_APPROVALS = {}
def request_approval(action, meta):
    token = hashlib.sha256(f"{action}|{json.dumps(meta)}|{time.time()}".encode()).hexdigest()
    _APPROVALS[token] = {'action':action,'meta':meta,'granted':False,'ts':int(time.time())}
    print('Requested approval token:', token)
    return token
def approve(token):
    if token in _APPROVALS:
        _APPROVALS[token]['granted'] = True
        print('Approved', token)
        return True
    print('Unknown token', token)
    return False
def verify_approval_token(token):
    return bool(_APPROVALS.get(token,{}).get('granted',False))
if __name__=='__main__':
    print('approval service demo. Use request_approval and approve(token) from python REPL.')