Approval Service - README
------------------------
Simple approval token service for demo. In production use multi-sig or KMS/HSM signed tokens.
