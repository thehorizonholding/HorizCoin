Auditor - README
----------------
Append-only auditor that writes signed JSON records to disk (HMAC demo).
In production, replace HMAC with KMS/HSM signing and push to immutable storage (S3 + Object Lock).
