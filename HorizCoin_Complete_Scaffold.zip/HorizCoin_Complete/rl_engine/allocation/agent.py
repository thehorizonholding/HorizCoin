from typing import List, Dict, Any
import random

class AllocationAgent:
    """Very simple placeholder allocation agent.

    Chooses a random available node.
    """

    def choose_node(self, nodes: List[Dict[str, Any]]) -> Dict[str, Any]:
        available = [n for n in nodes if n.get("status") == "online"]
        if not available:
            raise RuntimeError("No available nodes")
        return random.choice(available)
