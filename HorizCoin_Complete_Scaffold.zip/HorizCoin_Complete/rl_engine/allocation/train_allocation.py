def train():
    """Placeholder training for allocation agent."""
    print("Training allocation agent... (stub)")


if __name__ == "__main__":
    train()
