import time
import requests

CONTROL_CENTER_URL = "http://localhost:8000/api"

def main():
    node_address = "0xIOT_NODE"
    kind = "iot"

    requests.post(f"{CONTROL_CENTER_URL}/nodes/register", json={
        "address": node_address,
        "kind": kind,
    })

    print("IoT agent registered and running (stub).")
    while True:
        time.sleep(10)


if __name__ == "__main__":
    main()
