# Fleet Manager (Agents)

This directory contains **simple Python daemons** that simulate:

- GPU agents
- IoT agents
- Router agents

In production, you would likely implement these with more robust tooling (systemd, Docker, k8s).
