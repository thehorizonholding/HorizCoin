import time
import requests

CONTROL_CENTER_URL = "http://localhost:8000/api"

def main():
    node_address = "0xROUTER_NODE"
    kind = "router"

    requests.post(f"{CONTROL_CENTER_URL}/nodes/register", json={
        "address": node_address,
        "kind": kind,
    })

    print("Router agent registered and running (stub).")
    while True:
        time.sleep(8)


if __name__ == "__main__":
    main()
