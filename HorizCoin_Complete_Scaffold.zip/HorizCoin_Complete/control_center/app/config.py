from pydantic import BaseSettings

class Settings(BaseSettings):
    database_url: str = "sqlite:///./control_center.db"
    settlement_contract_address: str = "0x0000000000000000000000000000000000000000"
    chain_rpc_url: str = "http://localhost:8545"

    class Config:
        env_prefix = "HORIZCOIN_"

settings = Settings()
