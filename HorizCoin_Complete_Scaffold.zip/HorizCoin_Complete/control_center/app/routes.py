from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from . import models
from sqlalchemy.orm import Session
from sqlalchemy import select

router = APIRouter()

class JobCreate(BaseModel):
    external_id: str
    client_address: str
    payload: dict

class NodeRegister(BaseModel):
    address: str
    kind: str

def get_node_by_address(db: Session, address: str) -> Optional[models.Node]:
    return db.execute(select(models.Node).where(models.Node.address == address)).scalar_one_or_none()

@router.post("/nodes/register")
def register_node(body: NodeRegister, db: Session):
    node = get_node_by_address(db, body.address)
    if node:
        node.kind = body.kind
        node.status = "online"
    else:
        node = models.Node(address=body.address, kind=body.kind, status="online")
        db.add(node)
    db.commit()
    db.refresh(node)
    return node

@router.post("/jobs", response_model=dict)
def create_job(body: JobCreate, db: Session):
    job = models.Job(
        external_id=body.external_id,
        client_address=body.client_address,
        payload=body.payload,
        status="queued",
    )
    db.add(job)
    db.commit()
    db.refresh(job)
    return {"id": job.id, "status": job.status}

@router.get("/jobs", response_model=List[dict])
def list_jobs(db: Session):
    jobs = db.execute(select(models.Job)).scalars().all()
    return [
        {
            "id": j.id,
            "external_id": j.external_id,
            "status": j.status,
            "node_id": j.node_id,
            "price_husd": j.price_husd,
        }
        for j in jobs
    ]
