from fastapi import FastAPI
from . import routes, models
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from .config import settings

engine = create_engine(settings.database_url, future=True)
SessionLocal = sessionmaker(bind=engine, expire_on_commit=False)

models.Base.metadata.create_all(bind=engine)

app = FastAPI(title="HorizCoin Control-Center")

# Simple DB dependency
from fastapi import Depends
from sqlalchemy.orm import Session

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

app.dependency_overrides[routes.db] = get_db  # type: ignore

app.include_router(routes.router, prefix="/api")
