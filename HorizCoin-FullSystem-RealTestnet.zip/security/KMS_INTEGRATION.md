KMS / HSM Integration Notes
---------------------------
- Replace local Fernet-based encryption with KMS envelope encryption.
- Example flow (AWS KMS):
  1. Generate a data key via KMS GenerateDataKey (encrypted + plaintext)
  2. Use plaintext data key to encrypt private key, store encrypted private key in DB.
  3. Discard plaintext data key; use KMS to perform sign operations (via KMS Sign) where possible.
- Ensure IAM roles restrict access to only the wallet signing service.
