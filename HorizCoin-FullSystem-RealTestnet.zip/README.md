HorizCoin FullSystem (Testnet-Ready)
===================================

This package prepares HorizCoin for a **real testnet deployment** (Option B). It is designed to be added to the original project repository as an external deployment artifact — it does NOT change the original codebase.

IMPORTANT: This package does NOT contain any private keys or secrets. You must populate `.env` from `.env.example` before use.

Contents:
- contracts/                    # Solidity contracts (ERC-20 token)
- deploy/                       # Hardhat deploy scripts (testnet-ready)
- infra/                        # Pulumi / Kubernetes manifest samples for testnet
- ai/                           # AI integration service stubs for production testnet
- security/                     # Security & KMS integration examples
- docs/                         # Deployment & runbooks
- .env.example                  # env template for connecting to real testnets

How to use (high level):
1. Copy this folder into your project workspace (do not overwrite existing files).
2. Create a `.env` file from `.env.example` and populate with your RPC keys and secrets.
3. Install deps: `npm ci` and `pip install -r ai/requirements.txt` as needed.
4. Start a local deploy to Sepolia/Mumbai testnet:
   `npx hardhat run deploy/deploy_testnet.js --network sepolia`
5. Follow docs/REAL_DEPLOYMENT_GUIDE.md for secure KMS integration and production steps.

If you want, I can now create a GitHub-friendly PR bundle (zip) ready to attach — this file is it.
