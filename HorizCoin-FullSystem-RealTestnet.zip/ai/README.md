AI Integration (Testnet-ready)
------------------------------
This folder contains stubs and deployment guidance for the AI Valuation and Compliance services.
- Use MLflow for experiment management and TorchServe/Triton for model serving.
- Deploy AI services behind internal-only K8s services and expose via mTLS to Chainlink adapters if needed.
- See ai/requirements.txt for Python dependencies.
