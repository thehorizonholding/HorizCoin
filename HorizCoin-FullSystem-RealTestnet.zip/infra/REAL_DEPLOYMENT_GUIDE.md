Real Testnet Deployment Guide (secure)
-------------------------------------

1. Prepare cloud accounts (AWS/GCP) and enable KMS/HSM. Use a dedicated service account for deploys.
2. Store secrets in Vault or cloud KMS; DO NOT place private keys in source.
3. Build Docker images and push to ECR/GCR, then deploy to EKS/GKE.
4. Use Pulumi/Terraform modules to provision:
   - K8s cluster with private nodes
   - Managed Kafka (Confluent or MSK) for DePIN ingestion
   - RDS/Postgres for ledger and user db
   - HashiCorp Vault for secrets
5. Use Kubernetes NetworkPolicies and RBAC to isolate the custodial wallet service.
