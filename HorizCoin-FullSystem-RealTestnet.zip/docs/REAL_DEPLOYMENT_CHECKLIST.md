Real Testnet Checklist
- [ ] Populate .env with SEPOLIA_RPC_URL, PRIVATE_KEY, KMS settings.
- [ ] Run `npm ci` in deploy/ and install Hardhat plugins.
- [ ] Run `npx hardhat compile` then `npx hardhat run deploy/deploy_testnet.js --network sepolia`
- [ ] Verify token on explorer and update deploy/deployed_address.txt
- [ ] Configure Chainlink job with your Chainlink node and AI adapter URL
- [ ] Deploy AI services and point Chainlink to their endpoints
- [ ] Run integration test suite (ledger balancing, sign flows)
