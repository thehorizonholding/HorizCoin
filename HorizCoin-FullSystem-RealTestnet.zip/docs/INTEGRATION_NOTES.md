Integration Notes:
- Security bundle (prometheus alerts, falco rules, vault samples) should be applied from the security team artifacts; they are not modified here.
- AI Help package is provided separately; integrate the help_center service as an internal K8s deployment with read-only access to logs and write access to a ticketing webhook.
