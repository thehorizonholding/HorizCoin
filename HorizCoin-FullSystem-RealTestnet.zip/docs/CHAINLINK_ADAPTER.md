Chainlink External Adapter / Job Notes
-------------------------------------
- This repo includes a placeholder for Chainlink job configuration. In production:
  1. Run a Chainlink node (or use an operator). Configure an HTTP GET job that calls your AI valuation endpoint.
  2. The job should return a numeric price/value in the expected JSON path.
  3. Configure the DataValuationOracle contract with the node address and jobId.

Security:
- Only use whitelisted external adapters. Sign and verify adapter responses when possible.
