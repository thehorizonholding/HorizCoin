#!/usr/bin/env bash
set -e
# Validate existence of env
if [ ! -f .env ]; then
  echo '.env not found. Copy from .env.example and populate values.'
  exit 1
fi
echo 'Installing dependencies... (user must run npm ci)'
echo 'Compile contracts (example): npx hardhat compile'
echo 'To deploy to sepolia: npx hardhat run deploy/deploy_testnet.js --network sepolia'
