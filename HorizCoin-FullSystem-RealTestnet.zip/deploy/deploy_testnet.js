const hre = require('hardhat');

async function main() {
  const [deployer] = await hre.ethers.getSigners();
  console.log('Deploying from:', deployer.address);

  const initialSupply = hre.ethers.parseUnits('1000000', 18); // 1M HZC
  const Token = await hre.ethers.getContractFactory('HorizCoinToken');
  const token = await Token.deploy(initialSupply);
  await token.deploymentTransaction().wait(1);

  console.log('HorizCoinToken deployed at:', token.target);
  // Save deployment info to disk for other services
  const fs = require('fs');
  fs.writeFileSync('deploy/deployed_address.txt', token.target, 'utf8');
}

main().catch((err) => {
  console.error(err);
  process.exitCode = 1;
});
