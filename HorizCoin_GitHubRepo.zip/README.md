# HorizCoin Ultra — GitHub Repository (Full Production Skeleton)
Generated: 2025-11-29T16:50:21.839867Z

This repository is a complete, production-oriented skeleton for the HorizCoin Ultra project (Solo + Private Mode, $100B theoretical design).
It contains contracts, backend microservices, node simulator, oracle, frontend, infra, docs, tests, and CI workflows.

**IMPORTANT**: This repo is a design and engineering scaffold. It is **not** production-ready and requires:
- Security audits for smart contracts
- Legal/regulatory compliance
- Real infra deployment (cloud, HSMs, physical hardware)
- Partnerships for satellite and GPU supply

Folders:
- contracts/      — Solidity contracts (ERC20, PoBValidator, Governance, Admin)
- backend/        — watchtower, oracle, job-scheduler, reputation, billing
- node/           — Python node simulator and autonomous agent framework
- sdk/            — JavaScript SDKs for integration
- frontend/       — React dashboard
- infra/          — docker-compose, k8s placeholders, terraform skeleton
- docs/           — whitepaper, architecture, tokenomics, execution plan
- scripts/        — helper scripts
- tests/          — hardhat tests and pytest suites
- .github/        — GitHub Actions CI templates

To run locally (development):
1. Install Docker & docker-compose
2. `docker-compose -f infra/docker-compose.dev.yml up --build`
3. Deploy contracts to local Hardhat node (see contracts/README.md)
4. Start node simulator: `python node/pob_node.py --dev`
5. Open frontend at http://localhost:3000

