Run hardhat tests in contracts and pytest for node.
