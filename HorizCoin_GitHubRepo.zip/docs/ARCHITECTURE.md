# Architecture
High-level architecture: Solo sequencer, private compute backbone, oracle-based PoB, token sinks, billing, automation agents.
