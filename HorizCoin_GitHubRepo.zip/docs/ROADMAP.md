# Roadmap
Phase 1: Seed & PoC
Phase 2: Institutional contracts
Phase 3: Scale & sovereign partnerships
