# Tokenomics
GIC as settlement rail, mandatory burn/stake sinks, treasury management, price stabilization, conversion windows.
