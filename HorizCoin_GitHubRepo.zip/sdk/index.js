const fetch = require('node-fetch');
class HorizSDK {
  constructor(oracle = "http://localhost:5001") { this.oracle = oracle; }
  async submitProof(miner, proofHash, bandwidth) {
    const res = await fetch(this.oracle + "/attest", {method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify({miner, proofHash, bandwidth})});
    return res.json();
  }
}
module.exports = HorizSDK;
