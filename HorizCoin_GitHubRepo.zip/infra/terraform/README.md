Terraform skeleton placeholder. Fill provider blocks and modules for production infra.
