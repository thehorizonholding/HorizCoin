# Contracts
Contracts include:
- HORIZ token (ERC20)
- PoBValidator (oracle-driven minting)
- Admin / Governance (permissioned controls)
- Staking and Reward contracts

Use Hardhat for local dev:
npm install
npx hardhat node
npx hardhat run scripts/deploy_local.js --network localhost
npx hardhat test
