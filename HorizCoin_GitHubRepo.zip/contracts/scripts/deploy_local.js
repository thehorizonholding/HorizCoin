const hre = require("hardhat");
async function main(){
  const [deployer] = await hre.ethers.getSigners();
  console.log("Deployer:", deployer.address);
  const Token = await hre.ethers.getContractFactory("HorizToken");
  const token = await Token.deploy();
  await token.deployed();
  console.log("Token deployed:", token.address);
  const Val = await hre.ethers.getContractFactory("PoBValidator");
  const val = await Val.deploy(token.address);
  await val.deployed();
  console.log("Validator deployed:", val.address);
}
main().catch(e => { console.error(e); process.exit(1); });
