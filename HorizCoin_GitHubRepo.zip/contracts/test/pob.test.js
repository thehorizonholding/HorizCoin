const { expect } = require("chai");
const hre = require("hardhat");
describe("PoB flow", function(){
  it("deploys and mints via oracle", async function(){
    const [owner, miner, oracle] = await hre.ethers.getSigners();
    const Token = await hre.ethers.getContractFactory("HorizToken");
    const token = await Token.deploy();
    await token.deployed();
    const Val = await hre.ethers.getContractFactory("PoBValidator");
    const val = await Val.deploy(token.address);
    await val.deployed();
    await val.connect(owner).setOracle(oracle.address);
    const proof = "0x" + "11".repeat(32);
    await val.connect(oracle).submitVerifiedProof(miner.address, proof, hre.ethers.parseEther("1"));
    const bal = await token.balanceOf(miner.address);
    expect(bal).to.equal(hre.ethers.parseEther("1"));
  });
});
