Python node simulator and autonomous agent framework. Uses web3.py for contract interactions.
