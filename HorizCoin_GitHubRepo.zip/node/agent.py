import asyncio, time, os, requests
from web3 import Web3

class AutoAgent:
    def __init__(self, id, oracle_url="http://localhost:5001"):
        self.id = id
        self.oracle = oracle_url

    async def run(self):
        while True:
            # generate a proof (simulated)
            payload = {"miner": self.id, "proofHash": "0x" + "ab"*32, "bandwidth": 100000}
            try:
                r = requests.post(self.oracle + "/attest", json=payload, timeout=5)
                print("Agent", self.id, "oracle response:", r.text)
            except Exception as e:
                print("Agent error", e)
            await asyncio.sleep(60)

if __name__ == '__main__':
    id = os.environ.get("NODE_ID", "agent-1")
    agent = AutoAgent(id)
    asyncio.run(agent.run())
