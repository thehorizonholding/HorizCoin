#!/usr/bin/env python3
# Simple PoB node simulator
import time, requests, os
def run_once(node_id="node-1"):
    proof = "0x" + "ff"*32
    bandwidth = 500000
    payload = {"miner": node_id, "proofHash": proof, "bandwidth": bandwidth}
    try:
        r = requests.post("http://localhost:5001/attest", json=payload, timeout=5)
        print("Submitted proof:", r.json())
    except Exception as e:
        print("Failed to submit proof:", e)

if __name__ == '__main__':
    run_once(os.environ.get("NODE_ID", "node-1"))
