#!/usr/bin/env bash
# Run a few agents locally (requires python env)
python3 node/agent.py &
python3 node/pob_node.py
