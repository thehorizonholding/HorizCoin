import React, {useEffect, useState} from 'react';
export default function App(){
  const [scores, setScores] = useState({});
  useEffect(()=>{ fetch('http://localhost:5004/scores').then(r=>r.json()).then(setScores).catch(()=>{}); },[]);
  return (<div style={{padding:20}}><h1>HorizCoin Ultra Dashboard</h1><pre>{JSON.stringify(scores,null,2)}</pre></div>);
}
