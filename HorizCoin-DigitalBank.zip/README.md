HorizCoin Digital Bank - Starter Package
=======================================

This starter package provides a minimal scaffold to build a regulated-aligned digital bank module for HorizCoin.
It is intended as a developer starting point: tokenized fiat contract, backend FastAPI skeleton, mock fiat partner,
ledger (double-entry), Docker files and basic run instructions.

**IMPORTANT**: This is a prototype scaffold. Running any fiat flows in production requires licensed partners,
KYC/AML, audited contracts, and legal review. Do NOT use real private keys or production credentials with this demo.

Contents:
- contracts/TokenizedFiat.sol        - ERC-20 token with mint/burn controlled by MINTER_ROLE
- backend/api.py                    - FastAPI app with basic account, deposit, withdrawal endpoints
- backend/ledger.py                 - Simple SQLAlchemy double-entry ledger and models
- backend/mock_bank_webhook.py      - Simulated bank webhook to signal fiat settlement
- docker-compose.yml                - Compose to run backend and mock bank
- .env.example                      - environment variable examples
- scripts/deploy_contract.sh        - helper to compile and deploy (local dev)

Quickstart (local, dev):
1. Install requirements: Python 3.10+, NodeJS 18+, Hardhat (for solidity compile)
2. Create virtualenv and install Python deps:
   python -m venv .venv && source .venv/bin/activate
   pip install -r backend/requirements.txt
3. Start mock bank:
   python backend/mock_bank_webhook.py
4. Run backend API:
   uvicorn backend.api:app --reload --port 8000
5. Use API endpoints to create accounts and simulate fiat deposit/settlement.

For production: integrate with licensed bank/payment partner (Stripe Treasury, Railsbank), custody provider (Fireblocks),
KYC provider (SumSub/Onfido), and perform full security & legal audits.

