from fastapi import FastAPI, HTTPException, BackgroundTasks
from pydantic import BaseModel
import uuid, os
from backend.ledger import init_db, SessionLocal, create_account, post_entry

init_db()
app = FastAPI(title='HorizCoin Digital Bank - Demo')

class AccountCreate(BaseModel):
    id: str
    name: str

@app.post('/accounts')
def create_account_endpoint(payload: AccountCreate):
    db = SessionLocal()
    existing = db.query.__self__.bind.execute("SELECT id FROM accounts WHERE id=:id", {'id': payload.id}).fetchone()
    if existing:
        db.close()
        raise HTTPException(status_code=400, detail='Account exists')
    a = create_account(db, payload.id, payload.name)
    db.close()
    return {'ok': True, 'account': {'id': a.id, 'name': a.name}}

class FiatDepositRequest(BaseModel):
    account_id: str
    amount: float
    bank_ref: str = ''

@app.post('/deposits/fiat')
def deposit_fiat(req: FiatDepositRequest):
    # create a pending deposit order; in real system creates bank instructions
    deposit_id = str(uuid.uuid4())
    # For demo, immediately create ledger entries: debit bank float account, credit user custodial account
    db = SessionLocal()
    post_entry(db, debit='bank_float', credit=req.account_id, amount=req.amount, currency='USD', typ='fiat_deposit', ref=req.bank_ref)
    db.close()
    return {'ok': True, 'deposit_id': deposit_id, 'status': 'settled_immediate_demo'}

class FiatWithdrawRequest(BaseModel):
    account_id: str
    amount: float
    bank_account: str

@app.post('/withdrawals/fiat')
def withdraw_fiat(req: FiatWithdrawRequest):
    # create withdrawal; in demo mark as pending
    withdrawal_id = str(uuid.uuid4())
    db = SessionLocal()
    post_entry(db, debit=req.account_id, credit='bank_float', amount=req.amount, currency='USD', typ='fiat_withdrawal', ref=req.bank_account)
    db.close()
    return {'ok': True, 'withdrawal_id': withdrawal_id, 'status': 'submitted_demo'}

@app.get('/health')
def health():
    return {'ok': True}
