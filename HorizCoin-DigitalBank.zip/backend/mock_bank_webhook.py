from flask import Flask, request, jsonify
import uuid, time
app = Flask(__name__)
ORDERS = {}

@app.route('/notify_settlement', methods=['POST'])
def notify_settlement():
    data = request.get_json() or {}
    order_id = data.get('order_id', str(uuid.uuid4()))
    ORDERS[order_id] = {'id': order_id, 'amount': data.get('amount'), 'currency': data.get('currency', 'USD'), 'status': 'settled', 'ts': int(time.time())}
    return jsonify({'ok': True, 'order_id': order_id})

@app.route('/order/<order_id>')
def get_order(order_id):
    return jsonify(ORDERS.get(order_id, {}))

if __name__ == '__main__':
    app.run(port=5010)
