from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, JSON, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
from datetime import datetime
import os

DATABASE_URL = os.getenv('DATABASE_URL', 'sqlite:///./bank_ledger.db')
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine)
Base = declarative_base()

class Account(Base):
    __tablename__ = 'accounts'
    id = Column(String, primary_key=True, index=True)
    name = Column(String)
    kyc_level = Column(String, default='basic')
    created_at = Column(DateTime, default=datetime.utcnow)

class LedgerEntry(Base):
    __tablename__ = 'ledger_entries'
    id = Column(Integer, primary_key=True, autoincrement=True)
    debit_account = Column(String, index=True)
    credit_account = Column(String, index=True)
    amount = Column(Float)
    currency = Column(String)
    type = Column(String)
    ref = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)

def init_db():
    Base.metadata.create_all(bind=engine)

def create_account(db, account_id, name):
    a = Account(id=account_id, name=name)
    db.add(a)
    db.commit()
    db.refresh(a)
    return a

def post_entry(db, debit, credit, amount, currency='USD', typ='transfer', ref=''):
    e = LedgerEntry(debit_account=debit, credit_account=credit, amount=amount, currency=currency, type=typ, ref=ref)
    db.add(e)
    db.commit()
    db.refresh(e)
    return e
