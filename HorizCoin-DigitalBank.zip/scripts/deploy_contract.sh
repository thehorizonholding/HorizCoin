#!/usr/bin/env bash
set -e
# Minimal helper to compile and deploy TokenizedFiat locally using hardhat
if [ ! -f hardhat.config.js ]; then
  echo 'Please add a hardhat.config.js in repo root for solidity compilation/deploy.'
  exit 1
fi
npx hardhat compile
npx hardhat run scripts/deploy_tokenized_fiat.js --network localhost
