"""Recycle Service - safe, dry-run skeleton
- Advertise inventory
- Simulate job acceptance
- Produce invoices (JSON)
- Authentication and policy stubs included
"""

from flask import Flask, request, jsonify
import os, json, uuid, time
from decimal import Decimal

app = Flask(__name__)

# In-memory store for demo. Replace with DB in production.
OFFERS = {}
JOBS = {}
LEDGER = {}

# Simple auth stub (use real JWT + RBAC in prod)
API_KEYS = {"admin-key": "admin"}

def require_api_key(fn):
    def wrapper(*args, **kwargs):
        key = request.headers.get("X-Api-Key") or request.args.get("api_key")
        if not key or key not in API_KEYS:
            return jsonify({"error":"unauthorized"}), 401
        return fn(*args, **kwargs)
    wrapper.__name__ = fn.__name__
    return wrapper

@app.route("/inventory/offer", methods=["POST"])
@require_api_key
def create_offer():
    data = request.get_json() or {}
    nid = str(uuid.uuid4())
    offer = {
        "offer_id": nid,
        "node_id": data.get("node_id"),
        "vcpus": int(data.get("vcpus",0)),
        "memory_gb": float(data.get("memory_gb",0)),
        "region": data.get("region"),
        "available_hours": int(data.get("available_hours",0)),
        "price_per_hour_usd": str(data.get("price_per_hour_usd","0.00")),
        "tags": data.get("tags", {}),
        "created_at": int(time.time()),
        "status": "available"
    }
    OFFERS[nid] = offer
    return jsonify(offer), 201

@app.route("/marketplace/offers", methods=["GET"])
@require_api_key
def list_offers():
    return jsonify(list(OFFERS.values()))

@app.route("/job/submit", methods=["POST"])
@require_api_key
def submit_job():
    data = request.get_json() or {}
    payload_text = json.dumps(data).lower()
    blocked = ["mine","mining","cryptominer","botnet","steal","exploit","coin","mint"]
    for b in blocked:
        if b in payload_text:
            return jsonify({"error":"job contains disallowed activity"}), 400
    chosen = None
    for o in OFFERS.values():
        if o["status"] == "available" and int(o["available_hours"]) >= int(data.get("expected_hours",1)):
            chosen = o
            break
    if not chosen:
        return jsonify({"error":"no capacity available"}), 503
    jid = str(uuid.uuid4())
    job = {
        "job_id": jid,
        "offer_id": chosen["offer_id"],
        "status": "simulated",
        "requested_hours": int(data.get("expected_hours",1)),
        "price_per_hour": chosen["price_per_hour_usd"],
        "created_at": int(time.time())
    }
    JOBS[jid] = job
    chosen["available_hours"] = int(chosen["available_hours"]) - job["requested_hours"]
    acct = data.get("billing_account","test-cust")
    invoice = {
        "invoice_id": str(uuid.uuid4()),
        "job_id": jid,
        "account": acct,
        "amount_usd": str(Decimal(chosen["price_per_hour_usd"]) * Decimal(job["requested_hours"])),
        "ts": int(time.time())
    }
    LEDGER.setdefault(acct, []).append(invoice)
    return jsonify({"job": job, "invoice": invoice}), 201

@app.route("/billing/account/<account_id>", methods=["GET"])
@require_api_key
def get_account_invoices(account_id):
    return jsonify(LEDGER.get(account_id, []))

@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status":"ok", "ts": int(time.time())})

if __name__ == "__main__":
    port = int(os.getenv("PORT", "8081"))
    app.run(host="0.0.0.0", port=port, debug=False)
