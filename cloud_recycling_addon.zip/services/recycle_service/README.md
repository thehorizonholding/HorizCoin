# Recycle Service (Compute Leasing & Monetization) — Add-on

This is an **additive microservice** that lets you advertise idle capacity and accept lawful jobs.

Features:
- Inventory offers (dry-run)
- Simulated job acceptance and billing
- Billing ledger stub and invoice generator (JSON)
- Auth stubs (API Key) and policy enforcement (OPA recommended)

Safety:
- Runs **dry-run** by default (no real cloud APIs are called).
- Blocks job payloads containing disallowed keywords (mining, exploit, etc).
- Do not enable production connectors until keys are in Vault and compliance sign-off is done.

Quickstart:
1. Create a feature branch: `feat/cloud-recycling`
2. Add this folder to your repo and run in a sandbox environment.
3. Use CI to test the service in dry-run before merging.
