# HorizCoin Backend & AI Layer (Ultra Version)

This folder contains:
- A FastAPI **Control Center** to orchestrate on-chain settlement.
- Two Ray RLlib **AI agents**:
  - `pricing_agent.py`: learns dynamic pricing for jobs in hUSD.
  - `allocation_agent.py`: learns efficient allocation of jobs across nodes.

## Quickstart (MacBook Pro Max, local dev)

```bash
cd backend
python -m venv .venv
source .venv/bin/activate  # or .venv\\Scripts\\activate on Windows

pip install -r requirements.txt
```

### Run the Control Center API

Create `.env`:

```env
RPC_URL=http://127.0.0.1:8545
CHAIN_ID=31337
ADMIN_PRIVATE_KEY=0xYOUR_LOCAL_PRIVATE_KEY
JOB_SETTLEMENT_ADDRESS=0xJobSettlementAddress
HUSD_ADDRESS=0xHusdTokenAddress
```

Then:

```bash
uvicorn control_center.server:app --reload --port 8000
```

### Train the Pricing Agent

```bash
python ai/pricing_agent.py
```

### Train the Allocation Agent

```bash
python ai/allocation_agent.py
```
