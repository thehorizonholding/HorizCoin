import ray
from ray.rllib.algorithms.dqn import DQNConfig
import gym
import numpy as np

class PricingEnv(gym.Env):
    """Simple RL environment for dynamic hUSD pricing."""

    def __init__(self, config=None):
        super().__init__()
        self.action_space = gym.spaces.Discrete(100)  # 100 price points
        self.observation_space = gym.spaces.Box(low=0.0, high=1.0, shape=(10,), dtype=np.float32)
        self.state = self._get_obs()

    def reset(self, *, seed=None, options=None):
        super().reset(seed=seed)
        self.state = self._get_obs()
        return self.state

    def step(self, action):
        price = self._index_to_price(action)
        job = self._sample_job()
        accepted = self._simulate_client_acceptance(job, price)
        cost = self._estimate_cost(job)
        reward = (price - cost) if accepted else 0.0
        done = True
        self.state = self._get_obs()
        return self.state, reward, done, {}

    def _get_obs(self):
        return np.random.rand(10).astype(np.float32)

    def _sample_job(self):
        return {
            "difficulty": float(np.random.rand()),
            "price_sensitivity": float(np.random.rand()),
        }

    def _simulate_client_acceptance(self, job, price):
        base_wtp = (1.5 - job["price_sensitivity"]) * 100.0
        return price <= base_wtp

    def _estimate_cost(self, job):
        return 10.0 + job["difficulty"] * 40.0

    def _index_to_price(self, idx: int) -> float:
        return float(idx + 1)


def train_pricing_agent(iters: int = 50):
    ray.init(ignore_reinit_error=True)

    config = (
        DQNConfig()
        .environment(PricingEnv)
        .framework("torch")
        .rollouts(num_rollout_workers=1)
    )

    algo = config.build()

    for i in range(iters):
        result = algo.train()
        print(f"[PricingAgent] Iter {i} | mean reward: {result['episode_reward_mean']}")

    algo.save("pricing_agent_checkpoint")
    ray.shutdown()


if __name__ == "__main__":
    train_pricing_agent()
