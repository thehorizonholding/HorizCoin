import ray
from ray.rllib.algorithms.ppo import PPOConfig
import gym
import numpy as np


class AllocationEnv(gym.Env):
    """RL environment for fleet allocation and cost minimization."""

    def __init__(self, config=None):
        super().__init__()
        if config is None:
            config = {}
        self.num_nodes = int(config.get("num_nodes", 100))
        self.observation_space = gym.spaces.Box(
            low=0.0, high=1.0, shape=(10 + self.num_nodes,), dtype=np.float32
        )
        self.action_space = gym.spaces.Box(
            low=0.0, high=1.0, shape=(self.num_nodes,), dtype=np.float32
        )
        self.state = self._build_obs()

    def reset(self, *, seed=None, options=None):
        super().reset(seed=seed)
        self.state = self._build_obs()
        return self.state

    def step(self, action):
        if action.sum() > 0:
            allocation = action / action.sum()
        else:
            allocation = np.zeros_like(action)

        job = self._sample_job()
        cost, qos_penalty = self._simulate_execution(job, allocation)
        reward = -(cost + qos_penalty)
        done = True
        self.state = self._build_obs()
        return self.state, reward, done, {}

    def _build_obs(self):
        job_vec = np.random.rand(10)
        node_vec = np.random.rand(self.num_nodes)
        return np.concatenate([job_vec, node_vec]).astype(np.float32)

    def _sample_job(self):
        return {"size": float(np.random.rand()), "deadline": float(np.random.rand())}

    def _simulate_execution(self, job, allocation):
        effective_power = allocation.max()
        active_nodes = float((allocation > 0).sum())
        base_cost = job["size"] * 100.0 * (1.0 + active_nodes / self.num_nodes)
        qos_penalty = 0.0
        if effective_power < job["deadline"] * 0.5:
            qos_penalty = 50.0
        return base_cost, qos_penalty


def train_allocation_agent(iters: int = 50):
    ray.init(ignore_reinit_error=True)

    config = (
        PPOConfig()
        .environment(AllocationEnv, env_config={"num_nodes": 100})
        .framework("torch")
        .rollouts(num_rollout_workers=1)
    )

    algo = config.build()

    for i in range(iters):
        result = algo.train()
        print(f"[AllocationAgent] Iter {i} | mean reward: {result['episode_reward_mean']}")

    algo.save("allocation_agent_checkpoint")
    ray.shutdown()


if __name__ == "__main__":
    train_allocation_agent()
