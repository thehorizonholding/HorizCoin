import os
import uuid
from typing import Any, Dict

from fastapi import FastAPI
from pydantic import BaseModel
from web3 import Web3
from dotenv import load_dotenv

load_dotenv()

app = FastAPI(title="HorizCoin Control Center API")

RPC_URL = os.getenv("RPC_URL", "http://localhost:8545")
PRIVATE_KEY = os.getenv("ADMIN_PRIVATE_KEY")  # NEVER commit this in real life
CHAIN_ID = int(os.getenv("CHAIN_ID", "31337"))
JOB_SETTLEMENT_ADDRESS = os.getenv("JOB_SETTLEMENT_ADDRESS")
HUSD_ADDRESS = os.getenv("HUSD_ADDRESS")

w3 = Web3(Web3.HTTPProvider(RPC_URL))

# NOTE: generate the ABI JSON with Hardhat/Foundry and drop into this folder.
ABI_PATH = os.path.join(os.path.dirname(__file__), "JobSettlementContract.abi.json")
if os.path.exists(ABI_PATH):
    import json
    with open(ABI_PATH, "r") as f:
        JOB_SETTLEMENT_ABI = json.load(f)
else:
    JOB_SETTLEMENT_ABI = []

job_settlement = None
if JOB_SETTLEMENT_ABI and JOB_SETTLEMENT_ADDRESS:
    job_settlement = w3.eth.contract(
        address=Web3.to_checksum_address(JOB_SETTLEMENT_ADDRESS),
        abi=JOB_SETTLEMENT_ABI,
    )


class JobRequest(BaseModel):
    client_address: str
    provider_address: str
    amount_husd: int  # smallest units
    metadata: Dict[str, Any] = {}


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/jobs/settle")
def settle_job(req: JobRequest):
    if job_settlement is None:
        return {"error": "JobSettlementContract not configured"}

    job_id = uuid.uuid4().bytes
    client = Web3.to_checksum_address(req.client_address)
    provider = Web3.to_checksum_address(req.provider_address)

    account = w3.eth.account.from_key(PRIVATE_KEY)
    nonce = w3.eth.get_transaction_count(account.address)

    tx = job_settlement.functions.settleJob(
        job_id,
        client,
        provider,
        req.amount_husd,
    ).build_transaction(
        {
            "from": account.address,
            "nonce": nonce,
            "chainId": CHAIN_ID,
            "gas": 400000,
            "gasPrice": w3.to_wei("1", "gwei"),
        }
    )

    signed = account.sign_transaction(tx)
    tx_hash = w3.eth.send_raw_transaction(signed.rawTransaction)

    return {
        "job_id": job_id.hex(),
        "tx_hash": tx_hash.hex(),
    }
