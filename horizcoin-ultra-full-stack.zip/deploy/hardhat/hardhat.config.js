require("@nomicfoundation/hardhat-toolbox");
require("dotenv").config();

const { RPC_URL_LOCAL, RPC_URL_BASE, PRIVATE_KEY, ETHERSCAN_API_KEY } = process.env;

module.exports = {
  solidity: "0.8.20",
  networks: {
    localhost: {
      url: RPC_URL_LOCAL || "http://127.0.0.1:8545",
    },
    base: {
      url: RPC_URL_BASE || "",
      accounts: PRIVATE_KEY ? [PRIVATE_KEY] : []
    }
  },
  etherscan: {
    apiKey: ETHERSCAN_API_KEY || ""
  }
};
