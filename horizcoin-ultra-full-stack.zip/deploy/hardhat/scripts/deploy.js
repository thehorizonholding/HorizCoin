const hre = require("hardhat");

async function main() {
  const [deployer] = await hre.ethers.getSigners();
  console.log("Deploying with:", deployer.address);

  const HUSD = await hre.ethers.getContractFactory("HUSDMock");
  const husd = await HUSD.deploy(hre.ethers.parseUnits("1000000", 18), deployer.address);
  await husd.waitForDeployment();
  console.log("HUSDMock deployed:", await husd.getAddress());

  const HORC = await hre.ethers.getContractFactory("HORCToken");
  const horc = await HORC.deploy(hre.ethers.parseUnits("1000000000", 18), deployer.address);
  await horc.waitForDeployment();
  console.log("HORCToken deployed:", await horc.getAddress());

  const routerAddress = "0x0000000000000000000000000000000000000001"; // TODO: replace with real DEX router
  const incentivePool = deployer.address;

  const Flywheel = await hre.ethers.getContractFactory("RevenueFlywheelContract");
  const flywheel = await Flywheel.deploy(
    await husd.getAddress(),
    await horc.getAddress(),
    routerAddress,
    incentivePool,
    deployer.address
  );
  await flywheel.waitForDeployment();
  console.log("RevenueFlywheelContract deployed:", await flywheel.getAddress());

  const JobSettlement = await hre.ethers.getContractFactory("JobSettlementContract");
  const jobSettlement = await JobSettlement.deploy(
    await husd.getAddress(),
    await flywheel.getAddress(),
    2000 // 20% take rate
  );
  await jobSettlement.waitForDeployment();
  console.log("JobSettlementContract deployed:", await jobSettlement.getAddress());
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
