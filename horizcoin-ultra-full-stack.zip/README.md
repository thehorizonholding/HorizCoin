# HorizCoin UltraVersion – Full Stack (Contracts + Backend + AI + Deploy)

This bundle contains:
- Solidity smart contracts for HorizCoin tokenomics core (HORC, hUSD mock, JobSettlement, RevenueFlywheel).
- A FastAPI **Control Center** backend for orchestrating jobs and on-chain settlement.
- Ray RLlib **AI agents** for pricing and allocation.
- **Hardhat** and **Foundry** deploy scripts so deployment from your MacBook Pro Max is a single command.

You can drop this into a GitHub repo and extend around it.
