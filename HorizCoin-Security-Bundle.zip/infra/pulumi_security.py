import pulumi
import pulumi_aws as aws

vpc = aws.ec2.Vpc('hzc-vpc', cidr_block='10.0.0.0/16')
public_subnet = aws.ec2.Subnet('public-subnet', vpc_id=vpc.id, cidr_block='10.0.1.0/24')
sg = aws.ec2.SecurityGroup('hzc-sg',
    vpc_id=vpc.id,
    description='HorizCoin security group',
    ingress=[
        aws.ec2.SecurityGroupIngressArgs(protocol='tcp', from_port=443, to_port=443, cidr_blocks=['0.0.0.0/0']),
        aws.ec2.SecurityGroupIngressArgs(protocol='tcp', from_port=22, to_port=22, cidr_blocks=['10.0.0.0/8'])
    ],
    egress=[aws.ec2.SecurityGroupEgressArgs(protocol='-1', from_port=0, to_port=0, cidr_blocks=['0.0.0.0/0'])]
)
pulumi.export('sg_id', sg.id)
