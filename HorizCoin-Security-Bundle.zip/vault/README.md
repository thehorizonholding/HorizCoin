Vault Integration (sample)
- Use HashiCorp Vault to store DB credentials and API keys.
- Use dynamic secrets for databases where possible (short TTL).
- Authenticate apps using Kubernetes auth or AppRole.
