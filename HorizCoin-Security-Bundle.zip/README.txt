HorizCoin Security Bundle

This bundle contains security configs and templates to harden HorizCoin:
- Prometheus alert rules
- Grafana dashboard JSON
- GitHub Actions security workflow
- Pulumi security module (AWS)
- Kubernetes manifests: PodSecurity, NetworkPolicy, Falco
- Vault Terraform sample
- Vector log forwarder config
- Falco custom rules
- Incident response playbook
- Nginx rate-limiting

Instructions:
- Review and adapt the CIDR/IPs, secrets, and cloud-specific parameters to your environment.
- Do not use as-is in production without validation & testing.
