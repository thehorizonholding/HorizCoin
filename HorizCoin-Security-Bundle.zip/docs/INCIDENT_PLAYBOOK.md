HorizCoin Incident Response Playbook (summary)

P0 (Critical) - Unauthorized mint, funds theft, chain compromise
1. Triage: PagerDuty alert triggers, assemble Incident Response (IR) team lead, SRE, legal.
2. Contain: Pause automated systems, initiate multisig freeze (revoke MINTER_ROLE via multisig or execute timelock), cordon nodes.
3. Preserve: Snapshot VMs, collect logs (SIEM), export DB backups (read-only), preserve blockchain node data directory.
4. Forensics: Engage DFIR, collect memory images if needed, check CloudTrail for suspicious API calls.
5. Remediate: Re-deploy from signed artifacts, rotate compromised keys, notify exchanges & affected parties.
6. Postmortem: Write a blameless postmortem and publish remediation timeline.

Contact matrix:
- PagerDuty: On-call SRE
- Slack: #ops (warnings), #security (incidents)
- Email: security@horizcoin.example.com
