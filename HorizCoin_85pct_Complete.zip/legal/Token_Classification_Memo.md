# Token Classification Memo - HorizCoin
This memo analyzes HC-UTILITY (HORC), HC-REWARD, HC-ASSET under the Howey test and EU MiCA considerations. Summary:
- HC-UTILITY: designed as consumption token with minimal expectation of profit; recommend strict documentation and usage limits to reduce security risk.
- HC-REWARD: likely to carry investment expectations; treat as governance/reward token with clear tax implications.
- HC-ASSET: tokenized RWAs are securities in many jurisdictions; implement KYC/AML and restrict transfers.
Legal counsel needed to finalize.
