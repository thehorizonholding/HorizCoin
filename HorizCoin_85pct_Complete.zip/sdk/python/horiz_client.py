import requests
class HorizClient:
    def __init__(self, api_url): self.api_url = api_url
    def register_node(self, node_id, pubkey, capabilities): return requests.post(self.api_url + '/nodes/register', json={'nodeId':node_id,'pubKey':pubkey,'capabilities':capabilities}).json()