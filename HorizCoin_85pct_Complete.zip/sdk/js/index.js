const ChannelClient = require('../../clients/js/channelClient');
class HorizSDK {
  constructor(provider, wallet) { this.provider = provider; this.wallet = wallet; }
  channelClient(channelAddress) { return new ChannelClient(this.provider, this.wallet, channelAddress); }
  async registerNode(apiUrl, nodeId, pubKey, capabilities){ return fetch(apiUrl + '/nodes/register', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({nodeId,pubKey,capabilities})}).then(r=>r.json()); }
}
module.exports = HorizSDK;