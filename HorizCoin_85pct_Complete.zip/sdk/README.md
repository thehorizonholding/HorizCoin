SDKs: JS and Python client skeletons. Extend with typed interfaces and full documentation.
