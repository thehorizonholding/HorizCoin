const { expect } = require("chai"); const { ethers } = require("hardhat");
describe("PaymentChannel", function () {
  it("funds channel and settles via signed state", async function () {
    const [owner, payer, payee] = await ethers.getSigners();
    const Token = await ethers.getContractFactory("hUSD");
    const token = await Token.deploy(ethers.parseUnits("10000",18));
    await token.waitForDeployment();
    // send funds to payer and approve channel
    await token.transfer(payer.address, ethers.parseUnits("1000",18));
    const Channel = await ethers.getContractFactory("PaymentChannel");
    const expires = Math.floor(Date.now()/1000) + 3600;
    const channel = await Channel.deploy(token.target, payer.address, payee.address, expires);
    await channel.waitForDeployment();
    // payer funds channel
    await token.connect(payer).approve(channel.target, ethers.parseUnits("500",18));
    await channel.connect(payer).fund(ethers.parseUnits("500",18));
    // Build signed state off-chain (simulate)
    const amountPaid = ethers.parseUnits("100",18);
    const nonce = 1;
    const messageHash = ethers.keccak256(ethers.AbiCoder.defaultAbiCoder.encode(
["address","uint256","uint256"], [channel.target, amountPaid, nonce]));
    const signature = await payer.signMessage(ethers.getBytes(messageHash));
    // submit state and check payee balance increased
    await channel.connect(payee).submitState(amountPaid, nonce, signature);
    const balance = await token.balanceOf(payee.address);
    expect(balance).to.equal(amountPaid);
  });
});