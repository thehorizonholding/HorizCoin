const { expect } = require("chai"); const { ethers } = require("hardhat");
describe("HORC token", function () {
  it("deploys and transfers with fee to feeRecipient", async function () {
    const [owner, feeRecipient, alice] = await ethers.getSigners();
    const HORC = await ethers.getContractFactory("HORC");
    const initialSupply = ethers.parseUnits("1000", 18);
    const feeBps = 200; // 2%
    const horc = await HORC.deploy(feeRecipient.address, initialSupply, feeBps);
    await horc.waitForDeployment();
    const ownerBalance = await horc.balanceOf(owner.address);
    expect(ownerBalance).to.equal(initialSupply);
    const amount = ethers.parseUnits("100", 18);
    await horc.transfer(alice.address, amount);
    const aliceBalance = await horc.balanceOf(alice.address);
    const feeBalance = await horc.balanceOf(feeRecipient.address);
    expect(aliceBalance).to.equal(ethers.parseUnits("98", 18));
    expect(feeBalance).to.equal(ethers.parseUnits("2", 18));
  });
});