# Audit Checklist
- Smart contracts: full audit + formal verification for critical modules
- Backend: pentest and supply chain validation
- Agents: sandbox and TEE verification
- Watchtowers: resiliency testing
