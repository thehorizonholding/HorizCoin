const express = require('express'); const bodyParser = require('body-parser'); const app = express(); app.use(bodyParser.json());
// Simple watchtower: accepts channel states and can submit to chain if conditions met
let watched = {};
app.post('/watch', (req,res)=>{ const {channel, state} = req.body; watched[channel] = state; res.json({status:'watching'}); });
app.get('/watched', (req,res)=> res.json(watched));
const PORT = process.env.PORT || 4001; app.listen(PORT, ()=> console.log('Watchtower running', PORT));