#!/usr/bin/env python3
import requests, time, uuid, hashlib, hmac, os, json
NODE_ID = 'node-' + str(uuid.uuid4())[:8]
FM = os.environ.get('FLEET_MANAGER','http://localhost:3001')
KEY = os.environ.get('AGENT_KEY','demo-secret-key')
def sign(msg):
    return hmac.new(KEY.encode(), msg.encode(), hashlib.sha256).hexdigest()
def register():
    payload={'nodeId':NODE_ID,'pubKey':'mvp-key','capabilities':{'cpu':4,'gpus':0,'bandwidth':100}}
    r = requests.post(FM + '/nodes/register', json=payload)
    print('register', r.status_code, r.text)
def report():
    payload={'cpuLoad':0.12,'memPct':0.32,'bandwidthMbps':95,'uptime':3600}
    payload['sig']=sign(json.dumps(payload, sort_keys=True))
    r = requests.post(FM + f'/nodes/{NODE_ID}/telemetry', json=payload)
    print('telemetry', r.status_code)
def result_hash(result_bytes):
    # returns hex merkle-like single hash for small results (placeholder)
    return hashlib.sha256(result_bytes).hexdigest()
if __name__=='__main__':
    register()
    while True:
        report()
        time.sleep(15)