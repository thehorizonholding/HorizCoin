const ethers = require('ethers');
/*
Simple client to create signed payment channel states.
This client builds the message to sign compatible with the PaymentChannel contract.
*/
class ChannelClient {
  constructor(provider, wallet, channelAddress) {
    this.provider = provider;
    this.wallet = wallet;
    this.channelAddress = channelAddress;
    this.nonce = 0;
  }
  async signState(amountPaid) {
    this.nonce += 1;
    const abiCoder = ethers.AbiCoder.defaultAbiCoder;
    const encoded = abiCoder.encode(['address','uint256','uint256'], [this.channelAddress, amountPaid.toString(), this.nonce]);
    const hash = ethers.keccak256(encoded);
    const sig = await this.wallet.signMessage(ethers.getBytes(hash));
    return { amountPaid, nonce: this.nonce, signature: sig };
  }
}
module.exports = ChannelClient;
