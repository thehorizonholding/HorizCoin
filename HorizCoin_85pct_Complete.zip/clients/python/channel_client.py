import eth_account, eth_utils
from eth_account.messages import encode_defunct
class ChannelClient:
    def __init__(self, private_key, channel_address):
        self.priv = private_key
        self.channel = channel_address
        self.nonce = 0
    def sign_state(self, amount_paid):
        self.nonce += 1
        message = eth_utils.keccak(text=f"{self.channel}{amount_paid}{self.nonce}")
        acct = eth_account.Account.from_key(self.priv)
        sig = acct.sign_message(encode_defunct(message))
        return {"amount_paid": amount_paid, "nonce": self.nonce, "signature": sig.signature.hex()}
