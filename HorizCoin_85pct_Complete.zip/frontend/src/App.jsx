import React, { useEffect, useState } from 'react';
export default function App(){ const [nodes,setNodes]=useState([]);
useEffect(()=>{ fetch('http://localhost:3001/nodes').then(r=>r.json()).then(setNodes).catch(()=>setNodes([])); },[]);
return (<div style={{padding:20}}><h1>HorizCoin Dashboard</h1><h3>Nodes</h3><pre>{JSON.stringify(nodes,null,2)}</pre></div>); }