# DAO Proposal Template
Title:
Summary:
Motivation:
Specification:
Security considerations:
Implementation:
Voting parameters:
