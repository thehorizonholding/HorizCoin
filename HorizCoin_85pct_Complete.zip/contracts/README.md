Contracts folder: compile and test using the Hardhat scaffold in /hardhat. Ensure you run `npm ci` in hardhat and install OpenZeppelin in node_modules.
