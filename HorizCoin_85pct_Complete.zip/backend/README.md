Backend services: fleet_manager (Postgres), watchtower (node), other components. Configure DATABASE_URL before starting fleet_manager.
