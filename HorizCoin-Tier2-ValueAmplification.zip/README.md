HorizCoin Tier-2 Value Amplification Package
===========================================

Purpose:
This package implements optional, additive components to increase HorizCoin token value
(advanced tokenomics, AI-controlled supply, RL treasury buyback bot, multi-chain helper
contracts). It is explicitly designed **not to modify the original HorizCoin project**.
Copy these artifacts into a separate deployment repo or a new branch; integrate only after review.

Contents:
- ai_tokenomics_controller.py    # AI controller (simulator + policy output)
- rl_treasury_bot.py             # RL-based buyback & treasury manager (simulated training loop)
- contracts/DynamicSupply.sol    # Solidity contract stub for dynamic supply parameters (opt-in)
- contracts/TreasuryGuard.sol    # Treasury guard contract for buybacks (access-controlled)
- scripts/simulate_metrics.py    # Generates synthetic network metrics for testing controllers
- docs/IMPLEMENTATION_GUIDE.md   # Integration guide, safety notes, and recommended ops
- .env.example                   # env vars template

Usage:
1. Do NOT drop into original repo. Create a new integration branch or a separate repo.
2. Populate .env from .env.example and review docs/IMPLEMENTATION_GUIDE.md before use.
3. These are provided as **reference implementations**; before production, audit contracts and models.
