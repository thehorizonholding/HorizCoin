Implementation Guide - Tier-2 Value Amplification (Non-Invasive)
================================================================

Overview
--------
This package contains reference implementations for Tier-2 token value amplification.
They are intentionally additive and designed NOT to modify the original HorizCoin repo.
Integrate by deploying these components in a separate governance-controlled repo and
connecting via secure APIs, multisig transactions, and on-chain governance calls.

Components
----------
1. AI Tokenomics Controller (ai_tokenomics_controller.py)
   - Runs off-chain, ingests metrics (Prometheus/Grafana/Kafka) or simulated data.
   - Outputs policy recommendations: burn_rate, staking_yield, buyback_enabled.
   - Recommended flow: Controller emits signed proposals to a governance queue (Kafka or multisig proposal).

2. RL Treasury Bot (rl_treasury_bot.py)
   - Learns buyback policies via simulation and suggests buyback orders.
   - In production, actions should be executed by multisig-controlled relayers or via DAO proposals.
   - Do NOT allow autonomous on-chain transfers; use human or multisig approval.

3. DynamicSupply.sol & TreasuryGuard.sol
   - Optional contracts to store policy params and guard buybacks.
   - Governance must call updatePolicy() to apply changes. Never allow off-chain-only changes without DAO approval.

Security & Governance
---------------------
- All actions with financial effect must be governed by multisig (Gnosis Safe) or DAO votes.
- The AI controller must only propose; execution must require human/multisig confirmation.
- Never store private keys in code or plaintext env files. Use KMS and Vault.
- Audit all contracts and ML pipelines before mainnet use.

Operational Notes
-----------------
- Use canary deployments and simulate buybacks on testnet first.
- Keep treasury exposures diversified (USDC, ETH) to avoid single-asset risk.
- Maintain transparent logs and publish monthly treasury reports.
