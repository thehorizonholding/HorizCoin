#!/usr/bin/env python3
"""Generate synthetic metrics to feed controllers during testing."""
import json, time, random
def generate():
    return {
        'tx_rate': random.uniform(100, 15000),
        'active_nodes': random.randint(50, 50000),
        'liquidity_depth': random.uniform(5000, 2_000_000),
        'fiat_inflow_rate': random.uniform(0, 200000)
    }

if __name__ == '__main__':
    for i in range(20):
        print(json.dumps(generate()))
        time.sleep(0.5)
