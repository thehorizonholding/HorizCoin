# HorizCoin — 100% Code-Only Package (Artificial Completion)

Generated: 2025-11-23T22:35:01.954830Z

This package contains a code-only **simulation** of a fully completed HorizCoin system.

**Important:** This is purely a software representation. Real-world production completion requires audits, legal signoffs, custody, and real hardware. This archive *simulates* those pieces with mocks and emulators so you can run end-to-end tests locally.

Folders:
- contracts/: Full smart contracts (production-like) with tests
- hardhat/: Hardhat scaffold & scripts
- backend/: Fleet Manager (Postgres), Watchtower, KYC mock, Fiat On/Off mock
- clients/: JS & Python payment channel clients and watchtower client
- fleet_agent/: Enhanced agent with attestation emulator
- sdk/: JS & Python SDKs
- frontend/: React app with dashboards and simulated flows
- infra/: Dockerfiles, k8s manifests, helm placeholders
- docs/: whitepaper fragments, completion notes

Run instructions: See each service README. This package is intended for local simulation and testing only.
