#!/usr/bin/env bash
set -e
# This script assumes docker and docker-compose are installed
echo 'Starting docker-compose...'
docker-compose -f infra/docker-compose.yml up -d --build
sleep 8
# start hardhat tests
(cd hardhat && npm ci && npx hardhat test)
echo 'E2E complete (simulation)'
