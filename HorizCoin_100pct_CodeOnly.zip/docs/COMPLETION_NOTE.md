This package contains code implementations that simulate the final 15% of the project.
Simulated components include:
- Watchtower automated dispute submission (simulated on a local chain)
- Mock KYC provider and flow (HTTP service)
- Mock fiat on/off ramp service (HTTP service)
- Attestation emulator (software TPM-like responses)
- Watchtower incentivization simulation (token rewards via contracts)
- Automated test scripts to run full E2E in a Docker-compose environment (local)

This is a code-only artifact and not a substitute for real audits, hardware attestation, custody and legal compliance.
