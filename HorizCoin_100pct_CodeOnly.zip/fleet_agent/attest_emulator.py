import hashlib, json, time, uuid
# Attestation emulator - returns signed-like assertions for node hardware/software state
def emulate_attestation(node_id, pubkey):
    payload = {'node': node_id, 'pubkey': pubkey, 'ts': int(time.time()), 'nonce': uuid.uuid4().hex}
    sig = hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()
    return {'payload': payload, 'attestation_sig': sig}
if __name__=='__main__':
    print(emulate_attestation('node-emu','demo-pubkey'))