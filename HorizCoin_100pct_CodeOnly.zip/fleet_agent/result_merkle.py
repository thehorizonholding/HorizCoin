import hashlib
def hash_chunk(data): return hashlib.sha256(data).hexdigest()
def merkle_root(chunks):
    if not chunks: return None
    level = [hash_chunk(c) for c in chunks]
    while len(level) > 1:
        if len(level) % 2 == 1: level.append(level[-1])
        level = [hashlib.sha256((level[i]+level[i+1]).encode()).hexdigest() for i in range(0,len(level),2)]
    return level[0]
if __name__=='__main__':
    print(merkle_root([b'hello', b'world']))