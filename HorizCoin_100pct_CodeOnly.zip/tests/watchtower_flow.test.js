const { expect } = require("chai"); const { ethers } = require("hardhat");
describe("Watchtower & Channel integration", function () {
  it("allows watchtower to submit channel state and be rewarded", async function () {
    const [deployer, payer, payee, watcher] = await ethers.getSigners();
    const Token = await ethers.getContractFactory("hUSD");
    const token = await Token.deploy(ethers.parseUnits("10000",18));
    await token.waitForDeployment();
    // fund payer
    await token.transfer(payer.address, ethers.parseUnits("1000",18));
    // deploy channel directly
    const Channel = await ethers.getContractFactory("PaymentChannel");
    const expires = Math.floor(Date.now()/1000) + 3600;
    const channel = await Channel.deploy(token.target, payer.address, payee.address, expires);
    await channel.waitForDeployment();
    // payer funds channel
    await token.connect(payer).approve(channel.target, ethers.parseUnits("500",18));
    await channel.connect(payer).fund(ethers.parseUnits("500",18));
    // deploy WatchReward and ChannelHub
    const Watch = await ethers.getContractFactory("WatchReward");
    const watch = await Watch.deploy(ethers.parseUnits("1000",18));
    await watch.waitForDeployment();
    const Hub = await ethers.getContractFactory("ChannelHub");
    const hub = await Hub.deploy();
    await hub.waitForDeployment();
    await hub.connect(deployer).registerChannel(payer.address, channel.target);
    // Simulate off-chain signed state by payer
    const amountPaid = ethers.parseUnits("50",18);
    const nonce = 1;
    const abiCoder = ethers.AbiCoder.defaultAbiCoder;
    const msg = abiCoder.encode(['address','uint256','uint256'], [channel.target, amountPaid, nonce]);
    const hash = ethers.keccak256(msg);
    const sig = await payer.signMessage(ethers.getBytes(hash));
    // Watcher (simulate) requests hub to submit since payer is offline
    await hub.connect(deployer).submitStateIfOffline(channel.target, amountPaid, nonce, sig);
    const payeeBalance = await token.balanceOf(payee.address);
    expect(payeeBalance).to.equal(amountPaid);
  });
});