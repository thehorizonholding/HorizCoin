const express = require('express'); const bodyParser = require('body-parser'); const { Pool } = require('pg'); const basicAuth = require('express-basic-auth');
const app = express(); app.use(bodyParser.json());
// Basic auth for demo (replace with OAuth/JWT in prod)
app.use(basicAuth({ users: { 'admin': 'password' }, challenge: true }));
const pool = new Pool({ connectionString: process.env.DATABASE_URL || 'postgresql://postgres:postgres@localhost:5432/horiz' });
(async ()=>{ const c = await pool.connect(); await c.query(`CREATE TABLE IF NOT EXISTS nodes (id TEXT PRIMARY KEY, pubkey TEXT, capabilities JSON, last_seen TIMESTAMPTZ)`); c.release(); })();
app.post('/nodes/register', async (req,res)=>{ const {nodeId,pubKey,capabilities} = req.body; await pool.query('INSERT INTO nodes(id,pubkey,capabilities,last_seen) VALUES($1,$2,$3,now()) ON CONFLICT (id) DO UPDATE SET pubkey=$2,capabilities=$3,last_seen=now()', [nodeId,pubKey,capabilities]); res.json({status:'ok', nodeId}); });
app.get('/nodes', async (req,res)=>{ const r = await pool.query('SELECT id,pubkey,capabilities,last_seen FROM nodes'); res.json(r.rows); });
app.post('/metrics', async (req,res)=>{ console.log('metrics', req.body); res.json({status:'ok'}); });
const PORT = process.env.PORT || 3001; app.listen(PORT, ()=> console.log('Fleet Manager (prod) on', PORT));