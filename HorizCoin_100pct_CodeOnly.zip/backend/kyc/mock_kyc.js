const express = require('express'); const bodyParser = require('body-parser'); const app = express(); app.use(bodyParser.json());
// Simple KYC emulator - accepts any document and returns approved after a short delay
app.post('/kyc/submit', async (req,res)=>{ const {user, docs} = req.body; // simulate async review
  setTimeout(()=>{}, 1000); res.json({status:'approved', user}); });
app.get('/kyc/status/:user', (req,res)=>{ res.json({user:req.params.user, status:'approved'}); });
const PORT = process.env.PORT || 5001; app.listen(PORT, ()=> console.log('Mock KYC running', PORT));