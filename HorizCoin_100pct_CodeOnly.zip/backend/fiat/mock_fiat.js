const express = require('express'); const bodyParser = require('body-parser'); const app = express(); app.use(bodyParser.json());
app.post('/fiat/deposit', (req,res)=>{ const {user, amount, currency} = req.body; // simulate deposit -> issue hUSD on chain in tests via a webhook
  res.json({status:'pending', user, amount, currency}); });
app.post('/fiat/withdraw', (req,res)=>{ const {user, amount, currency, address} = req.body; res.json({status:'initiated', user, amount, currency, address}); });
const PORT = process.env.PORT || 5002; app.listen(PORT, ()=> console.log('Mock Fiat running', PORT));