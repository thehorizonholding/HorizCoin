const express = require('express'); const bodyParser = require('body-parser'); const axios = require('axios'); const app = express(); app.use(bodyParser.json());
// Simulated watchtower that will call a ChannelHub submit endpoint when a condition is met.
let watched = {};
app.post('/watch', (req,res)=>{ const {channel, state, callbackUrl} = req.body; watched[channel] = {state, callbackUrl, lastSeen:Date.now()}; res.json({status:'watching'}); });
// Periodic checker (in production should be robust)
setInterval(async ()=>{ for(const ch in watched){ const entry = watched[ch]; const {state, callbackUrl} = entry; try{ // call callbackUrl to submit state (simulated)
    if(callbackUrl){ await axios.post(callbackUrl, state, {timeout:5000}); console.log('submitted state for', ch); delete watched[ch]; }
  }catch(e){ console.error('submit failed', e.message); } } }, 5000);
app.get('/watched', (req,res)=> res.json(watched));
const PORT = process.env.PORT || 4001; app.listen(PORT, ()=> console.log('Watchtower running', PORT));