# HorizCoin UltraVersion (Core On-Chain Layer)

This zip contains the **core, fixed, and cleaned** Solidity contracts for the
HorizCoin UltraVersion project, ready to be added to GitHub and wired into your
existing Control-Center, AI, and DePIN infrastructure.

Contents:

- `contracts/HORCToken.sol` — ERC20 utility token (HORC).
- `contracts/HUSDMock.sol` — Mock hUSD stablecoin for local testing.
- `contracts/JobSettlementContract.sol` — Handles hUSD settlement and take-fee logic.
- `contracts/RevenueFlywheelContract.sol` — Swaps hUSD fees into HORC, then burns and
  distributes according to `burnSplitBps`.

You can use this as the **canonical on-chain core** and connect it to:

- Your existing Control-Center backend (for job orchestration),
- Your AI pricing & allocation agents,
- Your DePIN/compute infrastructure.

## Quick Notes

- All contracts use Solidity `^0.8.20` and OpenZeppelin primitives.
- In production, replace `HUSDMock` with a real stablecoin (USDC/USDT/etc).
- `RevenueFlywheelContract` expects a UniswapV2-style router at `dexRouter`.
- Governance (admin) can later be moved to a proper HORC-based DAO.

MIT license by default — adjust as needed.
