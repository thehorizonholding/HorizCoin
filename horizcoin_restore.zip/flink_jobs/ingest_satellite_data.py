# flink_jobs/ingest_satellite_data.py

from pyflink.table import EnvironmentSettings, TableEnvironment

def run_ingestion_job():
    settings = EnvironmentSettings.in_streaming_mode()
    t_env = TableEnvironment.create(settings)

    # Load required JARs (Kafka, JDBC, PostgreSQL)
    t_env.get_config().set(
        "pipeline.jars",
        "file:///opt/flink/lib/flink-sql-connector-kafka.jar;"
        "file:///opt/flink/lib/flink-connector-jdbc.jar;"
        "file:///opt/flink/lib/postgresql-42.7.3.jar"
    )

    # Kafka Source Table
    t_env.execute_sql("""
    CREATE TABLE kafka_raw_telemetry (
        satellite_id STRING,
        `timestamp` TIMESTAMP_LTZ(3),
        latitude DOUBLE,
        longitude DOUBLE,
        raw_data STRING
    ) WITH (
        'connector' = 'kafka',
        'topic' = 'satellite_raw_data',
        'properties.bootstrap.servers' = 'kafka-service.default.svc.cluster.local:9092',
        'properties.group.id' = 'flink-ingestion-group',
        'format' = 'json',
        'scan.startup.mode' = 'latest-offset'
    )
    """)

    # PostgreSQL Sink Table
    t_env.execute_sql(f"""
    CREATE TABLE postgres_sink (
        satellite_id STRING,
        `timestamp` TIMESTAMP_LTZ(3),
        latitude DOUBLE,
        longitude DOUBLE,
        raw_data STRING
    ) WITH (
        'connector' = 'jdbc',
        'url' = 'jdbc:postgresql://postgres-service.default.svc.cluster.local:5432/horizcoin_db',
        'table-name' = 'satellite_telemetry',
        'username' = '{{POSTGRES_USER}}',
        'password' = '{{POSTGRES_PASSWORD}}'
    )
    """)

    table_from_kafka = t_env.from_path("kafka_raw_telemetry")
    processed_table = table_from_kafka.select(
        "satellite_id, `timestamp`, latitude, longitude, raw_data"
    )

    statement_set = t_env.create_statement_set()
    statement_set.add_insert("postgres_sink", processed_table)

    print("🚀 Starting Flink ingestion job: Kafka → PostgreSQL")
    job_result = statement_set.execute()
    job_result.wait()

if __name__ == "__main__":
    run_ingestion_job()
