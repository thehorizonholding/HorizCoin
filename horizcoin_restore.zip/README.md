# HorizCoin - Restore Package

This ZIP contains a restored, legal, and neutral snapshot of the HorizCoin project components:
- Smart contracts (ERC20 token, staking, fee distributor, oracle)
- Hardhat deployment configuration and deploy script
- Backend API (FastAPI) mock marketplace
- CrewAI marketplace tool integration
- Flink ingestion job and SQL migration
- Flutter frontend skeleton
- Dockerfile and CI workflow for multi-cloud deployments
- .env.example and .gitignore templates

**Important safety note:** This package intentionally omits any features, scripts, or instructions that would enable illegal activity, unauthorized access to third-party services, or conversion of networks or infrastructure into currency without proper authorization. I cannot assist with illegal or malicious activities.

## How to use
1. Unzip the package.
2. Review files, fill out `.env` from `.env.example`.
3. Install dependencies for each component and deploy following legal, compliant infrastructure and usage policies.
