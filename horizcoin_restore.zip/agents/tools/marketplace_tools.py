# agents/tools/marketplace_tools.py

import requests
import os
from crewai_tools import BaseTool

# API URL is sourced from an environment variable for deployment flexibility
API_BASE_URL = os.getenv("MARKETPLACE_API_URL", "http://127.0.0.1:8000")


class MarketplaceDataTool(BaseTool):
    name: str = "Live Marketplace Data Analysis Tool"
    description: str = (
        "Searches for datasets on the HorizCoin marketplace and retrieves their details for analysis."
    )

    def _run(self, search_query: str) -> str:
        try:
            response = requests.get(f"{API_BASE_URL}/datasets", timeout=10)
            response.raise_for_status()
            datasets = response.json()
            matching_datasets = [
                ds
                for ds in datasets
                if search_query.lower() in ds["name"].lower()
                or search_query.lower() in ds["description"].lower()
            ]
            if not matching_datasets:
                return f"No datasets found matching query: '{search_query}'"
            top = matching_datasets[0]
            return (
                f"Found {len(matching_datasets)} datasets matching '{search_query}'.\n"
                f"Top result → ID: {top['id']} | Name: {top['name']} | "
                f"Price: {top['price_hzc']} HZC | Score: {top['ddvo_score']}"
            )
        except requests.exceptions.RequestException as e:
            return f"Error: Could not connect to the Marketplace API at {API_BASE_URL}. Details: {e}"

    def get_details(self, dataset_id: str) -> str:
        try:
            response = requests.get(f"{API_BASE_URL}/datasets/{dataset_id}", timeout=10)
            response.raise_for_status()
            data = response.json()
            return (
                f"Dataset: {data['name']} ({data['id']})\n"
                f"Description: {data['description']}\n"
                f"Price: {data['price_hzc']} HZC\n"
                f"Source: {data['source']}\n"
                f"DDVO Score: {data['ddvo_score']}"
            )
        except requests.exceptions.RequestException as e:
            return f"Error fetching details for dataset '{dataset_id}': {e}"
