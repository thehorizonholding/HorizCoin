// scripts/deploy-and-verify.js
const hre = require("hardhat");
const { run, network } = hre;

async function main() {
  const [deployer] = await hre.ethers.getSigners();
  console.log("Deploying contracts with the account:", deployer.address);

  // Deploy HorizCoin Token
  const HorizCoin = await hre.ethers.getContractFactory("HorizCoin");
  const horizCoin = await HorizCoin.deploy(deployer.address);
  await horizCoin.waitForDeployment();

  const horizCoinAddress = await horizCoin.getAddress();
  console.log("HorizCoin (HZC) deployed to:", horizCoinAddress);

  // Wait for block confirmations before verifying
  if (network.config.chainId !== 31337) {
    console.log("Waiting for 6 block confirmations...");
    await horizCoin.deploymentTransaction().wait(6);
    console.log("Confirmed!");
  }

  // Verify the contract on Etherscan (only for Sepolia)
  if (network.config.chainId === 11155111 && process.env.ETHERSCAN_API_KEY) {
    console.log("Verifying contract on Etherscan...");
    await verify(horizCoinAddress, [deployer.address]);
  }
}

// Programmatic verification function
async function verify(contractAddress, args) {
  console.log("Verifying contract at:", contractAddress);
  try {
    await run("verify:verify", {
      address: contractAddress,
      constructorArguments: args,
    });
    console.log("✅ Contract verified successfully on Etherscan!");
  } catch (e) {
    if (e.message.toLowerCase().includes("already verified")) {
      console.log("ℹ️ Contract is already verified.");
    } else {
      console.error("❌ Verification failed:", e);
    }
  }
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
