# Token Launchpad (Placeholder)

Future work:

- Web UI flow to deploy new tokens.
- Smart contract templates.
- Fee routing into the HorizCoin flywheel.

Add a `launchpad/frontend` and `launchpad/contracts` when you are ready.
