from sqlalchemy.orm import declarative_base, relationship
from sqlalchemy import Column, Integer, String, DateTime, Float, Enum, ForeignKey, JSON, func

Base = declarative_base()

class Node(Base):
    __tablename__ = "nodes"

    id = Column(Integer, primary_key=True, index=True)
    address = Column(String, unique=True, index=True)
    kind = Column(String)  # gpu / iot / router
    status = Column(String, default="offline")
    last_heartbeat = Column(DateTime, server_default=func.now())

class Job(Base):
    __tablename__ = "jobs"

    id = Column(Integer, primary_key=True, index=True)
    external_id = Column(String, unique=True, index=True)
    client_address = Column(String, index=True)
    status = Column(String, default="queued")  # queued / running / completed / failed
    payload = Column(JSON)
    node_id = Column(Integer, ForeignKey("nodes.id"))
    node = relationship("Node")
    price_husd = Column(Float, default=0.0)
