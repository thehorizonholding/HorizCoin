# RL Engine (Stub)

This directory contains **stubs** for RL agents:

- `pricing/` – Decides job prices (hUSD).
- `allocation/` – Decides which node to assign each job to.

You should replace these with real RL code (e.g. Stable-Baselines3, RLlib, etc.).
