from typing import List, Dict, Any
import random

class AllocationAgent:
    """Reputation-aware placeholder allocation agent.

    - Filters to online nodes.
    - Uses a simple weighted-random choice based on `reputation` field
      (defaulting to 1 if missing).
    """

    def choose_node(self, nodes: List[Dict[str, Any]]) -> Dict[str, Any]:
        available = [n for n in nodes if n.get("status") == "online"]
        if not available:
            raise RuntimeError("No available nodes")

        # Reputation-weighted random choice
        weights = []
        for n in available:
            rep = n.get("reputation", 1.0)
            try:
                rep_val = float(rep)
            except Exception:
                rep_val = 1.0
            if rep_val <= 0:
                rep_val = 1.0
            weights.append(rep_val)

        total = sum(weights)
        r = random.random() * total
        acc = 0.0
        for node, w in zip(available, weights):
            acc += w
            if r <= acc:
                return node

        # Fallback
        return available[-1]
