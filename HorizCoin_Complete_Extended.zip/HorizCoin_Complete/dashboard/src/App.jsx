import React, { useEffect, useState } from "react";

const API_BASE = "http://localhost:8000/api";

export default function App() {
  const [jobs, setJobs] = useState([]);

  useEffect(() => {
    fetch(`${API_BASE}/jobs`)
      .then((r) => r.json())
      .then(setJobs)
      .catch((err) => console.error("Failed to load jobs", err));
  }, []);

  return (
    <div style={{ fontFamily: "system-ui, sans-serif", padding: "1.5rem" }}>
      <h1>HorizCoin Control-Center</h1>
      <p>Minimal dashboard stub.</p>

      <section>
        <h2>Jobs</h2>
        {jobs.length === 0 ? (
          <p>No jobs yet.</p>
        ) : (
          <table border="1" cellPadding="6">
            <thead>
              <tr>
                <th>ID</th>
                <th>External ID</th>
                <th>Status</th>
                <th>Node</th>
                <th>Price (hUSD)</th>
              </tr>
            </thead>
            <tbody>
              {jobs.map((j) => (
                <tr key={j.id}>
                  <td>{j.id}</td>
                  <td>{j.external_id}</td>
                  <td>{j.status}</td>
                  <td>{j.node_id ?? "-"}</td>
                  <td>{j.price_husd.toFixed(4)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>
    </div>
  );
}
