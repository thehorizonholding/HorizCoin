# Multi-Chain Bridge (Placeholder)

Implement here:

- Cross-chain messaging (LayerZero, Axelar, Wormhole, etc.)
- Token mapping logic for HORC/hUSD.
- Scripts to deploy contracts on multiple chains.

This is out of scope for this scaffold but the directory is reserved.
