import time
import requests

CONTROL_CENTER_URL = "http://localhost:8000/api"

def main():
    node_address = "0xSTORAGE_NODE"
    kind = "storage"

    # Register storage node
    try:
        requests.post(f"{CONTROL_CENTER_URL}/nodes/register", json={
            "address": node_address,
            "kind": kind,
        })
        print("Storage agent registered and running (stub).")
    except Exception as e:
        print("Failed to register storage node:", e)

    while True:
        # TODO: poll for storage jobs (upload/download tasks), handle them,
        # and report back to Control-Center for settlement.
        time.sleep(7)


if __name__ == "__main__":
    main()
