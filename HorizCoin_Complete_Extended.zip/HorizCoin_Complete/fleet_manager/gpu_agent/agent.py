import time
import requests

CONTROL_CENTER_URL = "http://localhost:8000/api"

def main():
    node_address = "0xGPU_NODE"
    kind = "gpu"

    # Register node
    requests.post(f"{CONTROL_CENTER_URL}/nodes/register", json={
        "address": node_address,
        "kind": kind,
    })

    print("GPU agent registered and running (stub).")
    while True:
        # TODO: poll for jobs, run them, report results
        time.sleep(5)


if __name__ == "__main__":
    main()
