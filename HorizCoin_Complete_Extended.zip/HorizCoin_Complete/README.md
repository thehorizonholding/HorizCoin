# HorizCoin Complete Scaffold

This archive is a **scaffolded implementation** of the HorizCoin architecture:
DePIN + RL pricing/allocation + blockchain settlement + dashboard + agents.

> Important: This is **not** the official HorizCoin code and is not production-ready.
> It is a starting template you can expand and integrate into your own GitHub repo.

## Structure

- `contracts/` – Solidity stubs for HORC, hUSD, and settlement/flywheel contracts.
- `control_center/` – Python FastAPI backend for job orchestration and billing.
- `rl_engine/` – RL stubs for pricing and allocation agents.
- `fleet_manager/` – Simple GPU / IoT / router agent daemons.
- `dashboard/` – Minimal React dashboard skeleton.
- `zk_verification/` – Placeholder for future ZK compute verification.
- `bridge/` – Placeholder for multi-chain settlement bridge.
- `launchpad/` – Placeholder for token launchpad tooling.

You can place this folder in your HorizCoin repo and commit it as a starting
implementation, then iterate on each component.

## New: Internet-to-Currency Extensions

This extended scaffold adds:

- **Compute-as-currency (refined):** Nodes earn for running jobs (already core).
- **Reputation-based rewards:** Nodes accumulate reputation for good behavior; can be used to weight rewards or scheduling.
- **Storage-as-currency:** Storage agents can register and eventually serve storage jobs.
- **AI interaction-as-currency:** A separate `ai_interaction` microservice scaffold for rewarding feedback / human-AI interaction tasks.
