from fastapi import FastAPI
from pydantic import BaseModel
from typing import List
from datetime import datetime

app = FastAPI(title="HorizCoin AI Interaction Service (Stub)")

class Feedback(BaseModel):
    user_id: str
    session_id: str
    prompt: str
    ai_response: str
    rating: int  # e.g. 1-5
    tags: List[str] = []

# In-memory store for demo purposes only.
FEEDBACK_STORE = []


@app.post("/feedback")
def submit_feedback(body: Feedback):
    record = {
        **body.dict(),
        "timestamp": datetime.utcnow().isoformat() + "Z",
    }
    FEEDBACK_STORE.append(record)
    # In a real system, this would:
    # - Forward signal to RLHF / training pipelines.
    # - Compute reward credits.
    # - Notify Control-Center for settlement.
    return {"status": "ok", "stored": True}


@app.get("/feedback")
def list_feedback():
    # NOTE: do not expose this in production without auth / privacy controls.
    return FEEDBACK_STORE
