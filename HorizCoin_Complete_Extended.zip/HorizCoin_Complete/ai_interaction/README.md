# AI Interaction Service (Stub)

This microservice is meant to turn *human-AI interaction* into value inside the HorizCoin
ecosystem. Example use cases:

- Users rank AI responses.
- Users provide preference feedback.
- Users label small datasets.

Each interaction can be recorded here and later rewarded via the main settlement system.
