
# Tokenomics — Multi-Token Design

## Tokens
- **HC-UTILITY (HORC)**: ERC-20 compatible token used as primary payment medium. Supports off-chain channels (state channels) for micropayment batching.
- **hUSD**: Stablecoin (algorithmic or collateralized) used for price denomination and settlement for large value contracts.
- **HC-REWARD**: Reward token for staking, governance, and long-term incentives. Subject to vesting schedules.
- **HC-ASSET**: Compliant RWA wrapper tokens represented by tokenized legal claims; issuance requires KYC and is subject to securities regulation.

## Economic Flows
- Job buyer pays hUSD price quoted by RL engine.
- 80% of gross job payment credited to Node Operators (in hUSD or HC-UTILITY via market conversion).
- 20% directed to protocol flywheel (treasury/buyback/burn/HC-REWARD distribution).

## QoS Weighted Payout Formula
Reward = EpochReward * (W_B * norm(B) + W_A * norm(A) + W_C * norm(C) + W_D * norm(D))
Where W_B=0.35, W_A=0.25, W_C=0.20, W_D=0.20 and norm(x) is normalized metric in epoch.

## Anti-Front-Running & Fairness
- Randomized job assignment windows, cryptographic commitments for bids, and penalty slashing for misreporting.
