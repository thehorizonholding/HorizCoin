
# Architecture Overview

This document maps modules to the blueprint and provides component responsibilities, APIs and integration points.

## Components
- **Dashboard/UI**: Web apps and mobile apps for users, creators and node operators.
- **Control-Center API**: Central API gateway for job submission, bidding, and scheduling.
- **RL Pricing Engine**: Real-time pricing (reinforcement learning) for dynamic market clearing.
- **Fleet Manager**: Schedules jobs, enforces QoS, collects telemetry and issues payouts.
- **Fleet Agent**: Edge agent running on nodes; provides resource advertisement and secure attestation.
- **Settlement Layer**: Smart contracts and layer-2 payment channels.
- **Oracles & Attestation Services**: Provide external price and identity data; ZK/TPA services for proofs.

## Data Flow Summary
1. Job submitted via Dashboard -> Control-Center -> Fleet Manager.
2. Fleet Manager matches job with Node Operators using bidding and QoS filters.
3. Node executes job, reports proofs/attestations, and publishes QoS telemetry.
4. Settlement triggered: hUSD quoted -> HC-UTILITY/hUSD payment channels settled -> reward distribution.

## Mapping to Repo
- /contracts -> smart contracts for tokens and settlement.
- /network -> fleet & agent specs.
- /protocol -> API and message specs.
- /docs -> whitepaper, design docs.
