
# Project HorizCoin — Whitepaper (Polished)

## Abstract
HorizCoin is an integrated protocol and infrastructure stack designed to maximize Universal Decentralized Financial Utility (UDFU): enabling economic earning across the internet's functional surface by capturing value from four pillars — Decentralized Physical Infrastructure Networks (Depin), Decentralized Social (DeSoc) attention/data, Machine-to-Machine (M2M)/AI autonomous commerce, and Real-World Asset (RWA) tokenization. The project's core objective is to create a resilient multi-token, multi-layer architecture that enables micropayments at global scale while meeting pragmatic regulatory constraints.

## 1. Introduction & Motivation
The modern internet generates enormous value — value that is concentrated by centralized intermediaries. HorizCoin's mission is to decouple economic capture from centralized platforms and enable any actor (human, device, or machine) to earn HC-UTILITY tokens for providing services, attention, data, compute, storage, and bandwidth. The protocol is engineered for extremely high-throughput, low-fee micropayments, programmable economic incentives, verifiable QoS, and composable financial rails connecting to traditional capital markets via HC-ASSET tokens.

## 2. Problem Statement & Design Goals
- Enable global micro-earning across human, machine and hardware participants.
- Provide low-latency, low-cost settlement for sub-cent transactions.
- Isolate regulatory exposure via multi-token separation of concerns.
- Incentivize high QoS via verifiable performance and reputation.
- Support RWA integration while preserving utility classification for transactional tokens.
- Ship auditable, upgradeable smart contracts and secure fleet orchestration systems.

## 3. System Overview
HorizCoin is composed of three interacting layers:
1. **Edge / Fleet Layer (Depin)** — Node Operators run a Fleet Agent to register compute, storage, and bandwidth. Jobs are scheduled by the Fleet Manager with QoS measurements reported on-chain or via verifiable off-chain proofs (ZK/attestations).
2. **Protocol Layer (Settlement & Token Layer)** — Multi-token ledger including HC-UTILITY (low-fee transactional token), hUSD (stable settlement for pricing), HC-REWARD (staking/reward token), and HC-ASSET (tokenized RWAs). Settlement supports layer-2 channels and rollups for micropayment scaling.
3. **Application Layer (DeSoc, M2M, Data Markets)** — Interfaces, SDKs and agent frameworks enabling creators, devices and autonomous agents to monetize interactions and data via micropayment hooks and standardized APIs.

## 4. Token Architecture
- **HC-UTILITY**: Native utility token for service payments. Engineered for minimal friction. Supports payment channels and off-chain accounting to enable high TPS.
- **hUSD**: Native stable settlement token used for price denominated contracts and to reduce volatility risk in compute pricing.
- **HC-REWARD**: Inflationary or protocol-funded token for long-term rewards, governance, and staking incentives.
- **HC-ASSET**: Wrapped, compliant tokens representing RWAs; issued under controlled KYC/AML compliance and potentially restricted to accredited participants in some jurisdictions.

Separation of these roles reduces legal risk and enables different economic behaviors while keeping the utility token non-security in design intent.

## 5. Earning Pillars
### 5.1 Depin: Compute, Storage, Bandwidth
- Node Operators receive HC-UTILITY per job; a QoS formula weights Bandwidth (35%), Compute (25%), GPU Model (20%) and Uptime (20%) to calculate epoch payouts.
- Storage pricing is tiered by storage class and retrieval operations.
- Bandwidth capture pricing aligns with market benchmarks but remains competitive to encourage participation.

### 5.2 DeSoc: Data & Attention
- Profile NFTs and DeSoc identity frameworks enable users to monetize follows, posts, and micro-interactions.
- Micropayment hooks permit tipping, pay-per-interaction, and subscription micro-billing using HC-UTILITY.
- Agentic data monetization supports user agents negotiating data licenses with automated micropayments.

### 5.3 M2M: IoT & Autonomous Agents
- Payment channels and off-chain settlement enable ultra-low-value exchanges between devices.
- Autonomous AI Agents (AAAs) can operate within the HorizCoin economy to perform trading, data brokerage, or execute service orchestration, settling fees in HC-UTILITY.

### 5.4 RWA: Tokenized Financial Capital
- HC-ASSET tokens are constructed with explicit compliance wrappers and legal structures.
- RWA provides passive yield and brings institutional liquidity into the ecosystem while remaining operationally segregated from HC-UTILITY.

## 6. Protocol Details (summary)
- On-chain ledger built to support layer-2 settlement (channels, rollups).
- QoS data is verifiable via attestation or ZK proofs; critical metrics are recorded in epochs to calculate payouts.
- Arbitration and dispute resolution are defined via on-chain governance contract and off-chain arbitration committees (hybrid model).
- Bridges to other chains and oracles for price feeds and RWA data.

## 7. Security, Privacy & Compliance
- Smart contract audits and bounty programs are mandatory before mainnet launches.
- KYC/AML enforcement for HC-ASSET issuance; optional KYC for node registration depending on jurisdiction and deployment mode.
- Privacy-preserving techniques (selective disclosure, ZK attestation) to allow user/on-device privacy while enabling verifiable economic claims.

## 8. Economic Model & Sustainability
- Fee-split design (e.g., 80% to providers, 20% to protocol flywheel) drives liquidity and buyback mechanics.
- Dynamic pricing oracles and RL-based pricing engine ensure market-clearing prices across compute, storage and bandwidth markets.
- Treasury and reserve allocations enable bootstrap liquidity and continuous incentives while minimizing inflationary pressure.

## 9. Governance & Roadmap (see /roadmap/ROADMAP.md)
- Multi-sig and DAO governance for protocol-level changes; permissioned governance for HC-ASSET issuance.\n
## 10. Conclusion\nHorizCoin is a practical blueprint to enable ubiquitous earning across the internet's functional surface. The project balances ambition with regulatory pragmatism via token segregation and a layered technical architecture centered on verifiable QoS, micropayment scalability, and composability.\n\n---\n(End of whitepaper summary)