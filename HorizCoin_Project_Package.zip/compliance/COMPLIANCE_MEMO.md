
# Compliance Memo — Regulatory Posture

## Summary
HorizCoin separates functions across tokens to reduce regulatory exposure:
- HC-UTILITY: transactional consumption token (design intent: non-security).
- HC-REWARD: governance and reward token (may have taxable treatment).
- HC-ASSET: tokens representing RWAs, issued under KYC/AML and securities compliance regimes.

## Global Considerations
- EU (MiCA): Stablecoins and asset-referenced tokens must comply. Plan to register relevant issuances as required.
- US (SEC/FinCEN): HC-ASSET token issuance to be structured to avoid unregistered securities exposure, or to be offered via compliant exempt mechanisms (Reg D, Reg S, Reg A+ where applicable). FinCEN AML obligations for money transmitter activities — integrate compliant KYC/AML flows for fiat on/off ramps.
- Jurisdictional deployment: Support "permissioned" nodes and markets in restricted jurisdictions; allow opt-in/off-chain settlement in closed deployments.

## Recommended Controls
- KYC/AML provider integrations for HC-ASSET issuance and large-value settlements.
- On-chain flags and role-based access controls for issuance functions.
- Comprehensive audit logs and legal wrapper templates for RWA issuances.
