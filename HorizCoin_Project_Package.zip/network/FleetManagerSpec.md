
# Fleet Manager & Fleet Agent Specification

## Objectives
- Low-latency scheduling of containerized workloads.
- QoS telemetry collection and epoch-based payouts.
- Secure attestation of device identity and hardware fingerprinting.

## QoS Metrics
- Bandwidth (Mbps)
- Compute (job units completed)
- GPU Model Score (indexed)
- Uptime (% over epoch)
- Optional: Latency, packet loss, IOPS

## Fleet Agent Responsibilities
- Advertise resources and capabilities to Fleet Manager.
- Enforce sandboxed execution (containers) and report signed telemetry.
- Support remote attestation (TPM/TEE) where available.
- Provide secure update path for agent software.

## Fleet Manager Responsibilities
- Match jobs to nodes using RL pricing engine and QoS filters.
- Maintain reputation and stake-based prioritization.
- Aggregate epoch telemetry, compute payouts using tokenomics formula.
