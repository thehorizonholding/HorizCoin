# HorizCoin — Universal Decentralized Financial Utility (UDFU)

This repository package contains the full project deliverables for **Project HorizCoin**: a blueprint, whitepaper, protocol and starter code to build a Global Earning Infrastructure intended to monetize the functional surface area of the internet across four pillars: Depin (compute/hardware), DeSoc (human attention/data), M2M/AI (autonomous agents/IoT), and RWA (real-world assets).

Files included:
- /docs/WHITEPAPER.md — Full polished whitepaper
- /docs/ARCHITECTURE.md — System architecture and component mapping
- /docs/TOKENOMICS.md — Multi-token economic model
- /protocol/PROTOCOL_SPEC.md — Protocol and APIs
- /network/FleetManagerSpec.md — Fleet management and QoS
- /contracts/HORC.sol — Utility token (skeleton)
- /contracts/hUSD.sol — Stable settlement token (skeleton)
- /contracts/HCReward.sol — Reward token (skeleton)
- /contracts/HCAsset.sol — RWA asset token (skeleton, compliance comments)
- /compliance/COMPLIANCE_MEMO.md — Regulatory & compliance posture
- /roadmap/ROADMAP.md — Milestones and audit plan
- /scripts/deploy.sh — Deployment helper (placeholder)
- LICENSE, .gitignore

This package is a starting point and contains specification documents and code skeletons intended for review, iteration and auditing. Read the whitepaper first.
