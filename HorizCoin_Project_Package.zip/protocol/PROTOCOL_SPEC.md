
# Protocol Specification

## Goals
- High-throughput micropayments
- Verifiable QoS and dispute resolution
- Composable APIs for DeSoc, M2M, Depin and RWA

## APIs (summary)
- POST /jobs — submit a job (JSON: jobSpec, priceCap, ttl, requiredResources)
- GET /jobs/{id}/status — job status and telemetry
- POST /nodes/register — node registration and attestation
- POST /nodes/{id}/proofs — submit execution proof (signed)
- POST /settlement/claim — trigger payout for epoch

## Payment Channels
- Layer-2 channels with HTLC-like constructs for conditional settlement based on proofs.
- Support for state-signed micro-invoices and aggregated settlement transactions.

## Oracles & Proofs
- Oracles for hUSD exchange rates, GPU performance scores, and RWA valuations.
- ZK/attestation pipeline for workload completion proofs (future work: ZK-rollups).
