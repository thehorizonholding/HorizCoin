
# Roadmap & Audit Plan

## Phase 0 — Specification & Research (Done)
- Whitepaper, token design, architecture spec.

## Phase 1 — Core Prototype (0-3 months)
- Fleet Agent + Fleet Manager prototype.
- hUSD and HC-UTILITY test contracts (ERC-20).
- Basic job submission API and UI mockups.
- Internal security review.

## Phase 2 — Pilotnet (3-9 months)
- Layer-2 payment channels, QoS telemetry pipeline.
- UX for node onboarding and payouts.
- First public audit of token contracts.
- Integration with KYC/AML provider for HC-ASSET pilot.

## Phase 3 — Mainnet Launch (9-18 months)
- Cross-chain bridges, governance DAO launch, RWA issuance marketplace.
- Bug bounties and formal third-party audits.

## Ongoing
- Security hardening, ZK-proof integration, RL pricing engine improvements.
