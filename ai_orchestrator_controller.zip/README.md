# AI Orchestrator Controller (Chat-like interface)

This scaffold provides a **safe, auditable chat-like controller** for your project's orchestrator.
It accepts natural-language commands over a simple HTTP API and maps them to safe, policy-checked
orchestrator operations (dry-run by default).

Key features:
- Chat-style API (`/chat`) that accepts user prompts and returns structured plans or simulated actions.
- Policy engine that blocks disallowed activities (mining, unauthorized network use, data exfiltration).
- Human-approval workflow: actions that change infrastructure require an explicit `approve` call.
- Audit logging of all prompts, decisions, and attempted actions (append-only JSON log).
- Connector to your existing orchestrator's simulation endpoints (reuses orchestrator add-on patterns).
- Config-driven, secrets kept out of code (use env vars or Vault).

IMPORTANT:
- This scaffold is **intentionally conservative**: it never performs high-risk actions automatically.
- Replace or extend connectors only after security review and with credentials stored in a secrets manager.
- Do not use this to perform illegal or unauthorized operations.

Quickstart (development):
1. Create a Python 3.11 virtualenv and install requirements:
   ```bash
   python -m venv .venv
   source .venv/bin/activate
   pip install -r requirements.txt
   ```
2. Run the app locally:
   ```bash
   python ai_controller/app.py
   ```
3. Example request (dry-run):
   ```bash
   curl -X POST http://localhost:8088/chat -H "Content-Type: application/json" -d '{"user":"alice","prompt":"Ingest latest sentinel scenes for region X and show storage estimate"}'
   ```

Files in this package:
- `ai_controller/app.py`           : Flask HTTP server and chat endpoint
- `ai_controller/policy.py`        : Policy engine to block disallowed ops
- `ai_controller/orchestrator_client.py` : Lightweight client to talk to orchestrator (simulate/execute)
- `ai_controller/audit_log.py`     : Append-only audit log helper
- `ai_controller/actions.py`       : Mapping of high-level actions to orchestrator calls (dry-run)
- `requirements.txt`
- `.github/workflows/ci.yml`       : CI that runs unit checks and policy scan

Want me to integrate this with a real LLM (OpenAI / Azure / local LLM) for natural-language parsing?
I can add that after you confirm which provider and API keys you'll use.
