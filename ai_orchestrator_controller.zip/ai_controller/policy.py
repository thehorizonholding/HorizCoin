# ai_controller/policy.py - simple policy engine that blocks disallowed operations
from typing import Tuple, Dict, Any, List
DISALLOWED_KEYWORDS = ['mine','mining','cryptominer','botnet','steal','exploit','coin','mint','unauthorized','exfiltrate']

class PolicyEngine:
    def __init__(self):
        # You can extend policies: allowed_regions, max_egress_gb, provider_whitelist, etc.
        self.allowed_actions = ['ingest','process','list','status','plan','deploy_safe_service']
        self.max_egress_gb = 10000  # example policy gate

    def check_plan(self, plan: Dict[str,Any]) -> Tuple[bool, List[str]]:
        """Return (blocked:boolean, reasons:list)"""
        reasons = []
        action = plan.get('action')
        if action not in self.allowed_actions:
            reasons.append(f'action {action} is not allowed by policy')
        payload = str(plan.get('payload','')).lower()
        for k in DISALLOWED_KEYWORDS:
            if k in payload:
                reasons.append(f'payload contains disallowed keyword: {k}')
        # egress check
        if plan.get('payload',{}).get('expected_egress_gb',0) > self.max_egress_gb:
            reasons.append('expected_egress_gb exceeds policy maximum')
        return (len(reasons) > 0, reasons)
