# ai_controller/audit_log.py - append-only JSONL audit log
import json, time, os
from typing import Dict, Any

class AuditLog:
    def __init__(self, path='ai_controller_audit.jsonl'):
        self.path = path
        # ensure file exists
        open(self.path, 'a').close()

    def _append(self, record: Dict[str,Any]):
        record['ts'] = int(time.time())
        with open(self.path, 'a') as f:
            f.write(json.dumps(record) + '\n')
        return record.get('id')

    def log_prompt(self, user, prompt, context=None):
        rec = {'type':'prompt','id':'p-'+str(int(time.time()*1000)),'user':user,'prompt':prompt,'context': context or {}}
        self._append(rec)
        return rec['id']

    def log_blocked(self, entry_id, plan, reasons):
        rec = {'type':'blocked','id':'b-'+str(int(time.time()*1000)),'entry_id': entry_id,'plan':plan,'reasons': reasons}
        self._append(rec)
        return rec['id']

    def log_simulation(self, entry_id, plan, simulation):
        rec = {'type':'simulation','id':'s-'+str(int(time.time()*1000)),'entry_id':entry_id,'plan':plan,'simulation':simulation}
        self._append(rec)
        return rec['id']

    def log_execution(self, entry_id, approver, result):
        rec = {'type':'execution','id':'e-'+str(int(time.time()*1000)),'entry_id':entry_id,'approver':approver,'result':result}
        self._append(rec)
        return rec['id']

    def get_plan_for_entry(self, entry_id):
        # naive scan (for demo). In prod use DB with indexes or object store
        with open(self.path) as f:
            for line in f:
                obj = json.loads(line)
                if obj.get('type') == 'simulation' and obj.get('entry_id') == entry_id:
                    return obj.get('plan')
        return None
