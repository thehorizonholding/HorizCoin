# ai_controller/actions.py - map natural-language prompts to safe plans and simulate/execute them
import re, json
from ai_controller.orchestrator_client import simulate_ingest, execute_ingest

class ActionRouter:
    def __init__(self):
        pass

    def plan_from_prompt(self, prompt, context=None):
        """Very small heuristic-based NL -> plan mapper (replace with LLM parsing in prod)"""
        p = prompt.lower()
        # ingest request
        m = re.search(r'ingest\s+latest\s+(?P<dataset>\w+)\s+for\s+region\s+(?P<region>[\w-]+)', p)
        if m:
            return {'action':'ingest','payload':{'dataset': m.group('dataset'),'region': m.group('region'),'provider': context.get('provider','satellite') , 'expected_egress_gb': 10}}
        # list offers
        if 'list offers' in p or 'show offers' in p:
            return {'action':'list','payload':{}}
        # status
        if 'status' in p:
            return {'action':'status','payload':{}}
        # default to plan request
        return {'action':'plan','payload':{'text': prompt}}

    def simulate_plan(self, plan):
        action = plan.get('action')
        payload = plan.get('payload',{})
        if action == 'ingest':
            return simulate_ingest(payload.get('dataset'), payload.get('provider'))
        if action == 'list':
            return {'offers': []}
        if action == 'status':
            return {'status': 'orchestrator-ok'}
        return {'plan_summary': 'no-op simulation'}

    def execute_plan(self, plan, approver='unknown'):
        # very careful: only a few safe actions allowed to execute in this scaffold
        action = plan.get('action')
        payload = plan.get('payload',{})
        if action == 'ingest':
            # execute via orchestrator client (which must itself enforce auth & policy)
            return execute_ingest(payload.get('dataset'), payload.get('provider'))
        return {'error':'execution not supported for this action'}
