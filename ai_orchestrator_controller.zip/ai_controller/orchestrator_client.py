# ai_controller/orchestrator_client.py - small client to talk to orchestrator (simulate/execute)
# This is a thin wrapper that calls your orchestrator (the orchestrator add-on you added earlier)
import os, requests, json

ORCH_BASE = os.environ.get('ORCH_BASE', 'http://localhost:8080')  # default orchestrator endpoint

def simulate_ingest(dataset_id, provider):
    url = f"{ORCH_BASE}/simulate_ingest"
    payload = {'dataset_id': dataset_id, 'provider': provider}
    # For demo we simulate the response rather than actually calling an endpoint
    return {'status':'simulated','details':payload}

def execute_ingest(dataset_id, provider):
    # In production this should call an authenticated orchestrator execute endpoint
    url = f"{ORCH_BASE}/ingest"
    payload = {'dataset_id': dataset_id, 'provider': provider}
    try:
        resp = requests.post(url, json=payload, timeout=10)
        return resp.json()
    except Exception as e:
        return {'error':'failed to call orchestrator','detail': str(e)}
