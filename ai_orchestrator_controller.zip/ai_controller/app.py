# ai_controller/app.py - Chat-like AI Orchestrator Controller (safe scaffold)
from flask import Flask, request, jsonify
import os, json, time, uuid
from ai_controller.policy import PolicyEngine
from ai_controller.audit_log import AuditLog
from ai_controller.actions import ActionRouter

app = Flask(__name__)
API_KEYS = {os.getenv('ADMIN_API_KEY','admin-key'): 'admin'}

policy = PolicyEngine()
audit = AuditLog('ai_controller_audit.jsonl')
router = ActionRouter()

def require_api_key(fn):
    def wrapper(*args, **kwargs):
        key = request.headers.get('X-Api-Key') or request.args.get('api_key')
        if not key or key not in API_KEYS:
            return jsonify({'error':'unauthorized'}), 401
        return fn(*args, **kwargs)
    wrapper.__name__ = fn.__name__
    return wrapper

@app.route('/health', methods=['GET'])
def health():
    return jsonify({'status':'ok','ts': int(time.time())})

@app.route('/chat', methods=['POST'])
@require_api_key
def chat():
    body = request.get_json() or {}
    user = body.get('user','unknown')
    prompt = body.get('prompt','').strip()
    context = body.get('context', {})

    # Basic input check
    if not prompt:
        return jsonify({'error':'prompt required'}), 400

    # Log the prompt
    entry_id = audit.log_prompt(user, prompt, context)

    # Simple intent extraction heuristic (replace with LLM integration in prod)
    plan = router.plan_from_prompt(prompt, context)

    # Policy check
    blocked, reasons = policy.check_plan(plan)
    if blocked:
        audit.log_blocked(entry_id, plan, reasons)
        return jsonify({'status':'blocked','reasons': reasons}), 403

    # Dry-run simulation (do not execute dangerous actions automatically)
    simulation = router.simulate_plan(plan)

    # Record simulation in audit log
    audit.log_simulation(entry_id, plan, simulation)

    response = {
        'status':'simulated',
        'entry_id': entry_id,
        'plan': plan,
        'simulation': simulation,
        'note': 'To execute, call /approve with the entry_id and an approval token. Execution requires explicit approval.'
    }
    return jsonify(response), 200

@app.route('/approve', methods=['POST'])
@require_api_key
def approve():
    body = request.get_json() or {}
    entry_id = body.get('entry_id')
    approver = body.get('approver','unknown')
    token = body.get('approval_token')  # placeholder token check
    if not entry_id:
        return jsonify({'error':'entry_id required'}), 400

    # Simple approval gating - in prod implement MFA, role checks, and signed approvals
    # Retrieve plan from audit log
    plan = audit.get_plan_for_entry(entry_id)
    if not plan:
        return jsonify({'error':'entry not found'}), 404

    # Policy re-check before execution
    blocked, reasons = policy.check_plan(plan)
    if blocked:
        audit.log_blocked(entry_id, plan, reasons)
        return jsonify({'status':'blocked','reasons': reasons}), 403

    # Execute plan (router will enforce safe execution rules)
    exec_result = router.execute_plan(plan, approver=approver)

    audit.log_execution(entry_id, approver, exec_result)
    return jsonify({'status':'executed','result': exec_result}), 200

if __name__ == '__main__':
    port = int(os.getenv('PORT', '8088'))
    app.run(host='0.0.0.0', port=port, debug=False)
