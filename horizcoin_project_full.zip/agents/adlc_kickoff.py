# ADLC kickoff scaffold
print('ADLC scaffold')
