# PyFlink scaffold
print('flink job')
