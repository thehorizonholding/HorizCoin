# HorizCoin Blueprint

Consolidated blueprint and next steps.
