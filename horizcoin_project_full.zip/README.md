# HorizCoin Project — Full Package

This package contains a completed snapshot of the HorizCoin project (blueprint, contracts, backend stubs, agents, flink job, k8s manifests, CI templates).
