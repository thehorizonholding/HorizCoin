"""AI Agent adapter for the orchestrator.
- Supports 'mock' (deterministic planning), 'openai' (if OPENAI_API_KEY set), and 'ollama' (simple HTTP endpoint).
- This adapter *only* suggests plans and explanations. The orchestrator still asks for confirmations.
"""
import os, json, time
import requests

LLM_PROVIDER = os.getenv('LLM_PROVIDER','mock')

class AIAgent:
    def __init__(self):
        self.provider = LLM_PROVIDER

    def plan_pipeline(self, repo_path, stage):
        """Return a JSON object with planned steps. In mock mode this is deterministic.
        In real mode it will call the LLM endpoint and parse a JSON response.
        """
        if self.provider == 'mock':
            return self._mock_plan(repo_path, stage)
        if self.provider == 'openai':
            return self._openai_plan(repo_path, stage)
        if self.provider == 'ollama':
            return self._ollama_plan(repo_path, stage)
        raise RuntimeError('Unknown LLM provider: ' + self.provider)

    def _mock_plan(self, repo_path, stage):
        # deterministic plan useful for testing
        plan = {
            'stage': stage,
            'steps': [
                {'id': 'install_deps', 'cmd': 'pip install -r requirements.txt', 'desc': 'Install Python deps', 'sensitive': False},
                {'id': 'compile', 'cmd': 'npx hardhat compile', 'desc': 'Compile Solidity (if present)', 'sensitive': False},
                {'id': 'run_tests', 'cmd': 'npx hardhat test', 'desc': 'Run unit tests', 'sensitive': False},
                {'id': 'build_images', 'cmd': 'docker compose build', 'desc': 'Build docker images', 'sensitive': False},
                {'id': 'deploy_testnet', 'cmd': 'python scripts/deploy_and_interact.py', 'desc': 'Deploy to testnet', 'sensitive': True}
            ]
        }
        return plan

    def _openai_plan(self, repo_path, stage):
        from openai import OpenAI
        key = os.getenv('OPENAI_API_KEY')
        if not key:
            raise RuntimeError('OPENAI_API_KEY not set')
        client = OpenAI(api_key=key)
        prompt = f"Create a JSON plan for implementing the repo at {repo_path} for stage {stage}.\nReturn only JSON with 'steps' array (id, cmd, desc, sensitive boolean)."
        resp = client.chat.completions.create(model='gpt-4o-mini', messages=[{'role':'user','content':prompt}], max_tokens=400)
        text = resp.choices[0].message.content
        return json.loads(text)

    def _ollama_plan(self, repo_path, stage):
        url = os.getenv('OLLAMA_URL')
        if not url:
            raise RuntimeError('OLLAMA_URL not set')
        payload = {'prompt': f'Plan pipeline for {repo_path} stage {stage} and return JSON steps array.'}
        r = requests.post(url + '/v1/generate', json=payload, timeout=30)
        r.raise_for_status()
        text = r.json().get('output', '')
        return json.loads(text)
