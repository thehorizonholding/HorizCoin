Autonomy AI Orchestrator - Runbook & Safety Notes
================================================

1. Review all code before running. This tool executes shell commands.
2. Set up .env from .env.example and ensure you use TESTNET keys only for first runs.
3. Start in dry-run: `python autonomy_ai/orchestrator_ai.py --stage testnet --dry-run`
4. Review `autonomy_ai/proposed_actions.json` created by the AI agent and inspect each command.
5. To execute, run: `python autonomy_ai/orchestrator_ai.py --stage testnet` and confirm sensitive steps interactively.
6. To enable unattended runs (NOT recommended for mainnet), set AUTONOMY_ALLOW_UNATTENDED=yes in .env.
7. For production use, integrate multisig / HSM / Gnosis Safe for any transaction signing. The orchestrator should only call signed scripts that interact with multisig.

Legal & Ethical: Do not use this orchestrator to perform actions on devices or infrastructure without explicit consent from owners. Keep logs and runbooks for audits.
