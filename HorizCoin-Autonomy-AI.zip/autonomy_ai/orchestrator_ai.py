#!/usr/bin/env python3
"""Autonomy AI Orchestrator
- Uses ai_agent to propose a pipeline plan
- Writes proposed_actions.json
- Executes steps one by one, asking for confirmation on sensitive steps
- Logs actions to autonomy_ai/logs/

USAGE:
  python autonomy_ai/orchestrator_ai.py --stage testnet [--dry-run] [--yes]

WARNING: inspect the plan before running with --yes
"""
import argparse, os, json, subprocess, time, sys
from pathlib import Path
from dotenv import load_dotenv
from autonomy_ai.ai_agent import AIAgent

load_dotenv()
ROOT = Path(__file__).resolve().parents[1]
LOG_DIR = ROOT / 'autonomy_ai' / 'logs'
LOG_DIR.mkdir(parents=True, exist_ok=True)
PROPOSED = ROOT / 'autonomy_ai' / 'proposed_actions.json'

AGENT = AIAgent()

def run_cmd(cmd, cwd=None):
    print(f"[RUN] {cmd}")
    rc = subprocess.call(cmd, shell=True, cwd=cwd)
    return rc

def confirm(prompt):
    ans = input(prompt + ' (type YES to proceed): ')
    return ans.strip() == 'YES'

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--stage', choices=['local','testnet','mainnet'], default='local')
    parser.add_argument('--dry-run', action='store_true')
    parser.add_argument('--yes', action='store_true')
    args = parser.parse_args()

    print('Autonomy AI Orchestrator starting. Loading AI agent...')
    plan = AGENT.plan_pipeline(str(ROOT), args.stage)
    print('Plan received from AI agent:')
    print(json.dumps(plan, indent=2))
    with open(PROPOSED, 'w') as f:
        json.dump(plan, f, indent=2)

    if args.dry_run:
        print('Dry-run mode: no commands will be executed. Exiting.')
        return

    unattended = os.getenv('AUTONOMY_ALLOW_UNATTENDED','no').lower() == 'yes'

    for step in plan.get('steps', []):
        print('\n---')
        print(f"Step: {step.get('id')} - {step.get('desc')}")
        print(f"Cmd: {step.get('cmd')}")
        if step.get('sensitive'):
            if not unattended and not args.yes:
                ok = confirm('This step is marked SENSITIVE. Confirm to run')
                if not ok:
                    print('Skipping sensitive step')
                    continue
        # run command
        rc = run_cmd(step.get('cmd'))
        if rc != 0:
            print(f"Command failed with rc={rc}. Stopping.")
            break
        time.sleep(1)

    print('\nOrchestration complete. Review logs in autonomy_ai/logs/')

if __name__ == '__main__':
    main()
