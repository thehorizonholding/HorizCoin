HorizCoin Autonomy AI Orchestrator (Full AI decision layer) - ZIP Package
=======================================================================

This package contains a runnable, **consent-first** autonomous orchestrator that includes an AI decision layer.
It is intended for **local/private execution only**. **Do NOT** run this on a public CI without strict human approval gates.

What this package contains
- autonomy_ai/orchestrator_ai.py  - main orchestrator that executes pipeline steps under AI guidance
- autonomy_ai/ai_agent.py        - small adapter to call a language model (pluggable: OpenAI, local Ollama, etc.)
- autonomy_ai/runbook.md         - operator checklist and safety controls
- .env.example                   - environment variables to set before running
- .gitignore                     - safe ignores for secrets and logs
- .github/workflows/ci-autonomy.yml (example) - CI workflow (does NOT run autonomous mainnet actions)
- LICENSE (MIT)

Security & consent (READ THIS FIRST)
- This orchestrator **requires** the operator to set environment variables (RPC keys, GH token, cloud creds).
- The AI decision layer will **propose** actions; the orchestrator defaults to **interactive confirmation** for any destructive operation (mainnet deploy, key usage).
- For unattended runs, you must explicitly set `AUTONOMY_ALLOW_UNATTENDED=yes` and accept full responsibility.
- Never put mainnet private keys in the repo. Use hardware wallets or multisig for critical operations.

How to run (local):
1. Unzip the package.
2. Copy `.env.example` -> `.env` and fill with testnet keys and tokens.
3. (Optional) Install Python dependencies: `pip install -r requirements.txt` (this package keeps dependencies minimal).
4. Run the orchestrator in dry-run mode first:
   `python autonomy_ai/orchestrator_ai.py --stage testnet --dry-run`
5. Review the proposed actions in `autonomy_ai/proposed_actions.json` then run with confirmation:
   `python autonomy_ai/orchestrator_ai.py --stage testnet`

Notes about the AI decision layer
- `ai_agent.py` contains a simple interface. By default it uses a **local simulation mode** that returns deterministic plans.
- To enable real LLM usage, set `LLM_PROVIDER` in `.env` to `openai` or `ollama`, and provide the corresponding API endpoint and key. The orchestrator will still require explicit confirmation for sensitive steps.
