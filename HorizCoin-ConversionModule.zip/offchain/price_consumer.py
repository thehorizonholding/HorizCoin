"""Price consumer reads the price_store.json and provides helper functions to compute fiat value
for registered on-chain records. Integrate with your indexer to enrich records with fiat valuations.
"""
import json, os

PRICE_FILE = os.getenv('PRICE_OUT_FILE', 'price_store.json')

def get_latest_prices():
    if not os.path.exists(PRICE_FILE):
        return None
    with open(PRICE_FILE, 'r') as f:
        return json.load(f)

def hzc_to_usd(hzc_amount, latest_prices=None):
    latest = latest_prices or get_latest_prices()
    if not latest or 'data' not in latest:
        raise RuntimeError('Price data unavailable')
    # placeholder: use 'horizcoin' key; in a real deployment use accurate mapping
    usd_price = latest['data'].get('horizcoin', {}).get('usd')
    if usd_price is None:
        raise RuntimeError('HZC price missing')
    return float(hzc_amount) * float(usd_price)

if __name__ == '__main__':
    print('Price consumer ready. Load price_store.json via PRICE_OUT_FILE env variable.')
