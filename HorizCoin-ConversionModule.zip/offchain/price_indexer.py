"""Price indexer for HorizCoin project.
Periodically fetches price data (CoinGecko) and writes to a local store for the indexer to consume.
This is intended for test/dev and demonstration only.
"""
import os, time, json, requests

COINGECKO_API = 'https://api.coingecko.com/api/v3/simple/price'
PAIRS = {
    'hzc': 'horizcoin',   # placeholder token id (replace with actual id when available)
    'bitcoin': 'bitcoin',
    'ethereum': 'ethereum'
}
OUT_FILE = os.getenv('PRICE_OUT_FILE', 'price_store.json')
INTERVAL = int(os.getenv('PRICE_INDEX_INTERVAL', '30'))

def fetch_prices():
    ids = ','.join([PAIRS['hzc'], PAIRS['bitcoin'], PAIRS['ethereum']])
    params = {'ids': ids, 'vs_currencies': 'usd'}
    r = requests.get(COINGECKO_API, params=params, timeout=10)
    r.raise_for_status()
    return r.json()

def run():
    while True:
        try:
            data = fetch_prices()
            timestamp = int(time.time())
            out = {'timestamp': timestamp, 'data': data}
            with open(OUT_FILE, 'w') as f:
                json.dump(out, f, indent=2)
            print('Prices written to', OUT_FILE)
        except Exception as e:
            print('Price fetch error:', e)
        time.sleep(INTERVAL)

if __name__ == '__main__':
    run()
