"""Swap helper (off-chain). This script demonstrates preparing swap parameters using a DEX aggregator API.
It is a safe, non-custodial helper and does NOT perform swaps itself. Integrate with a frontend wallet or server-side
execution that uses user's signed transactions.
"""
import os, requests, json
from web3 import Web3

# Example: 1inch API base (for Ethereum mainnet / testnets)
ONEINCH_API = os.getenv('ONEINCH_API', 'https://api.1inch.io/v5.0/1')

def quote_swap(from_token, to_token, amount_wei):
    """Get a quote from 1inch (or other DEX aggregator)."""
    url = f"{ONEINCH_API}/quote?fromTokenAddress={from_token}&toTokenAddress={to_token}&amount={amount_wei}"
    r = requests.get(url, timeout=10)
    r.raise_for_status()
    return r.json()

def build_swap_transaction(from_token, to_token, amount_wei, from_address, slippage=1):
    """Request transaction data to execute a swap via aggregator (returned txn must be signed by user)."""
    url = f"{ONEINCH_API}/swap?fromTokenAddress={from_token}&toTokenAddress={to_token}&amount={amount_wei}&fromAddress={from_address}&slippage={slippage}"
    r = requests.get(url, timeout=10)
    r.raise_for_status()
    return r.json()

if __name__ == '__main__':
    print('Swap helper ready. Use in integration with wallet signing.')
