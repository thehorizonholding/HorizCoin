from flask import Flask, request, jsonify
import uuid, os, time

app = Flask(__name__)

# Simple in-memory store for demo purposes
ORDERS = {}

@app.route('/create_order', methods=['POST'])
def create_order():
    data = request.get_json() or {}
    amount = data.get('amount')  # amount in HZC or USD depending on mode
    currency = data.get('currency', 'USD')
    order_id = str(uuid.uuid4())
    ORDERS[order_id] = {'id': order_id, 'amount': amount, 'currency': currency, 'status': 'created', 'ts': int(time.time())}
    return jsonify({'ok': True, 'order_id': order_id, 'status': 'created'})

@app.route('/simulate_settle/<order_id>', methods=['POST'])
def settle(order_id):
    if order_id not in ORDERS:
        return jsonify({'ok': False, 'error': 'not found'}), 404
    ORDERS[order_id]['status'] = 'settled'
    return jsonify({'ok': True, 'order': ORDERS[order_id]})

@app.route('/order/<order_id>', methods=['GET'])
def get_order(order_id):
    return jsonify(ORDERS.get(order_id, {}))

if __name__ == '__main__':
    port = int(os.getenv('PORT', '5005'))
    app.run(host='0.0.0.0', port=port)
