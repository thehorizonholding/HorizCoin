# HorizCoin Conversion Module (Addition)

This module adds currency conversion capabilities to the HorizCoin project, including:
- `ConversionOracle.sol`: on-chain price-feed registry (owner-managed, Chainlink feed addresses)
- Off-chain helpers:
  - `offchain/price_indexer.py`: fetches market prices (CoinGecko) and writes `price_store.json`
  - `offchain/price_consumer.py`: consumes `price_store.json` to enrich records with fiat values
  - `offchain/swap_helper.py`: DEX aggregator helper (1inch) for building swap transactions (non-custodial)
  - `offchain/mock_fiat_gateway.py`: demo fiat on/off-ramp simulator (Flask)

## Usage (demo)
1. Deploy `ConversionOracle.sol` and set feeds (owner only). For local tests, you can deploy mock Aggregator contracts.
2. Run `offchain/price_indexer.py` to populate `price_store.json`.
3. Integrate `price_consumer.py` into your indexer to compute fiat-equivalent values.
4. Use `swap_helper.py` in a frontend to obtain swap transactions from a DEX aggregator; transactions must be signed by users' wallets.
5. For on/off-ramps, test flows with `mock_fiat_gateway.py` and replace with real providers (Transak, MoonPay, Circle) in production.

**Security**: This module is a demonstration. Do not use mock gateways in production. Always use regulated fiat on/off ramps and KYC-compliant providers.

