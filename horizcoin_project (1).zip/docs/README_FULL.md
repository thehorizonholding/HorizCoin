HorizCoin — Full Project Documentation
(See the README in the root for an executive summary.)
Full architecture and operational guidance included in this file would be used for engineering and audit.
