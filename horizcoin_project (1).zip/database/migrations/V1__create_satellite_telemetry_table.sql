CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS satellite_telemetry (
 event_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 satellite_id VARCHAR(100) NOT NULL,
 timestamp TIMESTAMPTZ NOT NULL,
 latitude DOUBLE PRECISION,
 longitude DOUBLE PRECISION,
 raw_data JSONB,
 ingested_at TIMESTAMPTZ DEFAULT (NOW() AT TIME ZONE 'utc'),
 UNIQUE (satellite_id, timestamp)
);
CREATE INDEX IF NOT EXISTS idx_telemetry_timestamp ON satellite_telemetry (timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_telemetry_satellite_id ON satellite_telemetry (satellite_id);
