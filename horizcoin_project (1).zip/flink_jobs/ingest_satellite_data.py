from pyflink.table import EnvironmentSettings, TableEnvironment
def run_ingestion_job():
    settings = EnvironmentSettings.in_streaming_mode()
    t_env = TableEnvironment.create(settings)
    t_env.execute_sql("""
    CREATE TABLE kafka_raw_telemetry (
        satellite_id STRING,
        timestamp TIMESTAMP_LTZ(3),
        latitude DOUBLE,
        longitude DOUBLE,
        raw_data STRING
    ) WITH (
        'connector' = 'kafka',
        'topic' = 'satellite_raw_data',
        'properties.bootstrap.servers' = 'kafka:9092',
        'format' = 'json',
        'scan.startup.mode' = 'latest-offset'
    )
    """)
    # Sink definition to Postgres should be added in production.
if __name__=='__main__': run_ingestion_job()
