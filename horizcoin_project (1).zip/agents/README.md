Agents folder contains scaffolding for the multi-agent system (Project Chimera).
Use CrewAI/crewai or similar to adapt these agent definitions to your infra and LLM provider.
