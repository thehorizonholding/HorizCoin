# HorizCoin — Data-as-a-Token Ecosystem (Project Chimera)

This repository is a full scaffold for the HorizCoin project (contracts, backend, agents, ingestion, infra manifests, and docs).
It is a starting point — **do not deploy to production without proper security reviews and audits**.

See `docs/README_FULL.md` for the comprehensive project description.
