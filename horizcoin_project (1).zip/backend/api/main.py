from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List
app = FastAPI(title='HorizCoin Marketplace API')
class Dataset(BaseModel):
    id: str; name: str; description: str; price_hzc: float; source: str; ddvo_score: int
mock_db_datasets = [
    Dataset(id='ds_001', name='Global Ocean Temp (Real-time)', description='Live feed from satellite cluster.', price_hzc=1500.0, source='Satellite-XYZ', ddvo_score=87),
    Dataset(id='ds_002', name='NA Urban IoT Traffic', description='Aggregated traffic data from major city sensors.', price_hzc=800.0, source='IoT-Sensor-Grid', ddvo_score=82)
]
@app.get('/')
def read_root(): return {'status':'HorizCoin Marketplace API is online'}
@app.get('/datasets', response_model=List[Dataset])
async def get_available_datasets(): return mock_db_datasets
@app.get('/datasets/{dataset_id}', response_model=Dataset)
async def get_dataset_details(dataset_id: str):
    for ds in mock_db_datasets:
        if ds.id==dataset_id: return ds
    raise HTTPException(status_code=404, detail='Dataset not found')
class PurchaseRequest(BaseModel):
    buyer_wallet: str; amount: int
@app.post('/purchase/{dataset_id}')
async def purchase_dataset(dataset_id: str, request: PurchaseRequest):
    dataset = None
    for ds in mock_db_datasets:
        if ds.id==dataset_id:
            dataset = ds; break
    if not dataset:
        raise HTTPException(status_code=404, detail='Dataset not found')
    print(f'Transaction initiated: {request.buyer_wallet} purchasing {request.amount} tokens for {dataset.name}')
    return {'status':'purchase_initiated','dataset_id':dataset.id,'buyer':request.buyer_wallet,'tx_hash_placeholder':'0xdeadbeef'}
