const hre = require('hardhat');
async function main(){
  const [deployer] = await hre.ethers.getSigners();
  console.log('Deploying with', deployer.address);
  const Horiz = await hre.ethers.getContractFactory('HorizCoin');
  const horiz = await Horiz.deploy(deployer.address);
  await horiz.deployed();
  console.log('HorizCoin deployed to', horiz.address);
  const NodeRegistry = await hre.ethers.getContractFactory('NodeRegistry');
  const nodeRegistry = await NodeRegistry.deploy();
  await nodeRegistry.deployed();
  console.log('NodeRegistry deployed to', nodeRegistry.address);
}
main().catch(e=>{console.error(e); process.exit(1);});
