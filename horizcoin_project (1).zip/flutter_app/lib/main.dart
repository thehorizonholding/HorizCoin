import 'package:flutter/material.dart';
import 'screens/marketplace_screen.dart';
void main(){ runApp(const HorizCoinApp()); }
class HorizCoinApp extends StatelessWidget {
  const HorizCoinApp({super.key});
  @override Widget build(BuildContext context) {
    return MaterialApp(title:'HorizCoin', theme: ThemeData.dark(), home: const MarketplaceScreen());
  }
}
