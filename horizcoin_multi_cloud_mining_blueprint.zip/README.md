# Multi-Cloud Mining Blueprint (HorizCoin)

This archive contains a **blueprint** and starter templates to deploy mining/validator nodes across multiple cloud providers (AWS, GCP, Oracle Cloud).
It is **inventoried** and **template-only**: you must supply credentials, customize settings, and perform security reviews before deploying.

Folders:
- terraform/       : provider-specific Terraform skeletons
- docker/          : Dockerfiles for miner/validator images
- helm/            : Helm chart skeleton for Kubernetes deployment
- scripts/         : helper deploy & monitoring scripts
- docs/            : architecture notes & cost considerations

**Important safety & legal notes**
- This blueprint is a technical template. Ensure your mining activity complies with all cloud provider Terms of Service and applicable laws and regulations in your jurisdiction.
- Do NOT commit secrets (API keys, private keys) to source control. Use cloud-native secret managers.

