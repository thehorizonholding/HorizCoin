#!/bin/bash
# Example orchestrator script to apply Terraform for each provider.
set -e
# This script assumes you have initialized Terraform in each provider folder and set credentials.
ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
for provider in aws gcp oracle; do
  echo "Applying Terraform for ${provider}..."
  pushd "${ROOT_DIR}/terraform" > /dev/null
  terraform init -input=false
  terraform apply -auto-approve -var='miner_image=your_dockerhub/hzc-miner:latest'
  popd > /dev/null
done
echo "Done. Note: this is a skeleton. Customize variables and secure secrets before running."
