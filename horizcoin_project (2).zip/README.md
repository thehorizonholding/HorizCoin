# HorizCoin - DePIN & AI Platform (Project Package)

This archive bundles a production-oriented implementation scaffold for the HorizCoin project described in the conversation.
It includes:

- Edge telemetry simulation and MQTT -> Kafka bridge
- WebSocket producer to feed Kafka
- Multi-cloud provider abstraction (AWS/GCP/OCI)
- AI Crew backend skeleton (FastAPI + CrewAI integration)
- Solidity contracts for DePIN NTFs and a data marketplace
- IPFS uploader script
- Requirements file and example env

IMPORTANT:
- Secrets/API keys are not included. Use the provided `.env.example` files and follow secure credential practices.
- This package is a large-scoped scaffold. Each component must be configured, secured, and tested before production use.

Quick start (development):
1. Fill in `app/.env.example` and move to `app/.env`.
2. Install Python deps: `pip install -r requirements.txt`
3. Start Kafka via Docker Compose: `docker-compose up -d`
4. Run the MQTT->Kafka bridge: `python mqtt_to_kafka_bridge.py`
5. Run the device simulator: `python depin_node_simulator.py`
6. Deploy and test smart contracts with Hardhat / Foundry (not included in this zip).

For full production deployment details refer to the architectural guide in the conversation.
