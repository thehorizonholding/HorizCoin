from crewai import Agent, Task, Crew, Process
from crewai_tools import SerperDevTool
from langchain_groq import ChatGroq
from app.config import GROQ_API_KEY, SERPER_API_KEY

def create_research_crew(topic: str):
    llm = ChatGroq(temperature=0, model_name="llama3-70b-8192", api_key=GROQ_API_KEY)
    search_tool = SerperDevTool()

    researcher = Agent(
        role='Senior Research Analyst',
        goal=f'Uncover cutting-edge developments in {topic}',
        backstory="You are a world-class research analyst...",
        verbose=True,
        allow_delegation=False,
        tools=[search_tool],
        llm=llm
    )

    writer = Agent(
        role='Tech Content Strategist',
        goal=f'Craft a compelling narrative about {topic}',
        backstory="You are a renowned content strategist...",
        verbose=True,
        allow_delegation=True,
        llm=llm
    )

    research_task = Task(
        description=f'Conduct a comprehensive analysis of the latest trends in {topic}.',
        expected_output='A full analysis report with key findings.',
        agent=researcher
    )

    write_task = Task(
        description=f'Using the research report, write a blog post about {topic}.',
        expected_output='A 5-paragraph blog post.',
        agent=writer
    )

    crew = Crew(
        agents=[researcher, writer],
        tasks=[research_task, write_task],
        process=Process.sequential,
        verbose=2
    )

    return crew
