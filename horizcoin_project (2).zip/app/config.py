import os
from dotenv import load_dotenv

load_dotenv()

GROQ_API_KEY = os.getenv("GROQ_API_KEY")
SERPER_API_KEY = os.getenv("SERPER_API_KEY")

DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://user:password@postgres/crewdb")
REDIS_URL = os.getenv("REDIS_URL", "redis://redis:6379")
