from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session
import json
from app import models, schemas, crew
from app.database import engine, get_db, redis_pool

models.Base.metadata.create_all(bind=engine)

app = FastAPI(title="AI Crew Backend")

@app.post("/crew/run", response_model=schemas.CrewRunResponse)
async def run_crew(request: schemas.CrewRunRequest, db: Session = Depends(get_db)):
    cache_key = f"crew_run:{request.topic}"
    cached_result = await redis_pool.get(cache_key)
    if cached_result:
        return json.loads(cached_result)

    try:
        research_crew = crew.create_research_crew(request.topic)
        inputs = {"topic": request.topic}
        result_text = research_crew.kickoff(inputs=inputs)

        db_run = models.CrewRun(inputs=json.dumps(inputs), result=result_text)
        db.add(db_run)
        db.commit()
        db.refresh(db_run)

        response_data = {"run_id": db_run.id, "result": result_text}
        await redis_pool.set(cache_key, json.dumps(response_data), ex=3600)
        return response_data
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
