from pydantic import BaseModel

class CrewRunRequest(BaseModel):
    topic: str

class CrewRunResponse(BaseModel):
    run_id: int
    result: str
