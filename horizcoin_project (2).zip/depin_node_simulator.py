import paho.mqtt.client as mqtt
import time
import json
import random
import uuid

BROKER_ADDRESS = "broker.emqx.io"
BROKER_PORT = 1883
MQTT_TOPIC = "depin/telemetry"

NODE_ID = str(uuid.uuid4())

def on_connect(client, userdata, flags, rc, properties=None):
    if rc == 0:
        print(f"Node {NODE_ID} connected to MQTT Broker successfully.")
    else:
        print(f"Failed to connect, return code {rc}\n")

def create_mqtt_client():
    client_id = f'depin-node-{NODE_ID}'
    client = mqtt.Client(client_id=client_id)
    client.on_connect = on_connect
    client.connect(BROKER_ADDRESS, BROKER_PORT)
    return client

def publish_telemetry(client):
    client.loop_start()
    try:
        while True:
            latency = round(random.uniform(50, 500), 2)
            success_rate = round(random.uniform(0.85, 1.0), 2)

            telemetry_data = {
                "node_id": NODE_ID,
                "timestamp": time.time(),
                "latency_ms": latency,
                "success_rate": success_rate,
                "region": "us-east-1"
            }

            payload = json.dumps(telemetry_data)
            result = client.publish(MQTT_TOPIC, payload)

            # paho mqtt publish returns a MQTTMessageInfo; check rc
            if getattr(result, 'rc', 0) == 0:
                print(f"Sent `{payload}` to topic `{MQTT_TOPIC}`")
            else:
                print(f"Failed to send message to topic {MQTT_TOPIC}")

            time.sleep(10)
    except KeyboardInterrupt:
        print("Telemetry publishing stopped.")
    finally:
        client.loop_stop()
        client.disconnect()

if __name__ == "__main__":
    mqtt_client = create_mqtt_client()
    publish_telemetry(mqtt_client)
