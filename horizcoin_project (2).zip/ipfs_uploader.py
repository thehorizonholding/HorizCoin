import requests
import json
import os
from dotenv import load_dotenv

load_dotenv()

PINATA_BASE_URL = "https://api.pinata.cloud"
PINATA_API_KEY = os.getenv("PINATA_API_KEY")
PINATA_API_SECRET = os.getenv("PINATA_API_SECRET")

HEADERS = {
    "pinata_api_key": PINATA_API_KEY,
    "pinata_secret_api_key": PINATA_API_SECRET
}

def upload_to_ipfs(filepath: str):
    try:
        with open(filepath, "rb") as fp:
            image_binary = fp.read()
            response = requests.post(
                f"{PINATA_BASE_URL}/pinning/pinFileToIPFS",
                files={"file": (os.path.basename(filepath), image_binary)},
                headers=HEADERS
            )
            response.raise_for_status()
            ipfs_hash = response.json()["IpfsHash"]
            print(f"File {os.path.basename(filepath)} uploaded successfully. CID: {ipfs_hash}")
            return ipfs_hash
    except Exception as e:
        print(f"Error uploading file to IPFS: {e}")
        return None

if __name__ == '__main__':
    main()
