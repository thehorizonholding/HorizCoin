from google.cloud import compute_v1
import time

class GCPProvider:
    def __init__(self, project_id: str, zone: str):
        self.project_id = project_id
        self.zone = zone
        self.instances_client = compute_v1.InstancesClient()
        self.operations_client = compute_v1.ZoneOperationsClient()
        print("Initialized GCP Provider.")

    def _wait_for_operation(self, operation):
        while operation.status != compute_v1.Operation.Status.DONE:
            operation = self.operations_client.wait(project=self.project_id, zone=self.zone, operation=operation.name)
            time.sleep(1)
        if getattr(operation, 'error', None):
            raise Exception(f"GCP operation failed: {operation.error}")
        return operation

    def provision_instance(self, params: dict):
        try:
            print(f"Provisioning GCP VM instance with params: {params}")
            instance_config = {
                "name": params['instance_name'],
                "machine_type": f"zones/{self.zone}/machineTypes/{params['machine_type']}",
                "disks": params.get('disks', []),
                "network_interfaces": [{"name": f"global/networks/{params.get('network_name', 'default')}"}],
            }
            operation = self.instances_client.insert(project=self.project_id, zone=self.zone, instance_resource=instance_config)
            self._wait_for_operation(operation)
            instance = self.instances_client.get(project=self.project_id, zone=self.zone, instance=params['instance_name'])
            print(f"Successfully created GCP VM instance: {instance.name}")
            return instance.name
        except Exception as e:
            print(f"Error provisioning GCP VM instance: {e}")
            return None

    def terminate_instance(self, instance_name: str):
        try:
            operation = self.instances_client.delete(project=self.project_id, zone=self.zone, instance=instance_name)
            self._wait_for_operation(operation)
            return True
        except Exception as e:
            print(f"Error terminating GCP VM instance {instance_name}: {e}")
            return False

    def get_instance_status(self, instance_name: str):
        try:
            instance = self.instances_client.get(project=self.project_id, zone=self.zone, instance=instance_name)
            return instance.status.name
        except Exception as e:
            print(f"Error getting status for GCP VM instance {instance_name}: {e}")
            return "ERROR"
