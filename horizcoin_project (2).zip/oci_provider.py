import oci
import time

class OCIProvider:
    def __init__(self, compartment_id: str):
        self.config = oci.config.from_file()
        self.compute_client = oci.core.ComputeClient(self.config)
        self.compartment_id = compartment_id
        print("Initialized OCI Provider.")

    def provision_instance(self, params: dict):
        try:
            print(f"Provisioning OCI Compute instance with params: {params}")
            launch_details = oci.core.models.LaunchInstanceDetails(
                compartment_id=self.compartment_id,
                availability_domain=params['availability_domain'],
                shape=params['shape'],
                display_name=params['display_name'],
                source_details=oci.core.models.InstanceSourceViaImageDetails(image_id=params['image_id']),
                create_vnic_details=oci.core.models.CreateVnicDetails(subnet_id=params['subnet_id']),
                metadata={"ssh_authorized_keys": params.get('ssh_key', "")}
            )
            launch_response = self.compute_client.launch_instance(launch_details)
            instance_ocid = launch_response.data.id
            # Wait briefly (in production use waiters)
            time.sleep(5)
            print(f"Instance {instance_ocid} launched.")
            return instance_ocid
        except oci.exceptions.ServiceError as e:
            print(f"Error provisioning OCI instance: {e}")
            return None

    def terminate_instance(self, instance_ocid: str):
        try:
            self.compute_client.terminate_instance(instance_ocid)
            return True
        except oci.exceptions.ServiceError as e:
            print(f"Error terminating OCI instance {instance_ocid}: {e}")
            return False

    def get_instance_status(self, instance_ocid: str):
        try:
            response = self.compute_client.get_instance(instance_ocid)
            return response.data.lifecycle_state
        except oci.exceptions.ServiceError as e:
            print(f"Error getting status for OCI instance {instance_ocid}: {e}")
            return "ERROR"
