import asyncio
import json
from datetime import datetime, timezone
import websockets
from kafka import KafkaProducer

KAFKA_BOOTSTRAP_SERVERS = 'localhost:9092'
KAFKA_TOPIC = 'depin-telemetry-raw'

WEBSOCKET_HOST = 'localhost'
WEBSOCKET_PORT = 8765

try:
    producer = KafkaProducer(
        bootstrap_servers=KAFKA_BOOTSTRAP_SERVERS,
        value_serializer=lambda v: json.dumps(v).encode('utf-8')
    )
    print("Successfully connected to Kafka.")
except Exception as e:
    print(f"Could not connect to Kafka: {e}")
    producer = None

async def handler(websocket, path):
    print(f"Client connected from {websocket.remote_address}")
    try:
        async for message in websocket:
            print(f"Received message via WebSocket: {message}")
            if not producer:
                print("Kafka producer not available. Skipping message.")
                continue
            try:
                data = json.loads(message)
                data['ingest_timestamp_utc'] = datetime.now(timezone.utc).isoformat()
                data['source_protocol'] = 'websocket'
                key = (data.get('sessionId') or data.get('userId') or '').encode('utf-8') or None
                producer.send(KAFKA_TOPIC, key=key, value=data)
                print(f"Forwarded message to Kafka topic: {KAFKA_TOPIC}")
            except json.JSONDecodeError:
                print(f"Warning: Received non-JSON message: {message}")
                producer.send(KAFKA_TOPIC, value={'raw_message': message})
            except Exception as e:
                print(f"Error processing WebSocket message: {e}")
    except websockets.exceptions.ConnectionClosed as e:
        print(f"Client disconnected: {e}")
    finally:
        pass

async def main():
    async with websockets.serve(handler, WEBSOCKET_HOST, WEBSOCKET_PORT):
        print(f"WebSocket server running at ws://{WEBSOCKET_HOST}:{WEBSOCKET_PORT}")
        await asyncio.Future()  # run forever

if __name__ == '__main__':
    asyncio.run(main())
