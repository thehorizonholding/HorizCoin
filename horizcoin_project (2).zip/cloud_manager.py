from aws_provider import AWSProvider
from gcp_provider import GCPProvider
from oci_provider import OCIProvider

def get_provider(provider_name: str, config: dict):
    if provider_name.lower() == 'aws':
        return AWSProvider(region=config.get('region', 'us-east-1'))
    elif provider_name.lower() == 'gcp':
        return GCPProvider(project_id=config['project_id'], zone=config['zone'])
    elif provider_name.lower() == 'oci':
        return OCIProvider(compartment_id=config['compartment_id'])
    else:
        raise ValueError(f"Unsupported cloud provider: {provider_name}")
