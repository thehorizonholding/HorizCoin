import boto3
from botocore.exceptions import ClientError

class AWSProvider:
    def __init__(self, region='us-east-1'):
        self.ec2_client = boto3.client('ec2', region_name=region)
        self.ec2_resource = boto3.resource('ec2', region_name=region)
        print("Initialized AWS Provider.")

    def provision_instance(self, params: dict):
        try:
            print(f"Provisioning AWS EC2 instance with params: {params}")
            instances = self.ec2_resource.create_instances(
                ImageId=params['image_id'],
                InstanceType=params['instance_type'],
                KeyName=params.get('key_name'),
                SecurityGroupIds=params.get('security_group_ids', []),
                MinCount=1,
                MaxCount=1
            )
            instance = instances[0]
            instance.wait_until_running()
            instance.reload()
            instance_id = instance.id
            print(f"Instance {instance_id} is now running.")
            return instance_id
        except ClientError as e:
            print(f"Error provisioning EC2 instance: {e}")
            return None

    def terminate_instance(self, instance_id: str):
        try:
            print(f"Terminating AWS EC2 instance: {instance_id}")
            response = self.ec2_client.terminate_instances(InstanceIds=[instance_id])
            return True
        except ClientError as e:
            print(f"Error terminating EC2 instance {instance_id}: {e}")
            return False

    def get_instance_status(self, instance_id: str):
        try:
            response = self.ec2_client.describe_instances(InstanceIds=[instance_id])
            return response['Reservations'][0]['Instances'][0]['State']['Name']
        except ClientError as e:
            print(f"Error getting status for EC2 instance {instance_id}: {e}")
            return "error"
