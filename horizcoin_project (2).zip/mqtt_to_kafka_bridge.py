import paho.mqtt.client as mqtt
from confluent_kafka import Producer
import json
import socket

MQTT_BROKER_ADDRESS = "broker.emqx.io"
MQTT_BROKER_PORT = 1883
MQTT_TOPIC = "depin/telemetry"

KAFKA_BROKER_ADDRESS = "localhost:9092"
KAFKA_TOPIC = "depin-telemetry-raw"

def create_kafka_producer():
    conf = {
        'bootstrap.servers': KAFKA_BROKER_ADDRESS,
        'client.id': socket.gethostname()
    }
    return Producer(conf)

def delivery_report(err, msg):
    if err is not None:
        print(f"Message delivery failed: {err}")
    else:
        print(f"Message delivered to {msg.topic()} [{msg.partition()}]")

def on_message(client, userdata, msg):
    producer = userdata['kafka_producer']
    payload = msg.payload.decode('utf-8')
    print(f"Received message from MQTT: {payload}")

    try:
        data = json.loads(payload)
        node_id = data.get("node_id", "unknown")

        producer.produce(
            KAFKA_TOPIC,
            key=node_id.encode('utf-8'),
            value=payload.encode('utf-8'),
            callback=delivery_report
        )
    except Exception as e:
        print(f"Error forwarding message to Kafka: {e}")

def on_connect(client, userdata, flags, rc, properties=None):
    if rc == 0:
        print("Bridge connected to MQTT Broker.")
        client.subscribe(MQTT_TOPIC)
        print(f"Subscribed to topic: {MQTT_TOPIC}")
    else:
        print(f"Failed to connect to MQTT, return code {rc}\n")

def main():
    kafka_producer = create_kafka_producer()

    client = mqtt.Client(client_id="mqtt-kafka-bridge")
    client.user_data_set({'kafka_producer': kafka_producer})
    client.on_connect = on_connect
    client.on_message = on_message

    client.connect(MQTT_BROKER_ADDRESS, MQTT_BROKER_PORT)

    try:
        client.loop_forever()
    except KeyboardInterrupt:
        print("Bridge shutting down.")
    finally:
        client.disconnect()
        kafka_producer.flush()

if __name__ == "__main__":
    main()
