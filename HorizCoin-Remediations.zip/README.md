HorizCoin Remediations Package
==============================

This package contains fixes and hardened stubs addressing the highest-priority issues
required to move from a sandbox/test environment to a secure, testnet-ready deployment.

Included fixes:
- Completed ledger_service.py: Uses Postgres via SQLAlchemy, enforces double-entry and atomicity.
- Updated wallet_service.py: Replaces insecure Fernet usage with a pluggable KMS signer interface. Includes safe fallbacks and warnings.
- Fixed deploy script: uses `token.address` for Hardhat/Ethers compatibility.
- CHANGELOG and integration notes for production steps.

IMPORTANT:
- This package does NOT include any private keys or production secrets.
- You must provision a real KMS (AWS KMS, GCP KMS, or HSM) and set KMS_PROVIDER env vars before enabling signing.
- Review and run unit tests before deploying to any network.

Files in this archive:
- services/wallet_service.py
- services/ledger_service.py
- deploy/deploy_testnet.js (fixed)
- docs/CHANGELOG.md (notes)
- docs/INTEGRATION.md (next steps)
