// Deploy script (fixed for ethers v6 compatibility)
const hre = require('hardhat');
const fs = require('fs');
async function main() {
  const [deployer] = await hre.ethers.getSigners();
  console.log('Deploying from:', deployer.address);
  const initialSupply = hre.ethers.parseUnits('1000000', 18); // 1M HZC
  const Token = await hre.ethers.getContractFactory('HorizCoinToken');
  const token = await Token.deploy(initialSupply);
  await token.deploymentTransaction().wait(1);
  const address = token.address || token.target || token.address; // compatibility
  console.log('HorizCoinToken deployed at:', address);
  fs.writeFileSync('deploy/deployed_address.txt', address, 'utf8');
}
main().catch((err) => {
  console.error(err);
  process.exitCode = 1;
});
