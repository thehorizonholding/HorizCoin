Integration Notes (Remediations)
===============================

1. Wallet Service
   - Configure KMS_PROVIDER to 'aws' or 'gcp' and implement provider-specific signing in KMSSigner.sign_transaction.
   - Ensure the service runs in a private subnet with restricted ingress.
   - Use Vault to store any KMS credentials; do not put keys in env files.

2. Ledger Service
   - Provide LEDGER_DATABASE_URL env var pointing to Postgres (example: postgresql://user:pass@host:5432/horizledger).
   - Ensure Postgres has proper backups and WAL archiving enabled.
   - Run migrations using Alembic when schema evolves.

3. Deploy script
   - Use Node 18+ and the matching ethers/hardhat versions.
   - Populate .env with SEPOLIA_RPC_URL and PRIVATE_KEY (use testnet only).

4. Testing
   - Run unit tests and integration tests for wallet->ledger->sign flow in a ci environment before any live deploy.
