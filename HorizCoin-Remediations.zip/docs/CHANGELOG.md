Changelog - Remediations Package
================================

- 2025-11-05: Complete ledger_service implementation with Postgres and double-entry enforcement.
- 2025-11-05: Replace insecure Fernet placeholder in wallet_service with a KMSSigner interface and clear warnings.
- 2025-11-05: Fix deploy script compatibility for ethers/hardhat versions.
- 2025-11-05: Added integration notes for KMS, HSM, and operational checklist.
