#!/usr/bin/env python3
"""Wallet signing service (remediated)

This service provides secure signing of transactions using a pluggable KMS signer.
It intentionally includes only a KMS stub -- you must configure a real KMS provider
(AWS KMS, Google Cloud KMS, Azure Key Vault, or an HSM) in production.
"""
import os
import json
import logging
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional

# Web3 for transaction signing if needed for local test flow
from web3 import Web3

logging.basicConfig(level=logging.INFO)

# Environment config
KMS_PROVIDER = os.environ.get('KMS_PROVIDER', '')  # 'aws' | 'gcp' | 'local'
ETH_NODE_URL = os.environ.get('ETH_NODE_URL', 'https://rpc.sepolia.org')
web3 = Web3(Web3.HTTPProvider(ETH_NODE_URL))

app = FastAPI(title='HorizCoin Wallet Service (Remediated)')

# Simple in-memory stores for demo. Replace with secure DB in prod.
encrypted_keys_db = {}  # user_id -> encrypted_key_blob (opaque to service)
address_db = {}         # user_id -> address

class CreateWalletRequest(BaseModel):
    user_id: str

class SignRequest(BaseModel):
    user_id: str
    unsigned_tx: dict  # Ethers transaction dict (nonce, to, value, gas, gasPrice, data, chainId)

class SignedTransaction(BaseModel):
    signed_tx_hex: str
    tx_hash: str

# ---- KMS Interface ----
class KMSSigner:
    """Abstract KMS signer. Implement provider-specific integrations."""
    def __init__(self, provider: str):
        self.provider = provider.lower()
        logging.info(f'KMSSigner initialized for provider: {self.provider}')

    def generate_keypair(self):
        # In production, create a key in KMS and return an identifier.
        # Here we generate a local account for test/demo only.
        acct = web3.eth.account.create()
        private_key = acct.key.hex()
        address = acct.address
        # WARNING: This is only for local testing. Do NOT use in production.
        return {'priv_hex': private_key, 'address': address, 'key_id': f'local-{address}'}

    def encrypt_and_store(self, key_id: str, priv_hex: str, user_id: str):
        # Store key material encrypted by KMS in your DB. Here we store plain (demo only).
        # In production, only store encrypted blob and never expose plaintext.
        encrypted_blob = json.dumps({'key_id': key_id, 'priv_hex': priv_hex})
        encrypted_keys_db[user_id] = encrypted_blob
        return True

    def sign_transaction(self, key_id: str, unsigned_tx: dict) -> Optional[dict]:
        # In production, call KMS Sign API which takes a digest and returns signature
        # For demo/testnet-only flows, we decrypt the stored blob and sign locally.
        blob = encrypted_keys_db.get(key_id)
        if not blob:
            # if key_id passed per-user (we map user->blob)
            blob = encrypted_keys_db.get(key_id) or encrypted_keys_db.get(key_id.split(':')[-1])
        if not blob:
            return None
        data = json.loads(blob)
        priv = data.get('priv_hex')
        acct = web3.eth.account.from_key(priv)
        try:
            signed = web3.eth.account.sign_transaction(unsigned_tx, priv)
            return {'raw': signed.rawTransaction.hex(), 'hash': signed.hash.hex()}
        except Exception as e:
            logging.error('Local sign failed: %s', e)
            return None

# Instantiate a KMS signer
kms = KMSSigner(KMS_PROVIDER or 'local')

# ---- API Endpoints ----
@app.post("/wallet/create")
async def create_wallet(req: CreateWalletRequest):
    if req.user_id in address_db:
        raise HTTPException(status_code=400, detail='wallet already exists')

    keys = kms.generate_keypair()
    key_id = keys['key_id']
    # Store encrypted blob via KMS envelope encryption in production
    kms.encrypt_and_store(key_id, keys['priv_hex'], req.user_id)
    address_db[req.user_id] = keys['address']
    return {'user_id': req.user_id, 'address': keys['address'], 'key_id': key_id}

@app.get("/wallet/{user_id}")
async def get_wallet(user_id: str):
    if user_id not in address_db:
        raise HTTPException(status_code=404, detail='wallet not found')
    address = address_db[user_id]
    # In production return limited info only
    return {'user_id': user_id, 'address': address}

@app.post("/wallet/sign", response_model=SignedTransaction)
async def sign_tx(req: SignRequest):
    if req.user_id not in encrypted_keys_db:
        raise HTTPException(status_code=404, detail='wallet key not found')
    # Map user_id -> stored blob; our demo stores user_id keyed encrypted blob
    result = kms.sign_transaction(req.user_id, req.unsigned_tx)
    if not result:
        raise HTTPException(status_code=500, detail='signing failed')
    return SignedTransaction(signed_tx_hex=result['raw'], tx_hash=result['hash'])

if __name__ == '__main__':
    import uvicorn
    uvicorn.run(app, host='0.0.0.0', port=8002)
