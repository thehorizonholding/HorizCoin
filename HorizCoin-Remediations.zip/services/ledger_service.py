#!/usr/bin/env python3
"""Ledger service: enforces double-entry accounting with Postgres backend.

This example uses SQLAlchemy and a minimal schema suitable for extension.
DO NOT use sqlite for production accounting; use Postgres with WAL and backups.
"""
import os
import uuid
from datetime import datetime
from decimal import Decimal
from typing import List
from pydantic import BaseModel, constr
from fastapi import FastAPI, HTTPException
from sqlalchemy import create_engine, Column, Integer, String, Numeric, DateTime, ForeignKey, func
from sqlalchemy.orm import sessionmaker, declarative_base, relationship
from sqlalchemy.exc import SQLAlchemyError

DATABASE_URL = os.environ.get('LEDGER_DATABASE_URL', 'postgresql://postgres:postgres@localhost:5432/horizledger')

Base = declarative_base()

class TransactionRecord(Base):
    __tablename__ = 'transactions'
    id = Column(Integer, primary_key=True)
    transaction_id = Column(String(128), unique=True, index=True)
    narration = Column(String(512))
    created_at = Column(DateTime, default=func.now())

class Entry(Base):
    __tablename__ = 'entries'
    id = Column(Integer, primary_key=True)
    transaction_id = Column(String(128), ForeignKey('transactions.transaction_id'))
    account = Column(String(128), index=True)
    debit = Column(Numeric(38, 8), default=0)
    credit = Column(Numeric(38, 8), default=0)
    created_at = Column(DateTime, default=func.now())

engine = create_engine(DATABASE_URL, echo=False)
SessionLocal = sessionmaker(bind=engine)
Base.metadata.create_all(engine)

app = FastAPI(title='HorizCoin Ledger Service')

# Pydantic models
class LedgerEntry(BaseModel):
    account: constr(min_length=1)
    debit: Decimal = Decimal('0')
    credit: Decimal = Decimal('0')

class TransactionRequest(BaseModel):
    transaction_id: constr(min_length=1)
    narration: str
    entries: List[LedgerEntry]

class TransactionResponse(BaseModel):
    transaction_id: str
    created_at: datetime

# Utility
def decimal_sum(entries):
    total_debit = Decimal('0')
    total_credit = Decimal('0')
    for e in entries:
        total_debit += Decimal(e.debit)
        total_credit += Decimal(e.credit)
    return total_debit, total_credit

@app.post('/ledger/record_transaction', response_model=TransactionResponse)
def record_transaction(req: TransactionRequest):
    # Validate double-entry
    total_debit, total_credit = decimal_sum(req.entries)
    if total_debit != total_credit:
        raise HTTPException(status_code=400, detail=f'Debit/Credit imbalance: {total_debit} != {total_credit}')

    db = SessionLocal()
    try:
        # Check idempotency
        existing = db.query(TransactionRecord).filter_by(transaction_id=req.transaction_id).first()
        if existing:
            return TransactionResponse(transaction_id=existing.transaction_id, created_at=existing.created_at)

        # Create transaction record
        tr = TransactionRecord(transaction_id=req.transaction_id, narration=req.narration)
        db.add(tr)
        # Add entries
        for e in req.entries:
            entry = Entry(transaction_id=req.transaction_id, account=e.account, debit=e.debit, credit=e.credit)
            db.add(entry)

        db.commit()
        db.refresh(tr)
        return TransactionResponse(transaction_id=tr.transaction_id, created_at=tr.created_at)
    except SQLAlchemyError as exc:
        db.rollback()
        raise HTTPException(status_code=500, detail=f'Database error: {exc}')
    finally:
        db.close()

if __name__ == '__main__':
    import uvicorn
    uvicorn.run(app, host='0.0.0.0', port=8003)
