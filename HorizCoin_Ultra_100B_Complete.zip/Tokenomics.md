# Tokenomics
Mechanics for 100B revenue.