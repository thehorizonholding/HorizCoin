# AMM Network
Automated liquidity architecture.