# Whitepaper
Full economic + technical model.