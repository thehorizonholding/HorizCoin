# Satellite Bandwidth
Leasing + resale model.