# 8 Pillars
Detailed descriptions.