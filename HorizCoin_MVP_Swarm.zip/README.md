# HorizCoin: Tokenizing Bandwidth and Data for the Decentralized Future

## Overview
This repository contains an MVP for HorizCoin (HZC) — a Proof-of-Bandwidth (PoB) DePIN project with AI data valuation and a basic marketplace.

## HorizAI Swarm Integration (October 31, 2025)
Powered by a local Swarm emulation script (horizai_swarm.py). Use it to run audits, tests, and simulated agent workstreams.

### Swarm Quick Start
1. `pip install -r backend/requirements.txt && pip install networkx`
2. `python horizai_swarm.py init` – Bootstraps agents.
3. Example: `python horizai_swarm.py test-mvp`

### Quick Start (MVP)
1. Copy `.env.example` to `.env` and fill keys.
2. Install root npm deps: `npm init -y && npm i hardhat @nomicfoundation/hardhat-toolbox @openzeppelin/contracts ethers dotenv`
3. Backend: `pip install -r backend/requirements.txt`
4. Frontend: `cd frontend && npm install`
5. Compile & deploy (Mumbai testnet): `npx hardhat compile && npx hardhat run scripts/deploy.js --network mumbai`
6. Run backend: `cd backend && uvicorn app:app --reload`
7. Run frontend: `cd frontend && npm run dev`

**Note:** This code is a blueprint and prototype. Audit smart contracts and secure secrets before any mainnet use.
