from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from dotenv import load_dotenv
import os
import requests
from langchain.llms import OpenAI
from langchain.prompts import PromptTemplate
from pob import generate_challenge, verify_proof

load_dotenv()
app = FastAPI(title="HorizCoin Backend")

llm = OpenAI(openai_api_key=os.getenv("OPENAI_API_KEY"))
valuation_prompt = PromptTemplate(
    input_variables=["data_desc", "market_factors"],
    template="Value this data parcel in USD (1-1000): {data_desc}. Factors: {market_factors}. Just a number."
)

class DataSubmission(BaseModel):
    description: str
    size_bytes: int
    hash: str

class PoBRequest(BaseModel):
    difficulty: int = 20
    size_bytes: int = 1024

@app.post("/valuate")
async def valuate_data(submission: DataSubmission):
    factors = f"Size: {submission.size_bytes}B"
    response = llm(valuation_prompt.format(data_desc=submission.description, market_factors=factors))
    try:
        value_usd = float(response.strip())
        hzc_equiv = value_usd * 1000
        ipfs_uri = f"ipfs://{submission.hash}"
        return {"value_usd": value_usd, "hzc_equiv": hzc_equiv, "ipfs_uri": ipfs_uri}
    except ValueError:
        raise HTTPException(400, "Bad valuation")

@app.post("/pob/challenge")
async def pob_challenge(req: PoBRequest):
    proof = generate_challenge(req.difficulty, req.size_bytes)
    if verify_proof(proof, req.difficulty, req.size_bytes):
        reward_hzc = (req.size_bytes / 1024) * 10
        return {"proof": proof, "reward_hzc": reward_hzc, "status": "verified"}
    raise HTTPException(400, "Invalid proof")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
