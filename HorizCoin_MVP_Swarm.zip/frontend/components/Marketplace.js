import { useState } from 'react';
import axios from 'axios';

export default function Marketplace() {
  const [req, setReq] = useState({ difficulty: 20, size_bytes: 1024 });

  const handlePoB = async () => {
    try {
      const res = await axios.post('http://localhost:8000/pob/challenge', req);
      alert(`Reward: ${res.data.reward_hzc} HZC`);
    } catch (err) {
      alert(`Failed: ${err.message}`);
    }
  };

  return (
    <div>
      <h2>PoB</h2>
      <input type="number" placeholder="Difficulty" value={req.difficulty} onChange={(e) => setReq({ ...req, difficulty: parseInt(e.target.value) })} />
      <input type="number" placeholder="Size" value={req.size_bytes} onChange={(e) => setReq({ ...req, size_bytes: parseInt(e.target.value) })} />
      <button onClick={handlePoB}>Submit</button>
    </div>
  );
}
