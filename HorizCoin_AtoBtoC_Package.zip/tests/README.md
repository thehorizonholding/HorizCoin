Run Hardhat tests in /hardhat. Add more tests for contracts, payment channels, EpochPayout, and end-to-end flows.
