const { expect } = require("chai"); const { ethers } = require("hardhat");
describe("HORC token", function () {
  it("deploys and transfers with fee to treasury", async function () {
    const [owner, treasury, alice] = await ethers.getSigners();
    const HORC = await ethers.getContractFactory("HORC"); const initialSupply = ethers.parseUnits("1000", 18); const feeBps = 200;
    const horc = await HORC.deploy(treasury.address, initialSupply, feeBps); await horc.waitForDeployment();
    const ownerBalance = await horc.balanceOf(owner.address); expect(ownerBalance).to.equal(initialSupply);
    const amount = ethers.parseUnits("100", 18); await horc.transfer(alice.address, amount);
    const aliceBalance = await horc.balanceOf(alice.address); const treasuryBalance = await horc.balanceOf(treasury.address);
    expect(aliceBalance).to.equal(ethers.parseUnits("98", 18)); expect(treasuryBalance).to.equal(ethers.parseUnits("2", 18));
  });
});