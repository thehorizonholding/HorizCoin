# Python SDK client placeholder
class HorizClient:
    pass
