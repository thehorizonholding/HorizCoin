Token classification memo template (Howey analysis per token).
