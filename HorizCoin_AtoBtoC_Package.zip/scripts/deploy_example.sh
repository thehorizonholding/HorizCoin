#!/usr/bin/env bash
# Example deploy script - adjust for your environment
echo "Start Fleet Manager (dev): cd backend/mvp && npm start &"
