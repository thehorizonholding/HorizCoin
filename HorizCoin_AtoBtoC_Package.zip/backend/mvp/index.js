const express = require('express'); const bodyParser = require('body-parser'); const app = express(); app.use(bodyParser.json());
let nodes = {}; let jobs = {};
app.get('/nodes', (req,res)=> res.json(nodes));
app.post('/nodes/register', (req,res)=>{ const {nodeId,pubKey,capabilities}=req.body; nodes[nodeId]={pubKey,capabilities,registeredAt:Date.now(),lastSeen:Date.now()}; res.json({status:'ok',nodeId}); });
app.post('/jobs', (req,res)=>{ const id='job_'+Date.now(); jobs[id]={id,spec:req.body,status:'queued',createdAt:Date.now()}; res.json({jobId:id}); });
app.post('/nodes/:id/telemetry', (req,res)=>{ const id=req.params.id; if(!nodes[id]) return res.status(404).json({error:'unknown node'}); nodes[id].lastSeen=Date.now(); nodes[id].telemetry=req.body; res.json({status:'ok'}); });
const PORT=process.env.PORT||3001; app.listen(PORT,()=>console.log('Fleet Manager listening on',PORT));