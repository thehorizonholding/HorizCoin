Architecture overview: Settlement layer, payment-channel mesh, fleet manager, DeSoc indexer, AAA runtime, RWA custody.
