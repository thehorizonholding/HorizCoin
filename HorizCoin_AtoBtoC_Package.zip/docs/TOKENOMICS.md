Tokenomics summary: HC-UTILITY (HORC), hUSD, HC-REWARD, HC-ASSET; fee splits and sample supply schedule.
