Roadmap: Phase 0..4 (MVP->Pilot->Production->Ecosystem)
