# HorizCoin Whitepaper (Compressed)

See the modular files in /docs/whitepaper_parts for full content.
