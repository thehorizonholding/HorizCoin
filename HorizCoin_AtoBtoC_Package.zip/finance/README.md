Financial model templates (CSV/XLSX) should be added here. See docs/TOKENOMICS.md for assumptions.
