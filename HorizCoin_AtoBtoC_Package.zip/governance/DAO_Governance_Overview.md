DAO governance model, proposal lifecycle, voting power, timelocks.
