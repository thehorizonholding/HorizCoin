"""Tiny demo loop for PricingEnv (no RL library wired)."""

from pricing_env import PricingEnv

def main():
    env = PricingEnv()
    obs, _ = env.reset()
    print("PricingEnv initial obs:", obs)

    for step in range(10):
        action = env.action_space.sample()
        obs, reward, terminated, truncated, info = env.step(action)
        print(f"step={step}, action={action}, reward={reward}")
        if terminated or truncated:
            obs, _ = env.reset()

if __name__ == "__main__":
    main()
