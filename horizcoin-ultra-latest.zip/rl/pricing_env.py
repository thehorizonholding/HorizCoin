import gymnasium as gym
from gymnasium import spaces
import numpy as np

class PricingEnv(gym.Env):
    """Skeleton environment for RL-based dynamic pricing."""
    metadata = {"render_modes": []}

    def __init__(self, config=None):
        super().__init__()
        self.config = config or {}
        self.num_price_points = self.config.get("num_price_points", 100)

        self.action_space = spaces.Discrete(self.num_price_points)
        self.observation_space = spaces.Box(
            low=0.0, high=1.0, shape=(10,), dtype=np.float32
        )

        self._state = np.zeros(10, dtype=np.float32)

    def reset(self, *, seed=None, options=None):
        super().reset(seed=seed)
        self._state = np.random.rand(10).astype(np.float32)
        return self._state, {}

    def step(self, action):
        # Map action index -> actual price (normalized for now)
        price = (action + 1) / self.num_price_points

        # Dummy demand curve: higher price => lower probability of acceptance
        acceptance_prob = max(0.0, 1.0 - price)
        accepted = self.np_random.random() < acceptance_prob

        estimated_cost = 0.3  # placeholder cost
        reward = 0.0
        if accepted:
            reward = float(max(price - estimated_cost, 0.0))

        self._state = np.random.rand(10).astype(np.float32)
        terminated = True
        truncated = False
        return self._state, reward, terminated, truncated, {}

    def render(self):
        pass
