"""Tiny demo loop for AllocationEnv (no RL library wired)."""

from allocation_env import AllocationEnv

def main():
    env = AllocationEnv()
    obs, _ = env.reset()
    print("AllocationEnv initial obs shape:", obs.shape)

    for step in range(10):
        action = env.action_space.sample()
        obs, reward, terminated, truncated, info = env.step(action)
        print(f"step={step}, reward={reward}")
        if terminated or truncated:
            obs, _ = env.reset()

if __name__ == "__main__":
    main()
