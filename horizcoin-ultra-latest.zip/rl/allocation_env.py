import gymnasium as gym
from gymnasium import spaces
import numpy as np

class AllocationEnv(gym.Env):
    """Skeleton environment for RL-based node allocation."""
    metadata = {"render_modes": []}

    def __init__(self, config=None):
        super().__init__()
        self.config = config or {}
        self.num_nodes = self.config.get("num_nodes", 32)

        # Observation: job requirements + simple node load metrics
        self.observation_space = spaces.Box(
            low=0.0, high=1.0, shape=(10 + self.num_nodes,), dtype=np.float32
        )

        # Action: fraction of work assigned to each node (continuous 0–1)
        self.action_space = spaces.Box(
            low=0.0, high=1.0, shape=(self.num_nodes,), dtype=np.float32
        )

        self._state = np.zeros(self.observation_space.shape, dtype=np.float32)

    def reset(self, *, seed=None, options=None):
        super().reset(seed=seed)
        self._state = np.random.rand(*self._state.shape).astype(np.float32)
        return self._state, {}

    def step(self, action):
        # Normalize allocation so sum <= 1.0
        total = float(np.sum(action)) + 1e-9
        norm_action = action / total

        # Dummy cost model: cost = sum(allocation^2) to encourage spreading load
        cost = float(np.sum(norm_action ** 2))
        qos_penalty = 0.0  # placeholder

        reward = -(cost + qos_penalty)

        self._state = np.random.rand(*self._state.shape).astype(np.float32)
        terminated = True
        truncated = False
        return self._state, reward, terminated, truncated, {}

    def render(self):
        pass
