import { Router } from 'express';

export const jobsRouter = Router();

/**
 * POST /jobs/submit
 * Minimal placeholder:
 *  - receives a job payload
 *  - returns a dummy jobId and echo
 */
jobsRouter.post('/submit', async (req, res) => {
  const job = req.body;
  res.json({ status: 'queued', jobId: 'demo-' + Date.now(), received: job });
});
