# HorizCoin Control Center (Concept)

This folder is a placeholder for:

- Job queue and scheduling
- Integration with RL agents (`../rl`)
- Integration with backend API (`../backend`)
- Observability and monitoring

In a real implementation this would likely be a set of services (Kubernetes, Nomad, etc.).
