# HorizCoin Mobile Clients (Skeleton)

This project assumes:

- **Android** client: opt-in telemetry + wallet + job console.
- **iOS** client: restricted to what the OS allows (no spyware, fully consent-based).

Implementation is **not included** because production mobile apps require
design, UX, and security reviews. Treat this repo as the backend + on-chain core.
