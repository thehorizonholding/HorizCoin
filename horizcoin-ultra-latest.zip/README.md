# HorizCoin Ultra – Private DePIN Compute Network (Skeleton)

This is a **reference implementation skeleton** for the HorizCoin Ultra private DePIN compute network.

It contains:

- `contracts/` – Solidity smart contracts (token, job settlement, revenue flywheel) + Hardhat config.
- `backend/`   – Node.js/TypeScript control-center API skeleton.
- `rl/`        – Python RL skeletons for pricing and allocation agents.
- `control_center/` – Orchestrator placeholder.
- `mobile/`    – Notes and scaffolding for Android/iOS clients (no production app).

> **Important:**  
> This is **not production ready**. It is a starting point for real engineers to extend, secure, audit, and deploy.

## Getting Started (High-Level)

- `contracts/`  
  - `npm install`  
  - Configure `.env` with RPC + key  
  - `npm run build` then `npm run deploy`

- `backend/`  
  - `npm install`  
  - `npm run dev` to start the control-center API skeleton.

- `rl/`  
  - Use Python 3.10+ and install `gymnasium` etc.  
  - Run `python train_pricing.py` or `python train_allocation.py` to see toy loops.

This repo is meant for GitHub; you can `git init` inside the unzipped folder and push.
