const hre = require("hardhat");

async function main() {
  const [deployer] = await hre.ethers.getSigners();
  console.log("Deploying with:", deployer.address);

  const HorizCoinToken = await hre.ethers.getContractFactory("HorizCoinToken");
  const horc = await HorizCoinToken.deploy(hre.ethers.parseUnits("1000000000", 18));
  await horc.waitForDeployment();
  console.log("HORC deployed at:", await horc.getAddress());

  // TODO: replace with real addresses on your target network
  const hUsdAddress = "0x0000000000000000000000000000000000000001";
  const incentivePool = deployer.address;
  const routerAddress = "0x0000000000000000000000000000000000000002";

  const Flywheel = await hre.ethers.getContractFactory("RevenueFlywheelContract");
  const flywheel = await Flywheel.deploy(
    hUsdAddress,
    await horc.getAddress(),
    routerAddress,
    incentivePool,
    5000 // 50% burn
  );
  await flywheel.waitForDeployment();
  console.log("Flywheel deployed at:", await flywheel.getAddress());

  const Settlement = await hre.ethers.getContractFactory("JobSettlementContract");
  const settlement = await Settlement.deploy(
    hUsdAddress,
    await flywheel.getAddress(),
    2000 // 20% take rate
  );
  await settlement.waitForDeployment();
  console.log("JobSettlement deployed at:", await settlement.getAddress());
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
