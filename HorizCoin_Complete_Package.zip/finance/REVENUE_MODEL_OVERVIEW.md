
# Revenue Model Overview

This folder should contain spreadsheets and scripts to simulate revenue under Conservative/Moderate/Aggressive adoption scenarios.
Columns should include nodes, MAU, devices, RWA under management, fee rates, and resulting annual revenue.
