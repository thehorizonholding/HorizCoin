
# Incident Response Plan (Template)

1. Detection & Triage
2. Internal notification
3. Public disclosure plan
4. Forensics & mitigation
5. Patch & redeploy
6. Postmortem & compensation
