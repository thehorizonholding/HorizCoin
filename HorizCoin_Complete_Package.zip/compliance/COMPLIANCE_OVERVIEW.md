
# Compliance & Legal Overview

This document outlines required legal actions and templates:
- Jurisdictional analysis (US, EU, UK, Singapore, Japan)
- Token classification memos (utility vs security)
- RWA issuance legal templates (SPV), custody agreements
- Sample KYC/AML integration pipeline (provider comparisons)
- FATF & Travel Rule considerations for on/off ramps
- Payment services licensing considerations (money transmitter laws)
