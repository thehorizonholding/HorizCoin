
# Audit Checklist

Smart Contracts:
- ERC20 compliance & edge cases
- Upgradability and proxy considerations
- Overflow and reentrancy checks
- Formal verification for critical modules (PaymentChannel, EpochPayout)

Network & Infra:
- Penetration testing (backend, fleet agents)
- Supply chain security for agent updates
- TEE/TPM attestation chain verification

Operational:
- Incident response plan
- Security incident insurance and bug bounty
