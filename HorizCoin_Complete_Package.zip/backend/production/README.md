
# Fleet Manager Production Stub

- Use Express/Node.js or Go/Rust for production-grade manager.
- Postgres for persistence.
- Provide authentication (OAuth2/JWT) for operators and clients.
- Worker queue (Redis/RabbitMQ) for job scheduling.
