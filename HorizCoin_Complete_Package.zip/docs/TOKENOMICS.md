
# Tokenomics (Complete)

Tokens:
- HC-UTILITY (HORC): payment token used in channels and for fees
- hUSD: settlement stable token
- HC-REWARD (HCR): reward and governance token
- HC-ASSET: tokenized RWA instruments

Sections included:
- Supply schedule
- Fee split (example: 80% provider, 20% flywheel)
- Vesting schedules
- Market making and liquidity provisioning
- Treasury usage and buyback/burn policy
