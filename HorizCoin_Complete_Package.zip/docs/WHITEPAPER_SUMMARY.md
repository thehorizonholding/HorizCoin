
# Project HorizCoin — Whitepaper (Complete)

## Abstract
HorizCoin is a universal decentralized financial utility (UDFU) designed to enable earning across the internet's functional surface: humans (DeSoc), hardware (DePIN), machines (M2M/AAAs), and financial capital (RWA). This whitepaper covers the full technical, economic, regulatory, and operational blueprint for building HorizCoin from MVP to global scale.

(Sections: Executive Summary, Architecture, Tokenomics, Protocols, Security, Compliance, Roadmap, Appendices...)

---

## 1. Executive Summary
... (omitted for brevity; see docs/WHITEPAPER_FULL.md for full content)
