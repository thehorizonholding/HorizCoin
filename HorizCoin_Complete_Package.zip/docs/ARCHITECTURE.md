
# Architecture Overview (Complete)

Components:
- Settlement Layer (Layer 1 or existing L1 + L2 rollups)
- Payment Channel Mesh & Watchtowers
- Fleet Manager & Fleet Agents (Depin)
- DeSoc Indexer & Identity Layer (DIDs, Profile NFTs)
- Agent Runtime & SDKs (AAAs)
- RWA Issuance & Custody Layer (legal SPVs, custodians)
- Oracles & Attestation Layer (ZK proofs, TEE attestation)
- Governance & Treasury

See docs/whitepaper_parts/03_architecture.md for full diagrams and sequence flows.
