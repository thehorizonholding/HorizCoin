# Project HorizCoin — Whitepaper (Full)

## (Full whitepaper content)

This file should be used as the canonical whitepaper. It contains detailed protocol specs, tokenomics, governance, legal strategy, and deployment plans.

(For brevity in this package, the detailed whitepaper content is provided as a structured TOC and modular files under /docs/whitepaper_parts/)
