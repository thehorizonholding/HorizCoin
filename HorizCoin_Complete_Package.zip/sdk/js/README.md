JavaScript SDK skeleton for interacting with HorizCoin: payment channels, node registry, job submission, signed state helpers.

Files:
- index.js
- channelClient.js
- nodeClient.js
