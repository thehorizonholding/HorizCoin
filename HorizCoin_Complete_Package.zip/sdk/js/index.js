// SDK entrypoint (placeholder)
module.exports = {};
