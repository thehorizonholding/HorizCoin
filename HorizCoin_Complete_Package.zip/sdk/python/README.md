Python SDK skeleton for agents and off-chain clients.

Files:
- client.py
- signer.py
