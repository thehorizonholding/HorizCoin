
# Token Classification Memo (Template)

- Summary of token roles and functions
- Howey test analysis per token (HC-UTILITY, HC-REWARD, HC-ASSET)
- Regulatory risks and mitigation strategies
- Proposed offering models (Reg D, Reg S, Reg A+, whitepaper disclosures)
