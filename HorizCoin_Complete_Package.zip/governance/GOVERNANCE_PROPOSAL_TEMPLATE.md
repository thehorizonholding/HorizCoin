
# Governance Proposal Template

Title:
Summary:
Motivation:
Specification:
Security considerations:
Backward compatibility:
Implementation plan:
Voting parameters:
