HorizCoin - Full Multi-Cloud Deployment (AWS, GCP, Azure)
=======================================================
This archive contains source templates to provision resources across
AWS (EKS), Google Cloud (GKE), and Azure (AKS) using Terraform, register
clusters with KubeFed (Kubernetes Federation), and deploy HorizCoin workloads
to all clusters via GitHub Actions.

IMPORTANT:
- This is a source-only package. Do NOT commit secrets to Git.
- Fill in cloud provider credentials as GitHub Secrets before running CI.
- Review and customize sizes, regions, and network policies to your requirements.

Main contents:
- multi-cloud/terraform/       Terraform configs for EKS/GKE/AKS (placeholders)
- multi-cloud/kubefed/         KubeFed installation and federation manifests
- .github/workflows/multicloud-deploy.yml  GitHub Actions for multi-cloud deploy
- kubernetes/                  Federated Kubernetes manifests (templates)
- scripts/                     Helper scripts for kubeconfig merging and verification
