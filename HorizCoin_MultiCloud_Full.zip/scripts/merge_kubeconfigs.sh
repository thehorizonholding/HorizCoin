#!/bin/bash
# Merge multiple kubeconfigs into KUBECONFIG for kubectl federation operations
export KUBECONFIG=$1:$2:$3
kubectl config view --flatten > merged_kubeconfig
echo "Merged kubeconfigs written to merged_kubeconfig"
