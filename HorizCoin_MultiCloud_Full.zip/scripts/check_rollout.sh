#!/bin/bash
# Simple rollout checker for all clusters (contexts passed as args)
for ctx in "$@"; do
  echo "Checking rollout in $ctx"
  kubectl --context="$ctx" rollout status deployment/horizcoin-backend -n horizcoin --timeout=120s
done
