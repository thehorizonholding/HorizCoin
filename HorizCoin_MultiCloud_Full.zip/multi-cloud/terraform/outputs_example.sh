# Example of how Terraform outputs (kubeconfigs) might be captured and saved as GitHub Secrets
# DO NOT store secrets in plain files in real projects.
echo "Use CI to capture terraform outputs and store them securely in GitHub Secrets"
