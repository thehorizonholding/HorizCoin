#!/bin/bash
# Installs KubeFedctl and registers clusters
set -e
echo "This script is a template. Install kubefedctl and run the following steps manually:"
echo "1) kubectl create ns kube-federation-system --context=<host-cluster>"
echo "2) kubefedctl init kube-federation --host-cluster-context=<host-context> --v=2"
echo "3) kubefedctl join <cluster-name> --cluster-context=<cluster-context> --host-cluster-context=<host-context> --v=2"
