# HorizCoin DePIN Prototype (Standalone)

This is a local, standalone prototype of the HorizCoin-style architecture:
- No external registrations required.
- Runs on your MacBook Pro (or any dev machine with Node.js).

Contents:
- blockchain/  – Hardhat + Solidity contracts
- backend/     – Node.js Express backend (AI + IoT mock)
- dashboard/   – Static HTML/JS control center

See README inside each folder for details.
