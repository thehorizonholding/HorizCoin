const hre = require("hardhat");

async function main() {
  const [deployer] = await hre.ethers.getSigners();
  console.log("Deploying with:", deployer.address);

  const initialSupply = hre.ethers.parseEther("1000000000");

  const HorizCoin = await hre.ethers.getContractFactory("HorizCoin");
  const horiz = await HorizCoin.deploy(initialSupply);
  await horiz.waitForDeployment();
  console.log("HorizCoin:", await horiz.getAddress());

  const DataNFT = await hre.ethers.getContractFactory("DataNFT");
  const dataNft = await DataNFT.deploy();
  await dataNft.waitForDeployment();
  console.log("DataNFT:", await dataNft.getAddress());

  const RewardPool = await hre.ethers.getContractFactory("RewardPool");
  const rewardPool = await RewardPool.deploy(await horiz.getAddress());
  await rewardPool.waitForDeployment();
  console.log("RewardPool:", await rewardPool.getAddress());
}

main().catch((e) => {
  console.error(e);
  process.exitCode = 1;
});
