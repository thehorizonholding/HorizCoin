const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");

const app = express();
app.use(cors());
app.use(bodyParser.json());

let iotEvents = [];
let lastValuations = [];

app.get("/health", (req, res) => {
  res.json({ status: "ok", message: "HorizCoin local backend running" });
});

app.post("/ai/value", (req, res) => {
  const { resourceType, amount } = req.body || {};
  const base = amount || 1;
  const valuation = {
    resourceType: resourceType || "generic",
    amount,
    tokenValue: base * 42,
    timestamp: new Date().toISOString()
  };
  lastValuations.push(valuation);
  if (lastValuations.length > 50) lastValuations.shift();
  res.json({ ok: true, valuation });
});

app.post("/iot/ingest", (req, res) => {
  const event = { ...req.body, receivedAt: new Date().toISOString() };
  iotEvents.push(event);
  if (iotEvents.length > 100) iotEvents.shift();
  res.json({ ok: true, stored: true });
});

app.get("/iot/events", (req, res) => {
  res.json({ ok: true, events: iotEvents });
});

app.get("/ai/valuations", (req, res) => {
  res.json({ ok: true, valuations: lastValuations });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`Backend http://127.0.0.1:${PORT}`);
});
