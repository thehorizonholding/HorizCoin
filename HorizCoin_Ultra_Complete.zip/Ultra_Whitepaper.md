# Ultra Whitepaper
Technical + revenue model.