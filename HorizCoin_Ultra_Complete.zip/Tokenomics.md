# Tokenomics
Economic model.