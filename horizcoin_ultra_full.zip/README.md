# HorizCoin UltraVersion
This is a placeholder skeleton containing all modules.