#!/usr/bin/env bash
set -e
echo 'Starting local docker stack...'
docker-compose -f infra/docker-compose.yml up -d --build
echo 'Contracts: run from contracts folder using hardhat local or connect to ganache at http://localhost:8545'
