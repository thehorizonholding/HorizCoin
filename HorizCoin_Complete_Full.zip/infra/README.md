# Infra

Use `docker-compose -f docker-compose.yml up --build` to run a local dev stack. Hardhat local node is simulated via Ganache at http://localhost:8545.
