import pytest
from node.bandwidth_proof import BandwidthProofer

def test_proof(): p = BandwidthProofer(1024); res = p.generate_proof(); assert 'proof' in res and res['bandwidth']>0
