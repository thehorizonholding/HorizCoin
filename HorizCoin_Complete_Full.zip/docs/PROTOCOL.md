# HorizCoin Protocol

Architecture overview:
- PoB consensus: nodes perform verifiable bandwidth challenges. Proofs are verified by an oracle/verifier off-chain and final settlement/minting is performed on-chain by the PoBValidator contract.
- Token: HORIZ ERC-20 (utility). HC-REWARD for staking/rewards. HC-ASSET for RWA (placeholder).
- Components: Node, Oracle, Watchtower, Job Marketplace, Reputation System.

Proof flow (high-level):
1. Node performs a bandwidth challenge to an assigned verifier endpoint and gets a signed attestation.
2. Node sends attestation + metadata to PoBValidator via the oracle service.
3. The oracle aggregates, verifies and triggers on-chain minting using a validator wallet.

Security: Use TEE/TPM for attestation where possible; use KYC for RWA issuance.
