# Operational Guide (Summary)

- Run DB backups daily
- Rotate secrets monthly
- Monitor watchtower submissions and job queue latencies
- Run security scans on container images
- Maintain an external metrics/alerting stack (Prometheus & Grafana)

Security: Keep private keys in an HSM or Vault. Use multisig for treasury operations.
