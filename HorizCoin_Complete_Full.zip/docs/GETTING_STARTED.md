# Getting Started — Local Devnet Simulation (HorizCoin Complete)

This guide walks through running a local devnet simulation of HorizCoin. It uses the included docker-compose to run services locally and Hardhat to run contracts on a local chain.

Prereqs: Docker, docker-compose, Node 18+, npm, Python 3.10+.

1. Build and start docker-compose:
   ```bash
   docker-compose -f infra/docker-compose.yml up --build -d
   ```
2. Deploy contracts to local Hardhat node (see contracts/README.md)
3. Start backend services (watchtower, oracle, job-scheduler) — containers are started by docker-compose or run via `npm start` in each backend folder.
4. Start node simulator: `python node/pob_node.py --devnet` (it will connect to local services)
5. Use frontend: open `frontend` and run `npm install && npm run dev` and point to local backend.

This simulation is for development and testing only.
