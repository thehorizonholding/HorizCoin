# LEO Currency Activation Guide

This document explains how to activate the future LEO currency adapter when a satellite provider publishes an API.

1. Implement the LEO adapter under `integrations/leo_adapter` to map provider attestation to PoB oracle format.
2. Configure oracle service to accept and validate LEO-specific attestations.
3. Update PoBValidator.oracle to the oracle's address.
4. Ensure legal and partnership checklists are completed with the satellite provider.
