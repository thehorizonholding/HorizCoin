import hashlib, time, os

class BandwidthProofer:
    def __init__(self, data_size=1024*1024):
        self.data_size = data_size
    def generate_proof(self):
        # Simulate sending data and measuring time
        start = time.time()
        data = os.urandom(self.data_size)
        h = hashlib.sha256(data).hexdigest()
        duration = max(0.001, time.time()-start)
        bandwidth = self.data_size / duration
        return {'proof': h, 'bandwidth': bandwidth, 'timestamp': int(start)}
