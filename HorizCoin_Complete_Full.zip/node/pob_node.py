#!/usr/bin/env python3
import time, requests, argparse
from bandwidth_proof import BandwidthProofer

class PoBNode:
    def __init__(self, node_id, oracle_url='http://localhost:4100'):
        self.node_id = node_id
        self.proofer = BandwidthProofer()
        self.oracle = oracle_url
    def run_once(self):
        proof = self.proofer.generate_proof()
        print('Generated proof', proof['proof'], 'bandwidth', proof['bandwidth'])
        # submit to oracle
        payload = {'miner': self.node_id, 'proofHash': proof['proof'], 'bandwidth': int(proof['bandwidth'])}
        try:
            r = requests.post(self.oracle + '/submit', json=payload, timeout=5)
            print('Oracle response', r.status_code, r.text)
        except Exception as e:
            print('Oracle submission failed', e)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--id', default='node-1'); args = parser.parse_args()
    node = PoBNode(args.id)
    while True:
        node.run_once()
        time.sleep(60)
