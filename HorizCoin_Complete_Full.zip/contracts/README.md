# Contracts

This folder contains Solidity contracts and Hardhat config. Use the Hardhat local node for testing.

Steps:
1. cd contracts
2. npm ci
3. npx hardhat node (in one terminal)
4. npx hardhat run scripts/deploy_local.js --network localhost
5. npx hardhat test
