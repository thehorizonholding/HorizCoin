Oracle service verifies proofs from nodes and submits verified proofs to PoBValidator on-chain.

This folder contains a simulated oracle with an HTTP API that accepts node attestations and calls the contract's submitVerifiedProof method using the oracle's private key.
