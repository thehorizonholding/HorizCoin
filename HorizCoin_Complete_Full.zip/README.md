# HorizCoin — Complete Code Package (Best-Effort)

Generated: 2025-11-26T17:03:25.993146Z

This repository contains a best-effort *complete* codebase for the HorizCoin project, implementing the Proof-of-Bandwidth (PoB) protocol, token contracts, staking, reputation, watchtower, job scheduler, oracle, node simulator, SDKs, frontend skeleton, deployment scripts, and documentation.

**Reality check:** This package is a comprehensive code delivery, but it is **not** production-ready. You must perform third-party smart contract audits, security penetration tests, legal/regulatory compliance, and deploy real infra (Kubernetes, HSM/Vault, cloud networks). Satellite provider and LEO-token integrations require partner APIs that are not available inside this environment.

Folders included:
- contracts/       (Solidity smart contracts + Hardhat)
- node/            (Python node, P2P simulator, proofs)
- oracle/          (bandwidth oracle & verifier)
- backend/         (watchtower, job-scheduler, reputation services)
- frontend/        (React app skeleton)
- infra/           (docker, docker-compose, k8s placeholders, terraform placeholders)
- docs/            (protocol, ops, activation)
- scripts/         (helpers to run local dev)
- tests/           (hardhat tests, pytest)

See /docs/GETTING_STARTED.md for step-by-step instructions to run a local devnet simulation.
