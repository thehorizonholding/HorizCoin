// SDK helper to interact with oracle
const fetch = require('node-fetch');
class HorizSDK{ constructor(oracle){ this.oracle = oracle || 'http://localhost:4100'; }
 async submitProof(miner, proofHash, bandwidth){ const res = await fetch(this.oracle + '/submit', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({miner, proofHash, bandwidth})}); return res.json(); }}
module.exports = HorizSDK;