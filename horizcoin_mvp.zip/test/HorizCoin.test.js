const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("HorizCoin", function () {
  it("Should mint total supply to deployer", async function () {
    const HorizCoin = await ethers.getContractFactory("HorizCoin");
    const hzc = await HorizCoin.deploy();
    await hzc.waitForDeployment();

    const totalSupply = await hzc.totalSupply();
    expect(totalSupply).to.equal(ethers.parseEther("10000000000"));
  });

  it("Should allow owner to mint rewards", async function () {
    const HorizCoin = await ethers.getContractFactory("HorizCoin");
    const hzc = await HorizCoin.deploy();
    await hzc.waitForDeployment();

    const [owner, addr1] = await ethers.getSigners();
    await hzc.mintRewards(addr1.address, ethers.parseEther("100"));
    expect(await hzc.balanceOf(addr1.address)).to.equal(ethers.parseEther("100"));
  });
});
