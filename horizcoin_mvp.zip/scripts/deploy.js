const hre = require("hardhat");

async function main() {
  const [deployer] = await hre.ethers.getSigners();
  console.log("Deploying contracts with account:", deployer.address);

  // Deploy HZC
  const HorizCoin = await hre.ethers.getContractFactory("HorizCoin");
  const hzc = await HorizCoin.deploy();
  await hzc.waitForDeployment();
  console.log("HZC deployed to:", await hzc.getAddress());

  // Deploy DataToken
  const DataToken = await hre.ethers.getContractFactory("DataToken");
  const dataToken = await DataToken.deploy();
  await dataToken.waitForDeployment();
  console.log("DataToken deployed to:", await dataToken.getAddress());

  // Verify on PolygonScan (manual step)
  console.log("\nVerify with: npx hardhat verify --network mumbai <address>");
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
