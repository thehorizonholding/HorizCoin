# HorizCoin: Tokenizing Bandwidth and Data for the Decentralized Future

See README in the project root for quick start instructions.
