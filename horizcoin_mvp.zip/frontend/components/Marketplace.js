import { useState } from 'react';
import axios from 'axios';

export default function Marketplace() {
  const [req, setReq] = useState({ difficulty: 20, size_bytes: 1024 });

  const handlePoB = async () => {
    try {
      const res = await axios.post('http://localhost:8000/pob/challenge', req);
      alert(`PoB Verified! Reward: ${res.data.reward_hzc} HZC\nSolve Time: ${res.data.proof.solve_time}s`);
      console.log('Proof:', res.data.proof);
    } catch (err) {
      alert(`PoB Failed: ${err.response?.data?.detail || err.message}`);
    }
  };

  return (
    <div style={{ marginTop: '20px', padding: '15px', border: '1px solid #ccc' }}>
      <h2>Prove Bandwidth (DePIN Mining)</h2>
      <p>Earn HZC by contributing network resources.</p>
      <input
        type="number"
        placeholder="Difficulty (hash zeros)"
        value={req.difficulty}
        onChange={(e) => setReq({ ...req, difficulty: parseInt(e.target.value) || 20 })}
        style={{ margin: '5px', padding: '8px' }}
      />
      <br />
      <input
        type="number"
        placeholder="Data Size (bytes)"
        value={req.size_bytes}
        onChange={(e) => setReq({ ...req, size_bytes: parseInt(e.target.value) || 1024 })}
        style={{ margin: '5px', padding: '8px' }}
      />
      <br />
      <button onClick={handlePoB} style={{ margin: '10px', padding: '10px' }}>
        Submit PoB Challenge
      </button>
    </div>
  );
}
