import { useState } from 'react';
import axios from 'axios';
import Marketplace from '../components/Marketplace';

export default function Home() {
  const [data, setData] = useState({
    description: '',
    size: 1024,
    hash: 'QmExampleCID123'
  });

  const handleValuate = async () => {
    try {
      const res = await axios.post('http://localhost:8000/valuate', data);
      alert(`Valuation: $${res.data.value_usd} USD (~${res.data.hzc_equiv} HZC)\nIPFS: ${res.data.ipfs_uri}`);
    } catch (err) {
      alert(`Error: ${err.response?.data?.detail || err.message}`);
    }
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial' }}>
      <h1>HorizCoin DePIN Marketplace MVP</h1>
      <p>Submit data for AI valuation and mint as NFT.</p>
      <input
        placeholder="Data Description (e.g., Fresh IoT traffic)"
        value={data.description}
        onChange={(e) => setData({ ...data, description: e.target.value })}
        style={{ margin: '5px', padding: '8px', width: '300px' }}
      />
      <br />
      <input
        type="number"
        placeholder="Size (bytes)"
        value={data.size}
        onChange={(e) => setData({ ...data, size: parseInt(e.target.value) || 1024 })}
        style={{ margin: '5px', padding: '8px' }}
      />
      <br />
      <input
        placeholder="Data Hash/CID"
        value={data.hash}
        onChange={(e) => setData({ ...data, hash: e.target.value })}
        style={{ margin: '5px', padding: '8px', width: '300px' }}
      />
      <br />
      <button onClick={handleValuate} style={{ margin: '10px', padding: '10px' }}>
        Valuate & Tokenize
      </button>
      <Marketplace />
    </div>
  );
}
