CREATE TABLE IF NOT EXISTS satellite_telemetry(...);
