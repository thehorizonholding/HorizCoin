# DePIN Overview
This document describes the architecture.
