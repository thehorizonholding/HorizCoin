# HorizCoin Project Bundle
Scaffold containing smart contracts, backend API, agent tools, ingestion job, migrations, and deployment helpers.