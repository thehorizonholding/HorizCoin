
Operational Runbook - Summary
1. Start Postgres and run migrations (infra/migrations/*.sql)
2. Start services: fleet_manager, job_scheduler, watchtower, reputation
3. Monitor /nodes and job queue; ensure watchtower has visibility into channels
4. Run periodic reputation scoring and push to chain via owner API (simulated)
5. Backup DB and rotate keys monthly
