const express = require('express'); const bodyParser = require('body-parser'); const app = express(); app.use(bodyParser.json()); let scores = {};
app.post('/metrics/report', (req,res)=>{ const {nodeId, metrics} = req.body; const score = Math.max(0, Math.floor((metrics.uptime_pct || 100) * 0.6 + (metrics.success_rate || 100) * 0.4)); scores[nodeId] = score; res.json({nodeId, score}); });
app.get('/scores', (req,res)=> res.json(scores));
app.post('/scores/push', async (req,res)=>{ const {nodeId, ownerApiKey, score} = req.body; console.log('PUSH to chain simulated', nodeId, score); res.json({status:'pushed'}); });
const PORT = process.env.PORT || 3200; app.listen(PORT, ()=> console.log('Reputation service on', PORT));