const express = require('express'); const bodyParser = require('body-parser'); const axios = require('axios');
const app = express(); app.use(bodyParser.json());
let watched = {};
app.post('/watch', (req,res)=>{ const {channel, state, callbackUrl, rewardCallback} = req.body; watched[channel] = {state, callbackUrl, rewardCallback, retries:0, lastAttempt:0}; res.json({status:'watching'}); });
async function attemptSubmit(channel, entry){
  try{
    const {state, callbackUrl} = entry;
    await axios.post(callbackUrl, state, {timeout:8000});
    if(entry.rewardCallback){ await axios.post(entry.rewardCallback, {channel, status:'reward'}).catch(()=>{}); }
    delete watched[channel];
    console.log('submitted', channel);
  }catch(e){
    entry.retries += 1; entry.lastAttempt = Date.now();
    console.error('submit failed for', channel, 'retry', entry.retries);
    if(entry.retries > 5){ console.error('max retries reached for', channel); delete watched[channel]; }
  }
}
setInterval(()=>{ for(const ch in watched){ const entry = watched[ch]; if(Date.now() - (entry.lastAttempt||0) > 5000){ attemptSubmit(ch, entry); } } }, 3000);
app.get('/watched', (req,res)=> res.json(watched));
const PORT = process.env.PORT || 4002; app.listen(PORT, ()=> console.log('Enhanced Watchtower running', PORT));