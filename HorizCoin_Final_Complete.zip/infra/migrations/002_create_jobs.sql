-- 002_create_jobs.sql
CREATE TABLE IF NOT EXISTS jobs (
  id SERIAL PRIMARY KEY,
  node_id TEXT,
  spec JSONB,
  status TEXT DEFAULT 'queued',
  created_at TIMESTAMP DEFAULT now()
);
