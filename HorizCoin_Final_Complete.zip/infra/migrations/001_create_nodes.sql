-- 001_create_nodes.sql
CREATE TABLE IF NOT EXISTS nodes (
  id TEXT PRIMARY KEY,
  pubkey TEXT,
  capabilities JSONB,
  created_at TIMESTAMP DEFAULT now(),
  last_seen TIMESTAMP
);
