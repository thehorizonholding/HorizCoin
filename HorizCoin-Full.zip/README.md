# HorizCoin Full Project
Skeleton.