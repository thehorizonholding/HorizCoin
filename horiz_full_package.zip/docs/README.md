Docs folder - add architecture diagrams, manuals, and operation runbooks here.
