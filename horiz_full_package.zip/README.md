# HorizCoin - Full Project Skeleton with AI Orchestrator

This package is a full project skeleton integrating the safe, human-in-loop AI Orchestrator.
It is intended for lawful, private use only and **blocks** disallowed actions (mining, unauthorized access).

**Contents**
- core/            : Placeholder for blockchain core
- saas/            : Placeholder for SaaS platform
- ai/              : AI orchestrator components and controller (safe, dry-run default)
- cloud/           : Cloud connector placeholders
- security/        : Security and compliance docs
- docs/            : Manuals and guides (placeholders)

IMPORTANT: Connectors are stubs and must be replaced with real, Vault-backed implementations before executing any real actions.
Execution requires multi-approver approvals, an operator confirmation file, and explicit environment variables to enable live execution.
