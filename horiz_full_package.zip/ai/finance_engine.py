# finance_engine.py - modular finance helpers
from decimal import Decimal
import uuid, time, json

class FinanceEngine:
    def __init__(self):
        self.accounts = {}

    def credit_account(self, account_id, amount):
        a = self.accounts.setdefault(account_id, {'balance': Decimal('0'), 'invoices': []})
        a['balance'] += Decimal(str(amount))
        return a['balance']

    def debit_account(self, account_id, amount):
        a = self.accounts.setdefault(account_id, {'balance': Decimal('0'), 'invoices': []})
        if a['balance'] < Decimal(str(amount)):
            raise ValueError('insufficient funds')
        a['balance'] -= Decimal(str(amount))
        return a['balance']

    def record_spend(self, account_id, items):
        total = sum([Decimal(str(it['amount'])) for it in items])
        inv = {'invoice_id': str(uuid.uuid4()), 'items': items, 'total': str(total), 'ts': int(time.time())}
        self.accounts.setdefault(account_id, {'balance': Decimal('0'), 'invoices': []})['invoices'].append(inv)
        return inv
