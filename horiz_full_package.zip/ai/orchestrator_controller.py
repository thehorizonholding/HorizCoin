#!/usr/bin/env python3
"""orchestrator_controller.py

Single-file, safe, human-in-loop Multi-Cloud Orchestrator controller.
- Dry-run by default.
- Explicit multi-approver approval and operator confirmation required for execution.
- Contains placeholders for cloud connectors and custody connectors (DO NOT use them without replacing with production connectors and Vault-backed secrets).
- Blocks any plan step that contains mining-related keywords or unauthorized actions.
"""

from __future__ import annotations
import argparse
import os
import json
import time
import uuid
from dataclasses import dataclass, asdict
from decimal import Decimal
from typing import List, Dict, Any, Tuple

# ---------------------------
# Configuration & constants
# ---------------------------
APPROVED_EXECUTION_FILE = "APPROVED_EXECUTION"  # local file must exist for execution
ENV_RUN_MODE = os.getenv("ORCH_RUN_MODE", "dry-run")  # dry-run or execute
ENV_ALLOW_EXEC = os.getenv("ORCH_ALLOW_EXECUTION", "0")  # must be "1" to allow execute path
DEFAULT_APPROVALS_REQUIRED = int(os.getenv("ORCH_REQUIRED_APPROVALS", "1"))  # required approvers
DISALLOWED_KEYWORDS = ["mine", "mining", "mint", "coin", "exploit", "steal", "botnet", "cryptominer"]

# ---------------------------
# Utilities
# ---------------------------
def now_ts() -> int:
    return int(time.time())

def generate_id(prefix="id") -> str:
    return f"{prefix}-{uuid.uuid4().hex[:8]}"

def safe_json(o: Any) -> str:
    return json.dumps(o, indent=2, default=str)

def contains_disallowed(text: str) -> bool:
    t = text.lower()
    for kw in DISALLOWED_KEYWORDS:
        if kw in t:
            return True
    return False

# ---------------------------
# Data classes
# ---------------------------
@dataclass
class Node:
    id: str
    provider: str
    region: str
    price_per_hour: float
    cpu: int
    memory_gb: float
    latency_ms: float
    reliability: float
    tags: Dict[str,str]

@dataclass
class PlanStep:
    id: str
    action: str
    provider: str
    region: str
    params: Dict[str,Any]
    cost_estimate_usd: float
    description: str

@dataclass
class Plan:
    id: str
    goal: str
    budget_usd: float
    steps: List[PlanStep]
    created_at: int
    status: str  # pending, approved, executed
    approvals: List[Dict[str,Any]]
    metadata: Dict[str,Any]

# ---------------------------
# Privacy & policy guard
# ---------------------------
class PrivacyGuard:
    """
    Simple policy engine:
     - Blocks any steps that mention disallowed words.
     - Ensures no export of sensitive data types (configurable).
     - In production, integrate with OPA and consent DB.
    """
    def __init__(self):
        self.allowed_data_types = {"metrics","telemetry","aggregates"}

    def verify_plan(self, plan: Plan) -> Tuple[bool,List[str]]:
        issues = []
        for step in plan.steps:
            # check description and action for disallowed keywords
            combined = f"{step.action} {step.description} {safe_json(step.params)}"
            if contains_disallowed(combined):
                issues.append(f"Step {step.id} contains disallowed keywords (possible mining/illegal operation).")
            # example check: block raw export of 'raw_data' type
            if step.params.get("type") == "raw_data" and step.params.get("recipient") is not None:
                issues.append(f"Step {step.id} attempts export of raw data to recipient {step.params.get('recipient')}")
        ok = len(issues) == 0
        return ok, issues

# ---------------------------
# Server selector
# ---------------------------
class ServerSelector:
    """
    Ranks nodes based on cost, perf, latency, reliability.
    This is offline/dry-run safe by default.
    """
    def __init__(self, weights=None):
        if weights is None:
            weights = {'price':1.0, 'perf':0.8, 'latency':0.5, 'reliability':0.6}
        self.weights = weights

    def score_node(self, node: Node) -> float:
        price_score = 1.0 / max(0.0001, node.price_per_hour)
        perf_score = (node.cpu * 0.6) + (node.memory_gb * 0.4)
        latency_score = 1.0 / max(1.0, node.latency_ms)
        reliability_score = node.reliability
        total = (self.weights['price'] * price_score +
                 self.weights['perf']  * perf_score +
                 self.weights['latency'] * latency_score +
                 self.weights['reliability'] * reliability_score)
        return total

    def select_nodes(self, nodes: List[Node], budget_usd: float, required_tags: Dict[str,str]=None, max_nodes=10) -> Dict[str,Any]:
        if required_tags:
            def tag_ok(n):
                for k,v in required_tags.items():
                    if n.tags.get(k) != v:
                        return False
                return True
            nodes = [n for n in nodes if tag_ok(n)]
        scored = [(self.score_node(n), n) for n in nodes]
        scored.sort(reverse=True, key=lambda x: x[0])
        plan = {'budget_usd': budget_usd, 'allocations': []}
        remaining = budget_usd
        for s, n in scored:
            if len(plan['allocations']) >= max_nodes:
                break
            allocate = min(remaining, 100.0)  # demo allocation per node
            if allocate <= 0:
                break
            plan['allocations'].append({'node_id': n.id, 'provider': n.provider, 'region': n.region, 'score': round(s,4), 'allocated_usd': round(allocate,2)})
            remaining -= allocate
        plan['remaining_usd'] = round(remaining,2)
        return plan

# ---------------------------
# Deployment planner
# ---------------------------
class DeployPlanner:
    """Creates deploy steps from allocations."""
    def create_steps(self, service_name: str, image: str, allocations: List[Dict[str,Any]]) -> List[PlanStep]:
        steps = []
        sid = 1
        for a in allocations:
            step = PlanStep(
                id = f"step-{sid}",
                action = "deploy_container",
                provider = a['provider'],
                region = a['region'],
                params = {
                    "service": service_name,
                    "image": image,
                    "replicas": 1,
                    "node_id": a['node_id']
                },
                cost_estimate_usd = a.get('allocated_usd', 0.0),
                description = f"Deploy {service_name} to node {a['node_id']} on {a['provider']}/{a['region']}"
            )
            steps.append(step)
            sid += 1
        return steps

    def simulate_steps(self, steps: List[PlanStep]) -> Dict[str,Any]:
        results = []
        for s in steps:
            ok = True
            issues = []
            # sample policy: disallow PCI-labeled service on Alibaba (demo)
            if s.provider.lower().startswith("alibaba") and s.params.get("service","").startswith("pci-"):
                ok = False
                issues.append("Compliance policy disallows PCI workload on Alibaba in this environment")
            results.append({"id": s.id, "ok": ok, "issues": issues})
        return {"simulated_at": now_ts(), "results": results}

# ---------------------------
# Finance engine (in-memory demo)
# ---------------------------
class FinanceEngine:
    """Simple in-memory ledger. In production, use DB and proper accounting."""
    def __init__(self):
        self.accounts = {}  # account_id -> {'balance':Decimal, 'invoices':[]}

    def credit(self, account_id: str, amount: Decimal):
        acct = self.accounts.setdefault(account_id, {'balance': Decimal('0'), 'invoices': []})
        acct['balance'] += Decimal(amount)
        return acct['balance']

    def debit(self, account_id: str, amount: Decimal):
        acct = self.accounts.setdefault(account_id, {'balance': Decimal('0'), 'invoices': []})
        if acct['balance'] < Decimal(amount):
            raise ValueError("insufficient funds")
        acct['balance'] -= Decimal(amount)
        return acct['balance']

    def record_spend(self, account_id: str, items: List[Dict[str,Any]]):
        total = sum([Decimal(str(it['amount'])) for it in items])
        inv_id = generate_id("inv")
        invoice = {'invoice_id': inv_id, 'items': items, 'total': str(total), 'timestamp': now_ts()}
        self.accounts.setdefault(account_id, {'balance':Decimal('0'),'invoices':[]})['invoices'].append(invoice)
        return invoice

# ---------------------------
# Approval gate (safe)
# ---------------------------
class ApprovalGate:
    def __init__(self, required_approvals:int=DEFAULT_APPROVALS_REQUIRED):
        self.required = required_approvals
        self.approvals = {}  # plan_id -> list of approver ids

    def add_approval(self, plan_id: str, approver: str, note:str=""):
        lst = self.approvals.setdefault(plan_id, [])
        lst.append({'approver':approver, 'note':note, 'ts': now_ts()})
        return len(lst)

    def is_approved(self, plan_id: str) -> bool:
        return len(self.approvals.get(plan_id, [])) >= self.required

    def approvals_count(self, plan_id: str) -> int:
        return len(self.approvals.get(plan_id, []))

# ---------------------------
# Connector stubs (must be replaced in production)
# ---------------------------
class CloudConnectorStub:
    """DO NOT use this in production. Replace with SDK-backed implementations (boto3, google-cloud, aliyun, azure)."""
    def deploy_container(self, provider:str, region:str, params:Dict[str,Any]) -> Dict[str,Any]:
        time.sleep(0.05)
        return {"status":"ok", "provider": provider, "region": region, "params": params, "tx": generate_id("deploy")}

class CustodyConnectorStub:
    """DO NOT use in production. Replace with custodian SDK or CCXT wrapper that fetches keys from Vault."""
    def create_settlement(self, amount_usd:float, destination:Dict[str,Any]) -> Dict[str,Any]:
        time.sleep(0.05)
        return {"status":"simulated", "tx": generate_id("settle"), "amount": amount_usd, "dest": destination}

# ---------------------------
# Simple signer (placeholder)
# ---------------------------
def sign_payload(payload: Dict[str,Any]) -> str:
    import hashlib, base64
    j = json.dumps(payload, sort_keys=True).encode()
    h = hashlib.sha256(j).digest()
    return base64.b64encode(h).decode()

# ---------------------------
# Orchestrator (main)
# ---------------------------
class Orchestrator:
    def __init__(self):
        self.privacy = PrivacyGuard()
        self.selector = ServerSelector()
        self.planner = DeployPlanner()
        self.finance = FinanceEngine()
        self.approval = ApprovalGate()
        self.cloud = CloudConnectorStub()
        self.custody = CustodyConnectorStub()
        self.plans = {}  # plan_id -> Plan

    def discover_nodes(self) -> List[Node]:
        nodes = [
            Node("aws-1","aws","us-east-1",0.08,4,16,12,0.995,{"compliance":"pci"}),
            Node("gcp-1","gcp","europe-west1",0.09,8,32,24,0.990,{"compliance":"pci"}),
            Node("ali-1","alibaba","ap-southeast-1",0.05,4,8,80,0.97,{}),
        ]
        return nodes

    def create_plan_from_goal(self, goal: str, budget_usd: float, service_name:str="service", image:str="image:latest", required_tags:Dict[str,str]=None) -> Plan:
        nodes = self.discover_nodes()
        alloc = self.selector.select_nodes(nodes, budget_usd, required_tags=required_tags)
        steps = self.planner.create_steps(service_name, image, alloc['allocations'])
        plan = Plan(
            id = generate_id("plan"),
            goal = goal,
            budget_usd = budget_usd,
            steps = steps,
            created_at = now_ts(),
            status = "pending",
            approvals = [],
            metadata = {"alloc": alloc}
        )
        self.plans[plan.id] = plan
        return plan

    def verify_plan(self, plan: Plan) -> Tuple[bool, List[str]]:
        ok, issues = self.privacy.verify_plan(plan)
        sim = self.planner.simulate_steps(plan.steps)
        for r in sim['results']:
            if not r['ok']:
                issues.append(f"Simulation issue for {r['id']}: {r['issues']}")
        return (len(issues) == 0, issues)

    def request_approval(self, plan: Plan, approver_id: str, note:str=""):
        count = self.approval.add_approval(plan.id, approver_id, note)
        plan.approvals.append({'approver':approver_id, 'note':note, 'ts':now_ts()})
        if self.approval.is_approved(plan.id):
            plan.status = "approved"
        return count

    def simulate_execution(self, plan: Plan) -> Dict[str,Any]:
        results = []
        for s in plan.steps:
            combined = f"{s.action} {s.description} {safe_json(s.params)}"
            if contains_disallowed(combined):
                results.append({'id':s.id, 'status':'blocked', 'detail':'disallowed keyword detected'})
                continue
            results.append({'id':s.id, 'status':'simulated', 'detail':'ok', 'expected_cost': s.cost_estimate_usd})
        return {'simulated_at': now_ts(), 'results': results}

    def execute_plan(self, plan: Plan, executor:str="operator", dry_run:bool=True) -> Dict[str,Any]:
        if plan.status != "approved":
            return {'error':'plan not approved', 'plan_status': plan.status}
        if dry_run:
            return self.simulate_execution(plan)
        if not os.path.exists(APPROVED_EXECUTION_FILE):
            return {'error':f"missing operator confirmation file {APPROVED_EXECUTION_FILE}"}
        if ENV_ALLOW_EXEC != "1":
            return {'error':"execution not allowed: ORCH_ALLOW_EXECUTION != 1"}
        results = []
        for s in plan.steps:
            combined = f"{s.action} {s.description} {safe_json(s.params)}"
            if contains_disallowed(combined):
                results.append({'id':s.id, 'status':'blocked','detail':'disallowed'})
                continue
            try:
                res = self.cloud.deploy_container(s.provider, s.region, s.params)
                results.append({'id':s.id,'status':'ok','result': res})
            except Exception as e:
                results.append({'id':s.id,'status':'error','error':str(e)})
        plan.status = "executed"
        record = {'plan_id': plan.id, 'executor': executor, 'results': results, 'ts': now_ts()}
        signature = sign_payload(record)
        return {'executed_at': now_ts(), 'results': results, 'signature': signature}

    def generate_report(self, plan: Plan) -> Dict[str,Any]:
        total_cost = sum([s.cost_estimate_usd for s in plan.steps])
        return {
            'plan_id': plan.id,
            'goal': plan.goal,
            'steps': len(plan.steps),
            'total_cost_estimate': total_cost,
            'status': plan.status,
            'approvals': plan.approvals,
            'metadata': plan.metadata
        }

# ---------------------------
# CLI methods
# ---------------------------
def write_plan_to_file(plan: Plan, path: str):
    obj = {
        'id': plan.id,
        'goal': plan.goal,
        'budget_usd': plan.budget_usd,
        'steps': [asdict(s) for s in plan.steps],
        'created_at': plan.created_at,
        'status': plan.status,
        'approvals': plan.approvals,
        'metadata': plan.metadata
    }
    with open(path, "w") as f:
        json.dump(obj, f, indent=2)
    print(f"Plan written to {path}")

def load_plan_from_file(path: str) -> Plan:
    with open(path) as f:
        obj = json.load(f)
    steps = [PlanStep(**s) for s in obj.get('steps',[])]
    p = Plan(id=obj['id'], goal=obj['goal'], budget_usd=obj['budget_usd'], steps=steps,
             created_at=obj.get('created_at', now_ts()), status=obj.get('status','pending'),
             approvals=obj.get('approvals',[]), metadata=obj.get('metadata',{}))
    return p

# ---------------------------
# Main CLI
# ---------------------------
def main():
    parser = argparse.ArgumentParser(description="Safe Multi-Cloud Orchestrator Controller (single-file)")
    parser.add_argument("--goal", help="Goal text to create a plan (create mode)")
    parser.add_argument("--budget", type=float, default=500.0, help="Budget USD for plan creation")
    parser.add_argument("--service", default="demo-service", help="Service name to deploy")
    parser.add_argument("--image", default="demo/image:latest", help="Container image reference")
    parser.add_argument("--plan", help="Path to plan.json (load existing plan)")
    parser.add_argument("--out", default="plan.json", help="Output plan file when creating")
    parser.add_argument("--simulate", action="store_true", help="Simulate plan execution (dry-run)")
    parser.add_argument("--approve", action="store_true", help="Approve a loaded plan (requires --approver)")
    parser.add_argument("--approver", help="Approver id when approving")
    parser.add_argument("--execute", action="store_true", help="Execute an approved plan (requires operator confirmation and ORCH_ALLOW_EXECUTION=1)")
    parser.add_argument("--dry", action="store_true", help="When executing, force dry-run mode (simulate only)")
    args = parser.parse_args()

    orch = Orchestrator()

    if args.goal:
        print("Creating plan for goal:", args.goal)
        plan = orch.create_plan_from_goal(args.goal, args.budget, service_name=args.service, image=args.image)
        ok, issues = orch.verify_plan(plan)
        print("Verification OK:", ok)
        if issues:
            print("Verification issues:", issues)
        write_plan_to_file(plan, args.out)
        print("Plan summary:")
        print(safe_json(orch.generate_report(plan)))
        return

    if args.plan:
        if not os.path.exists(args.plan):
            print("Plan file not found:", args.plan)
            return
        plan = load_plan_from_file(args.plan)
        orch.plans[plan.id] = plan

        if args.approve:
            if not args.approver:
                print("Approver id required with --approve --approver <id>")
                return
            count = orch.request_approval(plan, args.approver, note="approved via CLI")
            print(f"Approval added. Current approvals count: {count}. Required: {orch.approval.required}")
            write_plan_to_file(plan, args.plan)
            return

        if args.simulate:
            sim = orch.simulate_execution(plan)
            print("Simulation result:")
            print(safe_json(sim))
            return

        if args.execute:
            if args.dry:
                print("Executing in dry-run mode (simulate only).")
                sim = orch.simulate_execution(plan)
                print(safe_json(sim))
                return
            if not orch.approval.is_approved(plan.id):
                print("Plan not approved. Approvals:", orch.approval.approvals_count(plan.id))
                return
            if not os.path.exists(APPROVED_EXECUTION_FILE):
                print(f"Operator confirmation file `{APPROVED_EXECUTION_FILE}` not found. Place it in repo root to confirm execution.")
                return
            if ENV_ALLOW_EXEC != "1":
                print("Execution environment variable ORCH_ALLOW_EXECUTION != 1. Set it to 1 to allow execution.")
                return
            res = orch.execute_plan(plan, executor="cli-executor", dry_run=False)
            print("Execution result:")
            print(safe_json(res))
            write_plan_to_file(plan, args.plan)
            return

        print("Loaded plan summary:")
        print(safe_json(orch.generate_report(plan)))
        return

    print("No action specified. Use --goal to create a plan or --plan to load an existing plan.")
    parser.print_help()

if __name__ == "__main__":
    main()
