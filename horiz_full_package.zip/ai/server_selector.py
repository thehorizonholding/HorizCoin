# server_selector.py - modular version of the server selection logic
from dataclasses import dataclass
from typing import List, Dict, Any
from decimal import Decimal

@dataclass
class Node:
    id: str
    provider: str
    region: str
    price_per_hour: float
    cpu: int
    memory_gb: float
    latency_ms: float
    reliability: float
    tags: Dict[str,str]

def score_node(node: Node, weights: Dict[str,float]) -> float:
    price_score = 1.0 / max(0.0001, node.price_per_hour)
    perf_score = (node.cpu * 0.6) + (node.memory_gb * 0.4)
    latency_score = 1.0 / max(1.0, node.latency_ms)
    reliability_score = node.reliability
    total = (weights['price'] * price_score +
             weights['perf']  * perf_score +
             weights['latency'] * latency_score +
             weights['reliability'] * reliability_score)
    return total

def select_nodes(nodes: List[Node], budget: float, weights=None, max_nodes=10):
    if weights is None:
        weights = {'price':1.0, 'perf':0.8, 'latency':0.5, 'reliability':0.6}
    scored = [(score_node(n, weights), n) for n in nodes]
    scored.sort(reverse=True, key=lambda x: x[0])
    plan = {'budget': budget, 'allocations': []}
    remaining = budget
    for s,n in scored:
        if len(plan['allocations']) >= max_nodes:
            break
        allocate = min(remaining, 100.0)
        if allocate <= 0:
            break
        plan['allocations'].append({'node_id': n.id, 'provider': n.provider, 'region': n.region, 'score': s, 'allocated_usd': allocate})
        remaining -= allocate
    plan['remaining'] = remaining
    return plan
