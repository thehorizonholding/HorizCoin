# AI Orchestrator (safe version)

This folder contains the single-file orchestrator and modular helpers.
- orchestrator_controller.py : main single-file orchestrator (dry-run default)
- server_selector.py         : modular server selection logic
- deploy_planner.py          : modular deployment planner & simulator
- finance_engine.py          : modular finance/accounting helpers

IMPORTANT: Replace connector stubs with Vault-backed production connectors before live execution.
