# deploy_planner.py - modular deploy planner
import json
def create_deploy_steps(service_name, image, allocations):
    steps = []
    sid = 1
    for a in allocations:
        steps.append({
            'id': f'step-{sid}',
            'action': 'deploy_container',
            'provider': a['provider'],
            'region': a['region'],
            'params': {'service': service_name, 'image': image, 'node_id': a['node_id']},
            'cost_estimate_usd': a.get('allocated_usd', 0.0),
            'description': f"Deploy {service_name} to {a['node_id']}"
        })
        sid += 1
    return steps

def simulate_plan(steps):
    results = []
    for s in steps:
        ok = True
        issues = []
        results.append({'id': s['id'], 'ok': ok, 'issues': issues})
    return {'simulated_at': int(time.time()), 'results': results}
