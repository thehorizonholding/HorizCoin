// main.dart — Complete Flutter app for HorizCoin Data Marketplace (UI scaffold)
import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:provider/provider.dart';
import 'package:flutter_web3/flutter_web3.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (context) => MetaMaskProvider()..init(),
      child: const HorizCoinApp(),
    ),
  );
}

class MetaMaskProvider extends ChangeNotifier {
  static const int operatingChain = 11155111;
  String currentAddress = "";
  int currentChain = -1;

  bool get isEnabled => ethereum != null;
  bool get isInOperatingChain => currentChain == operatingChain;
  bool get isConnected => isEnabled && currentAddress.isNotEmpty;

  Future<void> connect() async {
    if (!isEnabled) return;
    final accs = await ethereum!.requestAccount();
    if (accs.isNotEmpty) {
      currentAddress = accs.first;
      currentChain = await ethereum!.getChainId();
    }
    notifyListeners();
  }

  void clear() {
    currentAddress = "";
    currentChain = -1;
    notifyListeners();
  }

  Future<void> init() async {
    if (isEnabled) {
      currentChain = await ethereum!.getChainId();
      final accs = await ethereum!.getAccounts();
      if (accs.isNotEmpty) currentAddress = accs.first;
      ethereum!.onAccountsChanged((accounts) => clear());
      ethereum!.onChainChanged((chainId) => clear());
      notifyListeners();
    }
  }
}

class HorizCoinApp extends StatelessWidget {
  const HorizCoinApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'HorizCoin Marketplace',
      theme: ThemeData.dark().copyWith(
        primaryColor: Colors.tealAccent,
      ),
      home: const MarketplaceHomePage(),
    );
  }
}

class MarketplaceHomePage extends StatelessWidget {
  const MarketplaceHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<MetaMaskProvider>(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text('HorizCoin Data Marketplace'),
        actions: [
          if (!provider.isConnected)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: ElevatedButton(
                onPressed: provider.connect,
                child: const Text('Connect Wallet'),
              ),
            )
          else
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Center(
                child: Text(
                  provider.currentAddress.isNotEmpty
                      ? 'Wallet: ${provider.currentAddress.substring(0,6)}...${provider.currentAddress.substring(provider.currentAddress.length-4)}'
                      : 'Connected',
                  style: const TextStyle(fontSize: 14, color: Colors.tealAccent),
                ),
              ),
            ),
        ],
      ),
      body: provider.isConnected
          ? const Center(child: Text('Marketplace UI'))
          : const Center(child: Text('Connect your MetaMask wallet.')),
    );
  }
}
