HorizCoin - Private Dedicated Package

This archive is a private, dedicated starter package for HorizCoin.
Included: backend tool, ingestion template, Flutter UI scaffold, Kubernetes manifest, CI workflow.

See .env.example for environment variables. Replace placeholders before deploying.
