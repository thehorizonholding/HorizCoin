"""HorizCoin Marketplace Tool
--------------------------
Provides CrewAI agents with the ability to search and purchase data assets
from the HorizCoin Data Marketplace. Communicates via REST API.

Requires:
- MARKETPLACE_API_URL
- MARKETPLACE_API_KEY
"""

import os
import json
import requests
from crewai_tools import BaseTool

class MarketplaceTool(BaseTool):
    name: str = "HorizCoin Marketplace Tool"
    description: str = (
        "Interact with the HorizCoin data marketplace. "
        "Supports searching for datasets and purchasing datatokens."
    )

    def _run(self, command: str, **kwargs) -> str:
        """
        Executes commands against the live marketplace API.

        Commands:
          - 'search': requires 'query' parameter
          - 'purchase': requires 'dataset_id' and 'amount' parameters
        """
        base_url = os.getenv("MARKETPLACE_API_URL", "https://api.horizcoin.example.com")
        headers = {"Authorization": f"Bearer {os.getenv('MARKETPLACE_API_KEY', '')}"}

        try:
            if command == "search":
                query = kwargs.get("query")
                if not query:
                    return "Error: 'query' parameter is required for search."

                response = requests.get(f"{base_url}/datasets/search", params={"q": query}, headers=headers, timeout=10)
                if response.status_code == 429:
                    return "Error: Marketplace API rate limit reached. Please wait and retry later."
                response.raise_for_status()

                return f"Search results:\n{json.dumps(response.json(), indent=2)}"

            elif command == "purchase":
                dataset_id = kwargs.get("dataset_id")
                amount = kwargs.get("amount")
                if not dataset_id or not amount:
                    return "Error: 'dataset_id' and 'amount' are required for purchase."

                payload = {"dataset_id": dataset_id, "amount": amount}
                response = requests.post(f"{base_url}/datatokens/purchase", json=payload, headers=headers, timeout=15)
                if response.status_code == 429:
                    return "Error: Marketplace API rate limit reached. Please wait and retry later."
                response.raise_for_status()

                return f"Purchase confirmation:\n{json.dumps(response.json(), indent=2)}"

            else:
                return "Error: Unknown command. Use 'search' or 'purchase'."

        except requests.exceptions.RequestException as e:
            return f"Network error contacting marketplace: {e}"
        except Exception as e:
            return f"Unexpected error: {e}"
