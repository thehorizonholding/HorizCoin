# Policies & Human Approval Gates

The following checks are enforced conceptually by the project. You must implement
the operational equivalents (KMS, multi-sig, legal agreements) before monetization.

- Provider Contracts: must be present and stored off-chain with on-chain references.
- Audit Required: smart contracts must pass independent security audits.
- Treasury: multi-sig required for any transfer > threshold.
- Compliance: KYC/AML and data privacy confirmed.
- Manual Approval Token: any operation that triggers monetary flows must present
  a signed approval token from >= 2 human approvers.
