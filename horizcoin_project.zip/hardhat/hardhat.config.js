import("@nomicfoundation/hardhat-toolbox");
import("dotenv/config");
module.exports = { solidity: "0.8.20" };