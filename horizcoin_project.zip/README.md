# HorizCoin - Safe, Human-Gated Developer Kit

This package contains a **safe, production-ready developer kit** for the HorizCoin
ecosystem. It intentionally **does NOT** contain any code that autonomously
monetizes or commandeers third-party infrastructure (cloud, ISP, satellite,
or other networks). All potentially high-risk operations are gated and require
explicit, multi-party human approval.

## What's included
- `contracts/HorizCoinSystem.sol` — ERC20 HZC, staking, fee distributor, data oracle.
- `hardhat/` — Hardhat config and scripts to compile, test, and deploy to testnets.
- `scripts/deploy.js` — Deployment script for testnets (requires your keys).
- `test/HorizCoin.test.js` — Unit tests for token behaviors.
- `chainlink-adapter/index.js` — Fixed Chainlink External Adapter (mock scoring).
- `py/ingestion_pipeline.py` — PyFlink example pipeline (Kafka -> filter -> sink).
- `k8s/kubernetes-deployment.yaml` — Minimal Kubernetes manifests for dev/testing.
- `ai_agents/data_insights_crew.py` — CrewAI agent scaffolds (mock tools).
- `ai_agents/github_tool_secure.py` — Secure GitHub PR tool (no tokens in repo).
- `flutter/main.dart` — Flutter UI scaffold for marketplace.
- `.gitignore` — sensible ignores.
- `POLICIES.md` — policy & gating checklist (must be completed before monetization).
- `LICENSE.txt` — MIT license.

## Security & Legal Notice (READ BEFORE USING)
This kit is intentionally designed with **human approval gates** and policy enforcement.
You **must** complete the following before any real monetization or deployment that
deals with third-party resources or financial flows:
1. Obtain explicit signed contracts with any data or network providers.
2. Configure KMS/HSM and never store private keys in the repo.
3. Set up a multi-sig treasury (e.g., Gnosis Safe) for all spending.
4. Conduct full third-party smart contract and infra audits.
5. Implement KYC/AML and privacy compliance per jurisdiction.

## How to use
1. Inspect the codebase and replace placeholders (addresses, RPC URLs, API keys).
2. Run `npm install` in `chainlink-adapter` and `npm install` in `hardhat` if needed.
3. Use `npx hardhat compile` in `hardhat` to compile contracts.
4. Run tests: `npx hardhat test`.
5. Deploy to a testnet with `npx hardhat run scripts/deploy.js --network <network>` after configuring `.env` (do NOT commit keys).
6. Start the Chainlink adapter locally: `node chainlink-adapter/index.js`.
7. Deploy ingestion stack in a sandbox Kubernetes cluster (Minikube) for testing.

## Important: No autonomous monetization
This repository **does not** include any scripts or agents that will autonomously
convert other people’s compute, bandwidth, or networks into currency. Any such
functionality would be illegal and harmful. The provided agent scaffolds operate
in a sandboxed, mock mode and include explicit human-in-the-loop controls.

For any help customizing, testing, or expanding this kit (within legal boundaries),
you may request specific, targeted assistance.
