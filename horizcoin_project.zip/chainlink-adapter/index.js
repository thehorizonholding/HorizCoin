const express = require('express');
const bodyParser = require('body-parser');
const { Requester, Validator } = require('@chainlink/external-adapter');
const app = express(); app.use(bodyParser.json());
const customParams = { dataId: ['dataId'] };
const getDimensionalScore = async (dataId) => Math.floor(Math.random()*100);
const getMarketScore = async (dataId) => Math.floor(Math.random()*100);
const getIncomeScore = async (dataId) => Math.floor(Math.random()*100);
const createRequest = async (input, callback) => {
  const validator = new Validator(input, customParams);
  const jobRunID = validator.validated.id;
  const { dataId } = validator.validated.data;
  try {
    const [d,m,i] = await Promise.all([getDimensionalScore(dataId), getMarketScore(dataId), getIncomeScore(dataId)]);
    const finalScore = Math.round(d*0.4 + m*0.35 + i*0.25);
    callback(200, { jobRunID, data: { dataId, finalScore, result: finalScore }, statusCode: 200 });
  } catch (err) { callback(500, Requester.errored(jobRunID, err)); }
};
app.post('/', (req,res)=> createRequest(req.body, (code,data)=>res.status(code).json(data)));
app.listen(process.env.PORT||8080, ()=>console.log('Adapter listening'));
