const hre = require("hardhat");
async function main() {
  const [deployer] = await hre.ethers.getSigners();
  const HorizCoin = await hre.ethers.getContractFactory("HorizCoin");
  const horizCoin = await HorizCoin.deploy(deployer.address);
  await horizCoin.deployed();
  console.log("HorizCoin deployed:", horizCoin.address);
}
main().catch(e => { console.error(e); process.exit(1); });
