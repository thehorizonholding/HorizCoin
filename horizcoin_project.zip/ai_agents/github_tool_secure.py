import os, requests
from crewai_tools import BaseTool
class GitHubTool(BaseTool):
    name="GitHubTool"
    def _run(self, repo, title, head, base, body):
        token = os.getenv("GITHUB_PAT")
        if not token: return "No token"
        url = f"https://api.github.com/repos/{repo}/pulls"
        headers = {"Authorization": f"token {token}", "Accept": "application/vnd.github.v3+json"}
        payload = {"title":title,"head":head,"base":base,"body":body}
        resp = requests.post(url, json=payload, headers=headers, timeout=10)
        if resp.status_code>=400: return f"Error {resp.status_code}"
        return resp.json().get("html_url")
