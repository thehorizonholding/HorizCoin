import os
from crewai import Agent, Task, Crew, Process
from crewai_tools import BaseTool
os.environ["HORIZCOIN_API_KEY"] = os.getenv("HORIZCOIN_API_KEY","demo")
class MarketplaceTool(BaseTool):
    name="MarketplaceTool"
    def _run(self, command:str, **kwargs):
        if "search" in command: return {"dataset_id":"demo","score":85}
        if "purchase" in command: return {"status":"ok"}
        return {"error":"unknown"}
marketplace = MarketplaceTool()
data_scout = Agent(role="DataScout", goal="Find data", backstory="", verbose=True, allow_delegation=False, tools=[marketplace])
acquisition = Agent(role="Acq", goal="Buy data", backstory="", verbose=True, allow_delegation=False, tools=[marketplace])
analyst = Agent(role="Analyst", goal="Analyze", backstory="", verbose=True, allow_delegation=False)
task1 = Task("Search", "report", agent=data_scout)
task2 = Task("Purchase","receipt", agent=acquisition)
task3 = Task("Analyze","report", agent=analyst)
crew = Crew(agents=[data_scout,acquisition,analyst], tasks=[task1,task2,task3], process=Process.sequential, verbose=2)
if __name__=="__main__": print(crew.kickoff())
