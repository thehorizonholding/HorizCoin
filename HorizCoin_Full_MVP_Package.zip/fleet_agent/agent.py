#!/usr/bin/env python3
"""Simple Fleet Agent prototype — reports telemetry to Fleet Manager"""
import requests, time, uuid, platform, json
NODE_ID = 'node-' + str(uuid.uuid4())[:8]
FM_URL = 'http://localhost:3001'

def register():
    payload = {'nodeId': NODE_ID, 'pubKey': 'mvp-demo-key', 'capabilities': {'cpu': 4, 'gpus': 0, 'bandwidthMbps': 100}}
    r = requests.post(FM_URL + '/nodes/register', json=payload)
    print('register:', r.status_code, r.text)

def report():
    payload = {'cpuLoad': 0.12, 'memPct': 0.32, 'bandwidthMbps': 95, 'uptime': 3600}
    r = requests.post(FM_URL + f'/nodes/{NODE_ID}/telemetry', json=payload)
    print('telemetry:', r.status_code, r.text)

if __name__ == '__main__':
    register()
    while True:
        report()
        time.sleep(15)
