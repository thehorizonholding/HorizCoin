#!/usr/bin/env bash
echo "This deploy script is an example. Customize for your infra."
echo "Deploy backend:"
echo "  cd backend && npm install && npm start &"
echo "Run fleet agent prototype:"
echo "  python3 fleet_agent/agent.py"
echo "Contracts: compile with Hardhat/Foundry and deploy using your keys."
