# HorizCoin — MVP Full Package

This package contains a more complete MVP scaffold for HorizCoin including:
- More advanced solidity contracts (utility token with fee/flywheel, payment channel skeleton, epoch payout)
- Basic backend Fleet Manager (Node.js/Express)
- Fleet Agent prototype (Python)
- Simple frontend React app skeleton
- Basic tests and CI workflow
- Documentation and roadmap

**WARNING**: Contracts are *example code only*. Do NOT deploy to mainnet without audits and legal review.
