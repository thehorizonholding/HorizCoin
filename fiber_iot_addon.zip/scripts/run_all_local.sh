#!/usr/bin/env bash
set -euo pipefail
echo 'Starting local demo: metering collector + IoT simulator + edge agent (requires mosquitto or local MQTT broker)'
python3 fiber/metering_collector.py &
sleep 1
python3 iot/device_simulator.py &
python3 iot/edge_agent.py &
echo 'Local demo started (check logs). Use Ctrl+C to stop.'
