Fiber + IoT Add-on - Architecture Overview
-----------------------------------------
Goals:
- Add a fiber-capacity monetization layer to the Horizon platform (permissioned, auditable).
- Add an IoT ingestion & edge-processing subsystem to capture device telemetry and optionally sell processed data.
- Provide secure metering, signed receipts, and ledger integration for provider payouts and customer billing.
- Provide a token-credit design (optional) to represent bandwidth/edge compute credits in a compliant way.

High-level components:
- Fiber Marketplace Service: provider onboarding, offers, SLA, bandwidth-metering collector, billing
- Metering Agents: deployed at provider edges or gateways; sign telemetry with KMS-backed keys
- IoT Edge Agents: local device gateway that aggregates, pre-processes, and uploads data to the orchestrator
- Tokenization Layer (optional): off-chain ledger + on-chain token bridge to represent credits
- Connector Layer: cloud & device connectors to AWS/GCP/Azure + MQTT / CoAP device adapters
- Security & Compliance: KMS/HSM signing, Vault for secrets, audit logs, KYC hooks

Dataflow (simplified):
[Provider / Fiber Node] --(signed telemetry)--> Metering Collector --> Ledger --> Billing / Marketplace
[IoT Device] --(MQTT/CoAP)--> Edge Agent --> Preprocess --> Upload to Object Storage --> ETL/Analytics

See docs/implementation_steps.md for detailed rollout steps.
