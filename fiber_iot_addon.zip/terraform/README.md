Terraform placeholders for Fiber + IoT add-on
---------------------------------------------
These are example roots to help you provision IoT gateways, message endpoints, and VPC resources.
Replace variables and modules with your production modules and credentials. Use secret managers (Vault/AWS Secrets Manager) for secrets.
