Compliance Checklist (summary)
-----------------------------
- Signed provider contracts with audit rights
- Data privacy & residency compliance (GDPR, CCPA where required)
- KYC/AML for customers that buy bandwidth credits or tokens
- Third-party security audit & penetration testing
- Smart-contract audit (if you issue tokens)
- Clear Acceptable Use Policy and SLA with providers/customers
