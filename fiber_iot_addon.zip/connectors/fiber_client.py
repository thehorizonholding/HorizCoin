# fiber_client.py - sample client to call the Fiber Marketplace metering endpoint
import requests, os, json

FIBER_API = os.environ.get('FIBER_API','http://localhost:8090')
API_KEY = os.environ.get('FIBER_API_KEY','demo-key')

def submit_telemetry(telemetry):
    headers = {'Authorization': f'Bearer {API_KEY}'}
    r = requests.post(f'{FIBER_API}/telemetry', json=telemetry, headers=headers, timeout=10)
    return r.json()
