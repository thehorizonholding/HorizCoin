Connectors: cloud and device adapters (simulated)
------------------------------------------------
This folder contains lightweight connector stubs for:
  - AWS S3/GCS upload (simulated)
  - MQTT ingest adapter (edge agent posts to orchestrator)
  - Fiber metering API client (verifies signed receipts)
Replace stubs with real SDK code in production.
