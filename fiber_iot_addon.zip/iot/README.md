IoT Subsystem - Quickstart
--------------------------
This directory contains a simple device simulator and an edge agent scaffold.
The simulator creates MQTT messages and the edge agent demonstrates secure ingest.

Steps to run simulator locally (development):
1. Install Python 3.11+, create venv and pip install -r requirements.txt
2. Run the simulator: python device_simulator.py
3. Start the edge agent (simulator publishes to localhost broker): python edge_agent.py

NOTE: Use a managed MQTT broker (AWS IoT Core, Google Cloud IoT, or Mosquitto) for production.
