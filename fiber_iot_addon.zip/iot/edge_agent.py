# edge_agent.py - simple edge gateway scaffold that subscribes to MQTT and forwards to orchestrator
import paho.mqtt.client as mqtt, os, requests, json

BROKER = os.environ.get('MQTT_BROKER','localhost')
ORCH = os.environ.get('ORCHESTRATOR_URL','http://localhost:8080/ingest_iot')

def on_message(client, userdata, msg):
    try:
        payload = json.loads(msg.payload.decode())
        # lightweight preprocessing example
        payload['processed'] = True
        requests.post(ORCH, json=payload, timeout=5)
        print('forwarded to orchestrator', payload.get('device_id'))
    except Exception as e:
        print('error forwarding', e)

client = mqtt.Client()
client.on_message = on_message
client.connect(BROKER, 1883, 60)
client.subscribe('horizon/iot/device')
client.loop_forever()
