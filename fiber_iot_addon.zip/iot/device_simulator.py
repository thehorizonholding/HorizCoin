# device_simulator.py - simple IoT device workload generator (MQTT)
import time, json, uuid, random, os
import paho.mqtt.client as mqtt

BROKER = os.environ.get('MQTT_BROKER','localhost')
TOPIC = 'horizon/iot/device'

client = mqtt.Client()
client.connect(BROKER, 1883, 60)

device_id = f'device-{uuid.uuid4().hex[:8]}'

try:
    for i in range(100):
        payload = {
            'device_id': device_id,
            'ts': int(time.time()),
            'temp_c': 20 + random.random()*10,
            'latency_ms': random.random()*50,
            'seq': i
        }
        client.publish(TOPIC, json.dumps(payload))
        print('published', payload)
        time.sleep(1)
except KeyboardInterrupt:
    pass
