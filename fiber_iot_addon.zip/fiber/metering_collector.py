# metering_collector.py - minimal Flask stub for collecting signed telemetry (demo)
from flask import Flask, request, jsonify
import os, json, base64, hmac, hashlib

app = Flask(__name__)
# DEMO ONLY: HMAC secret is for simulation; replace with KMS/HSM verification in production
SECRET = os.environ.get('METER_SECRET','demo-secret')

def verify_hmac(payload, signature):
    mac = hmac.new(SECRET.encode(), payload.encode(), hashlib.sha256).hexdigest()
    return hmac.compare_digest(mac, signature)

@app.route('/telemetry', methods=['POST'])
def telemetry():
    data = request.get_json() or {}
    sig = data.pop('sig', None)
    payload = json.dumps(data, sort_keys=True)
    ok = verify_hmac(payload, sig or '')
    if not ok:
        return jsonify({'status':'rejected','reason':'bad signature'}), 400
    # In production: record to append-only storage and ledger
    return jsonify({'status':'accepted','bytes': data.get('bytes_transferred',0)})

@app.route('/health')
def health():
    return jsonify({'status':'ok'})

if __name__=='__main__':
    app.run(port=8090, host='0.0.0.0')
