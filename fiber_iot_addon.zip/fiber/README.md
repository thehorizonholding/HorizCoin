Fiber Marketplace & Metering - Overview
--------------------------------------
Purpose:
- Allow permissioned fiber providers to onboard, register offers (capacity/time/region), and submit signed telemetry.
- Allow customers to lease capacity and receive signed receipts proving delivery.
- Integrate with your ledger for payments and provider payouts.

Components included:
- Metering Collector API (placeholder)
- Provider onboarding flow (doc)
- Signed receipt format (JSON) and example
- Bandwidth-credit token design (conceptual)

Example signed telemetry (JSON):
{
   "provider_id": "prov-abc",
   "period_start": 1690000000,
   "period_end": 1690003600,
   "bytes_transferred": 123456789,
   "sig": "BASE64_SIGNATURE"
}

The collector must verify signatures (KMS/HSM) before crediting ledger entries.
