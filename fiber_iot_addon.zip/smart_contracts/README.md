Smart Contracts - Illustrative Examples
---------------------------------------
These are illustrative example contracts that show how a bandwidth-credit token could be implemented.
DO NOT DEPLOY THESE TO MAINNET WITHOUT AUDIT.
