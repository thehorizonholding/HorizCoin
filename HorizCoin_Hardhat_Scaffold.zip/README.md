# HorizCoin Hardhat Scaffold

Run `npm install` then `npx hardhat test` to execute the sample test.