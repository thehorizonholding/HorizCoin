# HorizCoin Development Package

Local-development configuration and source files.