# services/metering_agent/agent.py - simulated metering agent (dry-run)
import time, json, uuid, hmac, hashlib, os
from datetime import datetime

# In production use secure KMS keys to sign telemetry (this is simulation only)
SECRET = os.environ.get('METER_SECRET','demo-secret')

def sign_message(msg: bytes) -> str:
    return hmac.new(SECRET.encode(), msg, hashlib.sha256).hexdigest()

def generate_sample_telemetry(provider_id='prov-demo', bytes_used=1024*1024):
    ts = int(time.time())
    payload = {
        'provider_id': provider_id,
        'timestamp': ts,
        'bytes': bytes_used,
        'session_id': 'sess-' + uuid.uuid4().hex[:8]
    }
    signature = sign_message(json.dumps(payload).encode())
    payload['signature'] = signature
    return payload

if __name__ == '__main__':
    # emit 5 sample telemetry messages
    for i in range(5):
        p = generate_sample_telemetry(bytes_used=1024*(i+1))
        print(json.dumps(p))
        time.sleep(0.5)
