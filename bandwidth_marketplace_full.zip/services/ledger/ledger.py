# services/ledger/ledger.py - simple double-entry ledger (demo)
import json, uuid, time, os
LEDGER_FILE = os.environ.get('LEDGER_FILE','ledger.json')

def _load():
    if os.path.exists(LEDGER_FILE):
        return json.load(open(LEDGER_FILE))
    return {'accounts':{}, 'entries':[]}

def _save(d):
    json.dump(d, open(LEDGER_FILE,'w'), indent=2)

def create_account(account_id):
    d = _load()
    if account_id in d['accounts']:
        return False
    d['accounts'][account_id] = {'balance':0}
    _save(d)
    return True

def record_entry(debit_account, credit_account, amount, currency='USD', meta=None):
    d = _load()
    entry = {'id': 'e-'+uuid.uuid4().hex[:8], 'debit':debit_account, 'credit':credit_account, 'amount':amount, 'currency':currency, 'ts': int(time.time()), 'meta': meta or {}}
    d['entries'].append(entry)
    # update balances (naive)
    d['accounts'].setdefault(debit_account, {'balance':0})
    d['accounts'].setdefault(credit_account, {'balance':0})
    d['accounts'][debit_account]['balance'] -= amount
    d['accounts'][credit_account]['balance'] += amount
    _save(d)
    return entry

if __name__ == '__main__':
    create_account('market-revenue')
    create_account('provider-payout')
    print(record_entry('customer-abc','market-revenue', 10.0, meta={'note':'demo'}))
