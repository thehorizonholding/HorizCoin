# services/bandwidth_marketplace/app.py (Flask dry-run API)
from flask import Flask, request, jsonify
import uuid, time, json
from decimal import Decimal

app = Flask(__name__)

# In-memory stores for demo
OFFERS = {}
LEASES = {}
PROVIDERS = {}
LEDGER = {}

# Simple API key auth for demo
API_KEYS = {'admin-key':'admin'}

def require_api_key(fn):
    def wrapper(*args, **kwargs):
        key = request.headers.get('X-Api-Key') or request.args.get('api_key')
        if not key or key not in API_KEYS:
            return jsonify({'error':'unauthorized'}), 401
        return fn(*args, **kwargs)
    wrapper.__name__ = fn.__name__
    return wrapper

@app.route('/providers/register', methods=['POST'])
@require_api_key
def register_provider():
    body = request.get_json() or {}
    pid = 'prov-' + uuid.uuid4().hex[:8]
    PROVIDERS[pid] = {'id':pid, 'name': body.get('name'), 'contact': body.get('contact'), 'status':'registered', 'created_at': int(time.time())}
    return jsonify(PROVIDERS[pid]), 201

@app.route('/offers', methods=['POST'])
@require_api_key
def create_offer():
    body = request.get_json() or {}
    pid = body.get('provider_id')
    if pid not in PROVIDERS:
        return jsonify({'error':'provider not found'}), 400
    oid = 'offer-' + uuid.uuid4().hex[:8]
    offer = {
        'offer_id': oid,
        'provider_id': pid,
        'region': body.get('region'),
        'bandwidth_mbps': int(body.get('bandwidth_mbps', 0)),
        'price_per_gb_usd': str(body.get('price_per_gb_usd','0.10')),
        'available_gb': int(body.get('available_gb',0)),
        'status':'available',
        'created_at': int(time.time())
    }
    OFFERS[oid] = offer
    return jsonify(offer), 201

@app.route('/offers', methods=['GET'])
@require_api_key
def list_offers():
    return jsonify(list(OFFERS.values()))

@app.route('/lease', methods=['POST'])
@require_api_key
def lease_offer():
    body = request.get_json() or {}
    offer_id = body.get('offer_id')
    gb = int(body.get('gb',1))
    acct = body.get('billing_account','test-cust')
    offer = OFFERS.get(offer_id)
    if not offer or offer['available_gb'] < gb:
        return jsonify({'error':'not enough capacity'}), 400
    lid = 'lease-' + uuid.uuid4().hex[:8]
    lease = {'lease_id':lid, 'offer_id':offer_id, 'gb':gb, 'account':acct, 'status':'simulated', 'created_at':int(time.time())}
    LEASES[lid] = lease
    offer['available_gb'] -= gb
    amount = Decimal(offer['price_per_gb_usd']) * Decimal(gb)
    invoice = {'invoice_id': str(uuid.uuid4()), 'lease_id': lid, 'account': acct, 'amount_usd': str(amount), 'ts': int(time.time())}
    LEDGER.setdefault(acct, []).append(invoice)
    return jsonify({'lease':lease, 'invoice': invoice}), 201

@app.route('/billing/<account>', methods=['GET'])
@require_api_key
def billing(account):
    return jsonify(LEDGER.get(account, []))

@app.route('/health', methods=['GET'])
def health():
    return jsonify({'status':'ok','ts':int(time.time())})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8085)
