# Bandwidth Marketplace Add-on (Full Package) — Safe & Dry-Run

This add-on provides a legal, auditable scaffold to monetize bandwidth, edge compute, and data services
via a permissioned marketplace. It is explicitly **dry-run by default** and uses simulated metering agents.
Use only with networks and providers you have explicit permission to work with.

Contents:
- services/bandwidth_marketplace/ : API server (offers, leases, billing) - dry-run
- services/metering_agent/        : agent stub that simulates signed telemetry
- services/ledger/                : double-entry ledger and billing engine stub
- tokenization/                   : docs + token contract stub (off-chain redemption model)
- docs/                           : legal, onboarding, metering, audit guidance
- .github/workflows/ci.yml        : CI runs dry-run tests and policy scans

Important:
- Never commit real credentials or private keys to this repo.
- Replace simulated agents with real, audited metering only after contracts and legal sign-off.
- Tokenization is provided as a compliance-first pattern: tokens represent off-chain capacity and require fiat settlement and KYC.
