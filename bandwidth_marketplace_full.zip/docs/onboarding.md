# docs/onboarding.md - Provider & Customer Onboarding

Provider onboarding checklist:
- Contract signed (capacity, SLA, pricing, audit rights)
- Metering agent deployed and validated (signed telemetry)
- KYC and sanctions screening completed for provider entity
- Test traffic and attestation completed (third-party audit optional)

Customer onboarding:
- Billing account created with payment method
- KYC for enterprise customers (as required by service terms)
- Purchase agreement for credits or reservation
