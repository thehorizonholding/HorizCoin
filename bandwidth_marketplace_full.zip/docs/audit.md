# docs/audit.md - Auditing & Transparency

- Maintain append-only logs of telemetry and ledger entries (signed with KMS)
- Expose attestation API for customers to verify usage (signed receipts)
- Offer third-party audit access (read-only, time-limited) under contract
