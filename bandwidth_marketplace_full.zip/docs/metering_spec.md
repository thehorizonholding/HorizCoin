# docs/metering_spec.md - Metering & Attestation Spec (summary)

- Metering agents must produce signed telemetry: provider_id, timestamp, bytes, session_id, signature
- Telemetry signatures must be verifiable using KMS public keys (demo uses HMAC simulator)
- Central meter ingests signed telemetry, validates signature, aggregates per-billing-period
- Aggregated usage -> invoice generation (CSV/JSON receipts) -> ledger entries
- Allow dispute window and re-audit flow for customers/providers
