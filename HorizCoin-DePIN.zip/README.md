# HorizCoin-DePIN
Private scaffold. See files.