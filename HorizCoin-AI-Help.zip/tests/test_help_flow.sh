#!/usr/bin/env bash
set -e
# Ensure logs dir
mkdir -p logs
# generate an error
python3 logs_watcher.py --once
# run help center in dry run mode to handle new log
python3 help_center.py --interval 1 --dry-run
