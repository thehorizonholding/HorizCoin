#!/usr/bin/env python3
"""Auto repair executor for HorizCoin Help Center.
Only executes commands listed in solution_library.json to reduce risk.
"""
import json, subprocess, logging, os
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
LIB = 'solution_library.json'

def load_lib():
    if not os.path.exists(LIB):
        return {}
    with open(LIB,'r') as f:
        return json.load(f)

def list_repairs_allowed():
    lib = load_lib()
    return list(lib.keys())

def run_repair(issue_text, fix_key, dry_run=True):
    lib = load_lib()
    cmd = lib.get(fix_key)
    if not cmd:
        return {'ok': False, 'reason': 'fix_key_not_found'}
    if dry_run:
        return {'ok': True, 'cmd': cmd, 'dry_run': True}
    try:
        logging.info('Executing repair command: %s', cmd)
        res = subprocess.run(cmd, shell=True, check=True, capture_output=True, text=True)
        return {'ok': True, 'stdout': res.stdout, 'stderr': res.stderr}
    except subprocess.CalledProcessError as e:
        logging.error('Repair failed: %s', e)
        return {'ok': False, 'error': str(e), 'stdout': e.stdout, 'stderr': e.stderr}

if __name__ == '__main__':
    print('Available repairs:', list_repairs_allowed())
    print(run_repair('Oracle Connection Failed', 'Oracle Connection Failed', dry_run=True))
