#!/usr/bin/env python3
"""HorizCoin Help Center (AI-backed troubleshooting assistant)

Usage: python help_center.py
This script monitors logs (via logs_watcher or direct input), analyses issues, and suggests fixes.
By default it runs a mock "LLM" planner. For production, hook this to CrewAI/LangChain or your LLM of choice.
"""
import os
import time
import json
import logging
import argparse
from datetime import datetime
from auto_repair import run_repair, list_repairs_allowed

LOG_FILE = os.getenv('HC_LOG_FILE', 'logs/system.log')
AI_MOCK = os.getenv('HC_USE_MOCK_LLM', '1') == '1'

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s', filename='horiz_help.log')

def mock_llm_analyze(issue_text, context=''):
    """A small deterministic mock LLM for offline use. Returns a suggested fix key."""
    issue = issue_text.lower()
    if 'oracle' in issue or 'connection' in issue or 'rpc' in issue:
        return {'type': 'suggestion', 'fix_key': 'Oracle Connection Failed', 'explanation': 'Restart the oracle connector and verify RPC URL.'}
    if 'database' in issue or 'locked' in issue or 'sqlite' in issue:
        return {'type': 'suggestion', 'fix_key': 'Database Locked', 'explanation': 'Clear locks and restart DB service.'}
    if 'memory' in issue or 'oom' in issue:
        return {'type': 'suggestion', 'fix_key': 'Memory Overflow', 'explanation': 'Free caches and restart service.'}
    if 'disk' in issue or 'no space' in issue:
        return {'type': 'suggestion', 'fix_key': 'Disk Full', 'explanation': 'Clear temp files and rotate logs.'}
    # default fallback
    return {'type': 'suggestion', 'fix_key': None, 'explanation': 'No direct auto-fix found. Recommend operator review.'}

def analyze_issue(issue_text, context=''):
    if AI_MOCK:
        return mock_llm_analyze(issue_text, context)
    # TODO: integrate real LLM/CrewAI here (LangChain, CrewAPI, etc.)
    raise RuntimeError('No LLM provider configured. Set HC_USE_MOCK_LLM=0 and implement an LLM integration.')

def main_loop(poll_interval=10, autorepair=False, dry_run=True):
    last_pos = 0
    print('Starting HorizCoin Help Center (mock LLM). Autorepair:', autorepair, 'Dry run:', dry_run)
    while True:
        if not os.path.exists(LOG_FILE):
            time.sleep(poll_interval)
            continue
        with open(LOG_FILE, 'r') as f:
            f.seek(last_pos)
            new = f.read()
            last_pos = f.tell()
        if new:
            # simple line-based parse for errors
            lines = [l.strip() for l in new.splitlines() if l.strip()]
            for line in lines:
                if any(k in line.upper() for k in ['ERROR','CRITICAL','EXCEPTION','FAIL']):
                    print(f"[{datetime.utcnow().isoformat()}] Issue detected: {line}")
                    logging.error(f"Issue detected: {line}")
                    result = analyze_issue(line)
                    print('AI Analysis:', result)
                    logging.info(f"AI Analysis: {json.dumps(result)}")
                    fix_key = result.get('fix_key')
                    if fix_key:
                        if autorepair:
                            out = run_repair(line, fix_key, dry_run=dry_run)
                            print('Repair result:', out)
                            logging.info(f"Repair result: {out}")
                        else:
                            allowed = list_repairs_allowed()
                            print('Suggested fix:', fix_key)
                            print('Allowed auto repairs:', allowed)
                    else:
                        print('No auto-fix suggestion. Escalate to operator.')
        time.sleep(poll_interval)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--interval', type=int, default=10)
    parser.add_argument('--autorepair', action='store_true', help='Enable auto-repair for known issues')
    parser.add_argument('--dry-run', action='store_true', help='Show repairs but do not execute them')
    args = parser.parse_args()
    main_loop(poll_interval=args.interval, autorepair=args.autorepair, dry_run=args.dry_run)
