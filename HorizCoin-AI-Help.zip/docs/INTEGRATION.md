Integration Guide - HorizCoin AI Help & Troubleshooting

1. Place this folder inside your HorizCoin repo, e.g., /backend/ai_help
2. Configure environment variables (optional):
   - HC_LOG_FILE: path to application log file (default: logs/system.log)
   - HC_USE_MOCK_LLM: set to '0' to integrate a real LLM provider
3. Review solution_library.json and replace commands with safe equivalents for your environment.
4. Start the logs generator (for test):
   python3 logs_watcher.py &
5. Start the help center in dry-run mode first to review suggestions:
   python3 help_center.py --interval 10 --dry-run
6. Enable autorepair only after validating commands and security policies:
   python3 help_center.py --autorepair

Security notes:
- Auto-repair executes shell commands; ensure commands are safe and run under appropriate privileges.
- Integrate with Vault/KMS for any secrets needed by repair commands.
