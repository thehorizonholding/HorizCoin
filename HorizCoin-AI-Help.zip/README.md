HorizCoin AI Help & Troubleshooting System
=========================================

This package contains an AI-backed Help & Troubleshooting subsystem for the HorizCoin platform.
It is intended to run alongside the HorizCoin FullStack to provide automated diagnostics,
guided remediation suggestions, and optional safe auto-remediation.

Contents:
- help_center.py         # Core assistant: integrates LLM (mock) + diagnostics
- logs_watcher.py        # Watches logs and forwards issues to the assistant
- auto_repair.py         # Executes safe, preapproved repair commands
- solution_library.json  # Predefined mapping of symptoms -> repair commands
- requirements.txt       # Python dependencies (minimal, mock-friendly)
- systemd/horiz-help.service.sample  # Example systemd unit for running help_center
- tests/test_help_flow.sh # Simple smoke test to simulate an error and run assistant
- docs/INTEGRATION.md    # Integration instructions and safety notes

Security & Safety:
- This code uses a mock LLM by default. DO NOT put production keys in these files.
- Auto-repair only executes commands listed in solution_library.json.
- Review all commands and ensure they are safe for your environment before enabling auto-repair.
