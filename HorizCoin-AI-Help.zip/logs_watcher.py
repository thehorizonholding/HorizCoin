#!/usr/bin/env python3
"""A simple log generator/watcher that simulates and forwards logs to the help center.
In production, wire your application's logging into this (file, syslog, or a logging API).
"""
import time, random, os, argparse
LOG_FILE = os.getenv('HC_LOG_FILE', 'logs/system.log')
os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)

ERRORS = [
    'ERROR: Oracle Connection Failed: timeout',
    'CRITICAL: Database Locked on write',
    'ERROR: Memory OOM killed process pid=1234',
    'WARN: High model latency detected',
    'ERROR: Disk full on /var/lib/data'
]

def generate_once():
    with open(LOG_FILE,'a') as f:
        msg = random.choice(ERRORS)
        f.write(msg + '\n')
        print('Generated log:', msg)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--once', action='store_true')
    parser.add_argument('--interval', type=int, default=30)
    args = parser.parse_args()
    if args.once:
        generate_once()
    else:
        while True:
            generate_once()
            time.sleep(args.interval)
