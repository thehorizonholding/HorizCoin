# HorizCoin Production Package

Production configuration and manifests.