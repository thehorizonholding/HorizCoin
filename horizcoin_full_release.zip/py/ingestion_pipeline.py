# PyFlink ingestion example (safe, with sink placeholders)
from pyflink.datastream import StreamExecutionEnvironment
from pyflink.table import StreamTableEnvironment, DataTypes
from pyflink.table.descriptors import Schema, Kafka, Json, Print
from pyflink.table.udf import udf

@udf(result_type=DataTypes.BOOLEAN())
def is_valid_reading(latitude, longitude):
    return -90 <= latitude <= 90 and -180 <= longitude <= 180

def data_ingestion_pipeline():
    env = StreamExecutionEnvironment.get_execution_environment()
    t_env = StreamTableEnvironment.create(stream_execution_environment=env)

    t_env.connect(
        Kafka().version("universal").topic("raw_satellite_data")
        .property("bootstrap.servers","kafka:9092")
        .property("group.id","flink-consumer-group").start_from_latest()
    ).with_format(Json()).with_schema(
        Schema().field("timestamp",DataTypes.BIGINT())
                .field("satellite_id",DataTypes.STRING())
                .field("latitude",DataTypes.DOUBLE())
                .field("longitude",DataTypes.DOUBLE())
                .field("image_url",DataTypes.STRING())
    ).create_temporary_table("kafka_source")

    t_env.create_temporary_function("is_valid_reading", is_valid_reading)
    src = t_env.from_path("kafka_source")
    processed = src.filter("is_valid_reading(latitude, longitude)").select("timestamp, satellite_id, latitude, longitude, image_url")

    # For demo we use the print sink. Replace with BigQuery or IPFS with secure credentials and human approval:
    t_env.connect(Print()).with_schema(
        Schema().field("timestamp",DataTypes.BIGINT())
                .field("satellite_id",DataTypes.STRING())
                .field("latitude",DataTypes.DOUBLE())
                .field("longitude",DataTypes.DOUBLE())
                .field("image_url",DataTypes.STRING())
    ).create_temporary_table("console_sink")

    processed.execute_insert("console_sink").wait()

if __name__ == "__main__":
    data_ingestion_pipeline()
