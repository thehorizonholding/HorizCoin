const { expect } = require("chai");
const { ethers } = require("hardhat");
describe("HorizCoin basic tests", function () {
  it("deploys and assigns supply", async function () {
    const [owner] = await ethers.getSigners();
    const HorizCoin = await ethers.getContractFactory("HorizCoin");
    const token = await HorizCoin.deploy(owner.address);
    await token.deployed();
    const bal = await token.balanceOf(owner.address);
    const total = await token.totalSupply();
    expect(bal).to.equal(total);
  });
});
