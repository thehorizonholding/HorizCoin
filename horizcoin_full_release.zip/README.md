# HorizCoin - Safe Developer Kit (Expanded)

This release is a **safe, fully-documented developer kit** for building the HorizCoin ecosystem.
It intentionally excludes any functionality that would autonomously monetize or commandeer third-party
infrastructure. All monetization/payment operations are gated behind human approvals.

## What I completed in this package
* Smart contracts (single Solidity file `contracts/HorizCoinSystem.sol`) — ERC20 + staking + fee distribution + oracle.
* Hardhat config, deploy script, basic tests. (`hardhat/`, `scripts/deploy.js`, `test/`)
* Chainlink External Adapter (Node.js) with example integrations placeholder (`chainlink-adapter/`).
* PyFlink ingestion pipeline with sample BigQuery/HTTP sink placeholders (`py/ingestion_pipeline.py`).
* Kubernetes manifests with PV placeholder and notes for production (`k8s/`).
* CrewAI agent scaffolds with secure GitHub PR tool and Web3/Ethers.js stubs requiring manual keys (`ai_agents/`).
* Flutter frontend scaffold (`flutter/main.dart`) with a working UI demo.
* Dockerfiles for Chainlink adapter and a simple GitHub Actions CI workflow that runs tests and lints.
* `.env.example`, `POLICIES.md`, and `SECURITY_GUIDE.md`.

## Important Safety & Legal Notes
* This project **does not** contain code to convert third-party networks, bandwidth, or devices into currency.
* Before any real-world monetization:
  - Implement legal contracts with providers.
  - Configure KMS/HSM for keys.
  - Use multisig (Gnosis Safe) for treasury.
  - Conduct security audits and legal review (KYC/AML).
* The AI agent modules are mock/sandboxed and require explicit human approval for any on-chain actions.

## How to use
1. Inspect and customize `.env.example` into `.env` (locally) — never commit secrets.
2. Install dependencies for Node and Hardhat and the Chainlink adapter:
   - `cd chainlink-adapter && npm install`
   - `cd hardhat && npm install`
3. Compile and test contracts:
   - `npx hardhat compile`
   - `npx hardhat test`
4. Run Chainlink adapter locally for testing:
   - `node chainlink-adapter/index.js`
5. Deploy PyFlink jobs and Kubernetes manifests in a sandbox (Minikube) only for testing.

## Structure
See repository folders for details.

If you want, I can now:
- Add production-ready Cloud deployment docs for a specific cloud (GCP/AWS/AliCloud) with cost estimates.
- Expand tests, add E2E flows, or add CI deployment to a testnet upon your request.
