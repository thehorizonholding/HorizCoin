# Policies & Human Approval Gates

This file lists mandatory operational controls you must implement before moving to production.

- Provider Contracts: Signed and notarized agreements kept off-chain.
- Key Management: Use a KMS/HSM. Never store private keys in code or Git.
- Treasury Controls: Use Gnosis Safe or equivalent multisig; at least 3-of-5 signers.
- Audits: Third-party smart contract and infra audits required.
- Compliance: Implement KYC/AML processes and data privacy controls (GDPR, etc).
- Manual Approval Token: Any contract calls that move funds must include a human-signed approval token.
- Bug Bounty: Run a public bug bounty program (Immunefi, HackerOne).
