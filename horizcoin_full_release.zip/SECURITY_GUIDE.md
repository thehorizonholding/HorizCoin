# Security Guide - High level

1. Run Slither/Solhint and other static analyzers in CI.
2. Configure monitoring for on-chain anomalies.
3. Rate-limit agent spending and require multi-sig for >= threshold.
4. Separate duties: different keys for deploy, ops, and treasury.
