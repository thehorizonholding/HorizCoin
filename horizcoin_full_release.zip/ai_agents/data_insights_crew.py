# CrewAI scaffold with Web3 stubs and explicit human approval gating
import os
from crewai import Agent, Task, Crew, Process
from crewai_tools import BaseTool

# Load keys securely from environment; do NOT hardcode
ETHEREUM_RPC = os.getenv("ETHEREUM_RPC")
# Agent wallet must be a multisig or be limited by a governance-controlled wallet.
AGENT_WALLET = os.getenv("AGENT_WALLET")  # required for on-chain actions

class MarketplaceTool(BaseTool):
    name = "MarketplaceTool"
    description = "Mock tool that simulates marketplace searches; on-chain purchases require human approval."

    def _run(self, command: str, **kwargs):
        if "search" in command:
            return {"dataset_id": "climate_data_q4", "score": 85}
        if "purchase" in command:
            # Never auto-spend: return a signed proposal object that requires human approval.
            return {"proposal": {"action": "purchase", "dataset_id": kwargs.get("dataset_id")}, "requires_approval": True}
        return {"error": "unknown"}

marketplace_tool = MarketplaceTool()

data_scout = Agent(role="Data Scout", goal="Find high-value datasets", backstory="", verbose=True, allow_delegation=False, tools=[marketplace_tool])
acquisition = Agent(role="Acquisition", goal="Create purchase proposals (requires approval)", backstory="", verbose=True, allow_delegation=False, tools=[marketplace_tool])
analyst = Agent(role="Analyst", goal="Analyze datasets offline", backstory="", verbose=True, allow_delegation=False)

tasks = [
    Task(description="Search for climate datasets with DDVO > 80", expected_output="List of candidates", agent=data_scout),
    Task(description="Create purchase proposal for top dataset", expected_output="Proposal object requiring human approval", agent=acquisition),
    Task(description="Analyze dataset offline and produce a report", expected_output="Analysis report", agent=analyst),
]

crew = Crew(agents=[data_scout, acquisition, analyst], tasks=tasks, process=Process.sequential, verbose=2)

if __name__ == '__main__':
    result = crew.kickoff()
    print("Crew result:", result)
