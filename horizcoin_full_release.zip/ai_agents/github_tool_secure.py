import os, requests
from crewai_tools import BaseTool

class GitHubTool(BaseTool):
    name = "GitHubTool"
    def _run(self, repo, title, head, base, body):
        token = os.getenv("GITHUB_PAT")
        if not token:
            return "Error: no token"
        url = f"https://api.github.com/repos/{repo}/pulls"
        headers = {"Authorization": f"token {token}"}
        data = {"title": title, "head": head, "base": base, "body": body}
        r = requests.post(url, json=data, headers=headers, timeout=10)
        if r.status_code >= 400:
            return f"Error {r.status_code}: {r.text}"
        return r.json().get("html_url")
