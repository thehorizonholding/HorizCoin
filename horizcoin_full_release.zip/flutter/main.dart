// main.dart - Complete Flutter application for the HorizCoin Marketplace
import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';

void main() {
  runApp(const HorizCoinApp());
}

class HorizCoinApp extends StatelessWidget {
  const HorizCoinApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'HorizCoin Data Marketplace',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        primaryColor: Colors.blueAccent,
        scaffoldBackgroundColor: const Color(0xFF121212),
      ),
      home: const MarketplaceHomePage(),
    );
  }
}

class MarketplaceHomePage extends StatelessWidget {
  const MarketplaceHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('HorizCoin Marketplace'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Refreshing marketplace data...')),
              );
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Data Value Trends',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            const SizedBox(height: 200, child: DataValueChart()),
            const SizedBox(height: 30),
            const Text(
              'Available Datasets',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            DatasetList(),
          ],
        ),
      ),
    );
  }
}

class DatasetList extends StatelessWidget {
  final List<Map<String, dynamic>> datasets = const [
    {
      'name': 'Climate Data Q4',
      'score': 85,
      'price': 120.5,
      'currency': 'HZC',
    },
    {
      'name': 'Urban Heat Index 2025',
      'score': 90,
      'price': 145.0,
      'currency': 'HZC',
    },
    {
      'name': 'Rainfall Prediction Dataset',
      'score': 78,
      'price': 99.9,
      'currency': 'HZC',
    },
  ];

  DatasetList({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: datasets.map((dataset) {
        return Card(
          color: const Color(0xFF1E1E1E),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          margin: const EdgeInsets.symmetric(vertical: 8),
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: Colors.blueAccent,
              child: Text(
                dataset['score'].toString(),
                style: const TextStyle(color: Colors.white),
              ),
            ),
            title: Text(dataset['name']),
            subtitle: Text('Value Score: ${dataset['score']}'),
            trailing: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blueAccent,
              ),
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Purchased ${dataset['name']} for ${dataset['price']} ${dataset['currency']}'),
                  ),
                );
              },
              child: Text('Buy (${dataset['price']} ${dataset['currency']})'),
            ),
          ),
        );
      }).toList(),
    );
  }
}

class DataValueChart extends StatelessWidget {
  const DataValueChart({super.key});

  @override
  Widget build(BuildContext context) {
    return LineChart(
      LineChartData(
        gridData: FlGridData(show: false),
        titlesData: FlTitlesData(show: false),
        borderData: FlBorderData(show: false),
        minX: 0,
        maxX: 6,
        minY: 0,
        maxY: 100,
        lineBarsData: [
          LineChartBarData(
            spots: const [
              FlSpot(0, 45),
              FlSpot(1, 55),
              FlSpot(2, 62),
              FlSpot(3, 70),
              FlSpot(4, 75),
              FlSpot(5, 90),
              FlSpot(6, 85),
            ],
            isCurved: true,
            color: Colors.blueAccent,
            barWidth: 4,
            isStrokeCapRound: true,
            dotData: FlDotData(show: false),
            belowBarData: BarAreaData(
              show: true,
              gradient: LinearGradient(
                colors: [
                  Colors.blueAccent.withOpacity(0.3),
                  Colors.cyanAccent.withOpacity(0.2),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
