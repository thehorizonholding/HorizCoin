const hre = require("hardhat");

async function main() {
  const [deployer] = await hre.ethers.getSigners();
  console.log("Deploying with:", deployer.address);

  const initialSupply = hre.ethers.parseEther("100000000"); // 100M HORIZ

  const Token = await hre.ethers.getContractFactory("HorizCoinToken");
  const token = await Token.deploy(initialSupply);
  await token.waitForDeployment();
  console.log("HorizCoinToken deployed to:", await token.getAddress());

  const Vault = await hre.ethers.getContractFactory("RewardVault");
  const vault = await Vault.deploy(await token.getAddress());
  await vault.waitForDeployment();
  console.log("RewardVault deployed to:", await vault.getAddress());
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
