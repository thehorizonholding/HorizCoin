# HorizCoin – Minimal Production-Ready Stack (AI + Blockchain + IoT + Control Center)

This is a **self-contained, offline-capable starter implementation** of the HorizCoin architecture
suitable for running entirely on a single machine (e.g. MacBook Pro Max).

It includes:

- `backend/` – FastAPI REST backend with:
  - device registration + data ingestion (IoT / SIM-style events)
  - a fake AI valuation pipeline (can be swapped to a real model later)
  - reward calculation + persistence in SQLite
- `blockchain/` – Hardhat-based EVM project with:
  - `HorizCoinToken.sol` – ERC-20 token
  - `RewardVault.sol` – contract that can be funded and used to record off-chain rewards
- `control-center/` – React + Vite dashboard to:
  - view devices
  - view ingested events
  - manually trigger "valuation + reward" flows for testing
- `docker-compose.yml` – One-command dev orchestration (API + frontend).

This is a **minimal but coherent v1**; it does *not* attempt to include every speculative feature
(e.g. full mobile app, SIM-level hooks, Chainlink Functions, global DePIN network), but it is
complete and runnable as-is, and is designed to be extended.

## Quickstart

Requirements:

- Docker + Docker Compose, **or**
- Python 3.10+ and Node 18+ if you want to run things manually.

### 1. Using Docker (recommended)

```bash
cd horizcoin_full_project

# build and start backend + control center
docker compose up --build
```

- Backend: http://localhost:8000/docs
- Control Center UI: http://localhost:5173

### 2. Run services manually (no Docker)

Backend:

```bash
cd backend
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

Frontend:

```bash
cd control-center
npm install
npm run dev -- --host 0.0.0.0 --port 5173
```

Blockchain (local Hardhat node):

```bash
cd blockchain
npm install
npx hardhat node
# In a new terminal:
npx hardhat run scripts/deploy.js --network localhost
```

Then set the deployed contract addresses in `backend/app/config.py` if you want on-chain
interactions later.

---

This project is intentionally straightforward so you can *own it entirely* on your MacBook
without depending on external registrations (no Chainlink, no cloud accounts, etc.).
