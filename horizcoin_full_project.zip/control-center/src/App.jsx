import React, { useEffect, useState } from "react";
import axios from "axios";

const api = axios.create({
  baseURL: "/api",
});

function App() {
  const [devices, setDevices] = useState([]);
  const [events, setEvents] = useState([]);
  const [summary, setSummary] = useState(null);
  const [newDevice, setNewDevice] = useState({ name: "", owner_wallet: "", description: "" });
  const [selectedDevice, setSelectedDevice] = useState(null);
  const [eventKind, setEventKind] = useState("iot");
  const [eventPayload, setEventPayload] = useState('{"temperature": 22, "battery": 90, "signal_strength": 3}');

  async function refreshAll() {
    const [d, e, s] = await Promise.all([
      api.get("/devices/"),
      api.get("/events/"),
      api.get("/rewards/summary"),
    ]);
    setDevices(d.data);
    setEvents(e.data);
    setSummary(s.data);
  }

  useEffect(() => {
    refreshAll().catch(console.error);
  }, []);

  async function createDevice(e) {
    e.preventDefault();
    await api.post("/devices/", newDevice);
    setNewDevice({ name: "", owner_wallet: "", description: "" });
    await refreshAll();
  }

  async function sendEvent(e) {
    e.preventDefault();
    if (!selectedDevice) return;
    let payload;
    try {
      payload = JSON.parse(eventPayload);
    } catch {
      alert("Payload must be valid JSON");
      return;
    }
    await api.post(`/events/${selectedDevice}`, {
      kind: eventKind,
      payload,
    });
    await refreshAll();
  }

  return (
    <div style={{ fontFamily: "system-ui, sans-serif", padding: "1.5rem", maxWidth: 1200, margin: "0 auto" }}>
      <h1>HorizCoin Control Center (Standalone)</h1>
      <p style={{ color: "#555" }}>
        Local-only testbed. Backend at <code>http://localhost:8000</code>. No external services.
      </p>

      <section style={{ marginTop: "1.5rem", display: "grid", gridTemplateColumns: "1.2fr 1fr", gap: "1.5rem" }}>
        <div>
          <h2>Devices</h2>
          <form onSubmit={createDevice} style={{ marginBottom: "1rem", display: "grid", gap: "0.4rem" }}>
            <input
              required
              placeholder="Device name"
              value={newDevice.name}
              onChange={(e) => setNewDevice({ ...newDevice, name: e.target.value })}
            />
            <input
              required
              placeholder="Owner wallet (0x...)"
              value={newDevice.owner_wallet}
              onChange={(e) => setNewDevice({ ...newDevice, owner_wallet: e.target.value })}
            />
            <input
              placeholder="Description"
              value={newDevice.description}
              onChange={(e) => setNewDevice({ ...newDevice, description: e.target.value })}
            />
            <button type="submit">Add Device</button>
          </form>

          <ul style={{ listStyle: "none", padding: 0, margin: 0 }}>
            {devices.map((d) => (
              <li
                key={d.id}
                onClick={() => setSelectedDevice(d.id)}
                style={{
                  padding: "0.5rem 0.75rem",
                  marginBottom: "0.25rem",
                  borderRadius: 6,
                  border: "1px solid #ddd",
                  background: d.id === selectedDevice ? "#eef6ff" : "#fafafa",
                  cursor: "pointer",
                }}
              >
                <strong>#{d.id} {d.name}</strong>
                <div style={{ fontSize: 12, color: "#555" }}>
                  Wallet: {d.owner_wallet}<br />
                  {d.description}
                </div>
              </li>
            ))}
            {devices.length === 0 && <li style={{ color: "#777" }}>No devices yet.</li>}
          </ul>
        </div>

        <div>
          <h2>Send Synthetic Event</h2>
          <form onSubmit={sendEvent} style={{ display: "grid", gap: "0.4rem" }}>
            <label>
              Target Device:
              <select
                value={selectedDevice || ""}
                onChange={(e) => setSelectedDevice(Number(e.target.value) || null)}
              >
                <option value="">-- choose --</option>
                {devices.map((d) => (
                  <option key={d.id} value={d.id}>
                    #{d.id} {d.name}
                  </option>
                ))}
              </select>
            </label>

            <label>
              Event kind:
              <select value={eventKind} onChange={(e) => setEventKind(e.target.value)}>
                <option value="iot">iot</option>
                <option value="sim">sim</option>
                <option value="power">power</option>
              </select>
            </label>

            <label>
              Payload JSON:
              <textarea
                rows={6}
                value={eventPayload}
                onChange={(e) => setEventPayload(e.target.value)}
                style={{ fontFamily: "monospace", fontSize: 13 }}
              />
            </label>

            <button type="submit" disabled={!selectedDevice}>
              Ingest & Value Event
            </button>
          </form>

          <div style={{ marginTop: "1rem", padding: "0.75rem", borderRadius: 6, border: "1px solid #ddd" }}>
            <h3>Reward Summary</h3>
            {summary ? (
              <ul style={{ paddingLeft: "1.2rem" }}>
                <li>Total events: {summary.total_events}</li>
                <li>Total valuation: {summary.total_valuation.toFixed(4)} (USD-equivalent units)</li>
                <li>Total rewards: {summary.total_rewards.toFixed(4)} HORIZ (logical units)</li>
              </ul>
            ) : (
              <p>Loading...</p>
            )}
          </div>
        </div>
      </section>

      <section style={{ marginTop: "2rem" }}>
        <h2>Recent Events</h2>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
          <thead>
            <tr>
              <th style={{ textAlign: "left", borderBottom: "1px solid #ddd" }}>ID</th>
              <th style={{ textAlign: "left", borderBottom: "1px solid #ddd" }}>Device</th>
              <th style={{ textAlign: "left", borderBottom: "1px solid #ddd" }}>Kind</th>
              <th style={{ textAlign: "left", borderBottom: "1px solid #ddd" }}>Payload</th>
              <th style={{ textAlign: "right", borderBottom: "1px solid #ddd" }}>Valuation</th>
              <th style={{ textAlign: "right", borderBottom: "1px solid #ddd" }}>Reward (HORIZ)</th>
              <th style={{ textAlign: "left", borderBottom: "1px solid #ddd" }}>Created</th>
            </tr>
          </thead>
          <tbody>
            {events.map((ev) => (
              <tr key={ev.id}>
                <td style={{ borderBottom: "1px solid #eee" }}>{ev.id}</td>
                <td style={{ borderBottom: "1px solid #eee" }}>{ev.device_id}</td>
                <td style={{ borderBottom: "1px solid #eee" }}>{ev.kind}</td>
                <td style={{ borderBottom: "1px solid #eee", fontFamily: "monospace" }}>
                  {typeof ev.payload === "string" ? ev.payload : JSON.stringify(ev.payload)}
                </td>
                <td style={{ borderBottom: "1px solid #eee", textAlign: "right" }}>
                  {ev.valuation?.toFixed(4)}
                </td>
                <td style={{ borderBottom: "1px solid #eee", textAlign: "right" }}>
                  {ev.reward_horiz?.toFixed(4)}
                </td>
                <td style={{ borderBottom: "1px solid #eee" }}>
                  {new Date(ev.created_at).toLocaleString()}
                </td>
              </tr>
            ))}
            {events.length === 0 && (
              <tr>
                <td colSpan="7" style={{ textAlign: "center", padding: "0.75rem", color: "#777" }}>
                  No events yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </section>
    </div>
  );
}

export default App;
