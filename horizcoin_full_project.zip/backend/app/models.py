from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from datetime import datetime
from .db import Base

class Device(Base):
    __tablename__ = "devices"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True)
    owner_wallet = Column(String, index=True)
    description = Column(String, nullable=True)

    events = relationship("DeviceEvent", back_populates="device")

class DeviceEvent(Base):
    __tablename__ = "device_events"
    id = Column(Integer, primary_key=True, index=True)
    device_id = Column(Integer, ForeignKey("devices.id"))
    kind = Column(String, index=True)  # e.g. "iot", "sim", "power"
    payload = Column(String)  # raw JSON as string
    valuation = Column(Float, nullable=True)
    reward_horiz = Column(Float, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    device = relationship("Device", back_populates="events")
