from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from .. import models, schemas, ai
from ..db import get_db

router = APIRouter(prefix="/events", tags=["events"])

@router.post("/{device_id}", response_model=schemas.DeviceEventOut)
def ingest_event(
    device_id: int,
    body: schemas.DeviceEventCreate,
    db: Session = Depends(get_db),
):
    device = db.query(models.Device).filter(models.Device.id == device_id).first()
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")

    valuation = ai.value_event(body.kind, body.payload)
    reward = valuation  # 1:1 mapping for now, can parameterize token price etc.

    ev = models.DeviceEvent(
        device_id=device_id,
        kind=body.kind,
        payload=str(body.payload),
        valuation=valuation,
        reward_horiz=reward,
    )
    db.add(ev)
    db.commit()
    db.refresh(ev)
    return ev

@router.get("/", response_model=List[schemas.DeviceEventOut])
def list_events(db: Session = Depends(get_db)):
    return db.query(models.DeviceEvent).order_by(models.DeviceEvent.id.desc()).all()
