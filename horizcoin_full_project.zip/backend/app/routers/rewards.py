from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from .. import models, schemas
from ..db import get_db

router = APIRouter(prefix="/rewards", tags=["rewards"])

@router.get("/summary", response_model=schemas.RewardSummary)
def get_reward_summary(db: Session = Depends(get_db)):
    q = db.query(models.DeviceEvent)
    total_events = q.count()
    total_valuation = sum(ev.valuation or 0 for ev in q)
    total_rewards = sum(ev.reward_horiz or 0 for ev in q)
    return schemas.RewardSummary(
        total_events=total_events,
        total_valuation=total_valuation,
        total_rewards=total_rewards,
    )
