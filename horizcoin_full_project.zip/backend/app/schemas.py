from pydantic import BaseModel, Field
from typing import Optional, Any, List
from datetime import datetime

class DeviceCreate(BaseModel):
    name: str
    owner_wallet: str
    description: Optional[str] = None

class DeviceOut(BaseModel):
    id: int
    name: str
    owner_wallet: str
    description: Optional[str]

    class Config:
        from_attributes = True

class DeviceEventCreate(BaseModel):
    kind: str = Field(examples=["iot", "sim", "power"])
    payload: Any

class DeviceEventOut(BaseModel):
    id: int
    device_id: int
    kind: str
    payload: Any
    valuation: Optional[float]
    reward_horiz: Optional[float]
    created_at: datetime

    class Config:
        from_attributes = True

class RewardRequest(BaseModel):
    device_event_id: int

class RewardSummary(BaseModel):
    total_events: int
    total_valuation: float
    total_rewards: float
