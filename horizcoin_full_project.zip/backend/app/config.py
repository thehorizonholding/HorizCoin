from pydantic import BaseModel
from functools import lru_cache
import os

class Settings(BaseModel):
    app_name: str = "HorizCoin Backend"
    environment: str = os.getenv("ENVIRONMENT", "local")
    database_url: str = os.getenv("DATABASE_URL", "sqlite:///./horizcoin.db")
    # Placeholder addresses – can be updated after you deploy your token/contracts
    horiz_token_address: str = os.getenv("HORIZ_TOKEN_ADDRESS", "0x0000000000000000000000000000000000000000")
    reward_vault_address: str = os.getenv("REWARD_VAULT_ADDRESS", "0x0000000000000000000000000000000000000000")

@lru_cache
def get_settings() -> Settings:
    return Settings()
