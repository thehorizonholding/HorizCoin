"""Very simple, fully local 'AI' valuation stub.

In production you would replace this with:
- a real ML model loaded from disk
- or a call to a cloud / on-prem LLM
- or an RL-optimized policy.

For now we:
- Inspect the event kind
- Look at numeric signals in the payload
- Produce a pseudo-value in USD-equivalent units.
"""

from typing import Any, Dict

def _safe_number(x, default=1.0) -> float:
    try:
        return float(x)
    except Exception:
        return float(default)

def value_event(kind: str, payload: Any) -> float:
    """Return a deterministic pseudo-valuation for a given event."

    if not isinstance(payload, dict):
        # Non-structured payload, assign a base value
        base = 0.01
        return base

    kind = (kind or "").lower()

    # Example heuristics
    if kind == "iot":
        # Assume fields: temperature, battery, signal_strength
        temp = _safe_number(payload.get("temperature", 22))
        battery = _safe_number(payload.get("battery", 80))
        signal = _safe_number(payload.get("signal_strength", 3))
        score = (100 - abs(temp - 22)) * 0.01 + battery * 0.001 + signal * 0.05
        return max(score, 0.01)

    if kind == "sim":
        # Assume fields: bytes_used, duration_sec
        bytes_used = _safe_number(payload.get("bytes_used", 1_000_000))  # 1MB
        duration = _safe_number(payload.get("duration_sec", 60))
        score = (bytes_used / 1_000_000) * 0.02 + (duration / 60) * 0.01
        return max(score, 0.005)

    if kind == "power":
        # Assume fields: watt_hours, carbon_intensity
        wh = _safe_number(payload.get("watt_hours", 10))
        carbon = _safe_number(payload.get("carbon_intensity", 300))
        # reward cleaner usage / generation higher
        cleanliness = max(0, 500 - carbon) / 500
        score = wh * 0.001 * (1 + cleanliness)
        return max(score, 0.001)

    # Fallback
    return 0.01
