from fastapi import FastAPI
from .db import Base, engine
from .routers import health, devices, events, rewards

Base.metadata.create_all(bind=engine)

app = FastAPI(title="HorizCoin Backend (Standalone)")

app.include_router(health.router)
app.include_router(devices.router)
app.include_router(events.router)
app.include_router(rewards.router)
