import threading, time, uuid, requests, os
from financial_system.ledger import SessionLocal, set_order_status, record_tx

FIAT_GATEWAY = os.getenv('FIAT_GATEWAY', 'http://localhost:5005')

class SettlementWorker(threading.Thread):
    def __init__(self, interval=5):
        super().__init__(daemon=True)
        self.interval = interval
        self.running = True

    def run(self):
        while self.running:
            try:
                self.process_pending()
            except Exception as e:
                print('Settlement worker error', e)
            time.sleep(self.interval)

    def process_pending(self):
        db = SessionLocal()
        rows = db.execute("SELECT id FROM orders WHERE status='created'").fetchall()
        for r in rows:
            order_id = r[0]
            try:
                resp = requests.post(f"{FIAT_GATEWAY}/create_order", json={'amount': 1, 'currency': 'USD'}, timeout=5)
                if resp.ok:
                    tx_id = str(uuid.uuid4())
                    record_tx(db, tx_id, order_id, 'fiat_settlement', 1, 'USD')
                    set_order_status(db, order_id, 'settled')
                    print(f"Order {order_id} settled (mock)")
            except Exception as e:
                print('Settlement call failed', e)
        db.close()

    def stop(self):
        self.running = False
