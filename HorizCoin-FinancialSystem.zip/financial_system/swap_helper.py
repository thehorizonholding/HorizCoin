"""Swap helper for building swap transactions via a DEX aggregator (1inch style).
This helper only builds/simulates transaction payloads. Actual signing and submission must be done by wallets.
"""
import os
import httpx

ONEINCH_API = os.getenv('ONEINCH_API', 'https://api.1inch.io/v5.0/1')

async def quote_swap(from_token: str, to_token: str, amount_wei: int):
    url = f"{ONEINCH_API}/quote"
    params = {'fromTokenAddress': from_token, 'toTokenAddress': to_token, 'amount': str(amount_wei)}
    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(url, params=params)
        r.raise_for_status()
        return r.json()

async def build_swap(from_token: str, to_token: str, amount_wei: int, from_address: str, slippage: int = 1):
    url = f"{ONEINCH_API}/swap"
    params = {
        'fromTokenAddress': from_token,
        'toTokenAddress': to_token,
        'amount': str(amount_wei),
        'fromAddress': from_address,
        'slippage': slippage
    }
    async with httpx.AsyncClient(timeout=15) as client:
        r = await client.get(url, params=params)
        r.raise_for_status()
        return r.json()
