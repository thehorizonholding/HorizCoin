from fastapi import FastAPI, HTTPException, BackgroundTasks
from pydantic import BaseModel
import uuid
from financial_system.ledger import init_db, SessionLocal, create_order, set_order_status, record_tx
from financial_system.ai_pricer import compute_price

init_db()
app = FastAPI(title='HorizCoin Financial Router')

class OrderCreate(BaseModel):
    asset: str
    amount: float
    metadata: dict = {}

@app.post('/orders/create')
def create_order_endpoint(payload: OrderCreate, background_tasks: BackgroundTasks):
    db = SessionLocal()
    oid = str(uuid.uuid4())
    o = create_order(db, oid, payload.asset, payload.amount, payload.metadata)
    db.close()
    background_tasks.add_task(set_order_status, SessionLocal(), oid, 'processing')
    return {'ok': True, 'order_id': oid}

@app.get('/orders/{order_id}')
def get_order(order_id: str):
    db = SessionLocal()
    o = db.execute("SELECT id, asset, amount, status FROM orders WHERE id=:id", {'id': order_id}).fetchone()
    db.close()
    if not o:
        raise HTTPException(status_code=404, detail='Order not found')
    return {'id': o[0], 'asset': o[1], 'amount': o[2], 'status': o[3]}

class QuoteRequest(BaseModel):
    asset: str
    amount: float

@app.post('/quotes')
def get_quote(q: QuoteRequest):
    order = {'asset': q.asset, 'amount': q.amount}
    price = compute_price(order)
    return {'ok': True, 'price': price}

class SwapRequest(BaseModel):
    from_token: str
    to_token: str
    amount_wei: int
    from_address: str

@app.post('/swap/build')
async def build_swap(req: SwapRequest):
    from financial_system.swap_helper import build_swap
    try:
        res = await build_swap(req.from_token, req.to_token, req.amount_wei, req.from_address)
        return {'ok': True, 'tx': res}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post('/settle/{order_id}')
def settle_order(order_id: str):
    db = SessionLocal()
    o = set_order_status(db, order_id, 'settling')
    if not o:
        db.close()
        raise HTTPException(status_code=404, detail='Order not found')
    tx_id = str(uuid.uuid4())
    record_tx(db, tx_id, order_id, 'manual_settle', o.amount, 'HZC')
    set_order_status(db, order_id, 'settled')
    db.close()
    return {'ok': True, 'order_id': order_id, 'status': 'settled'}
