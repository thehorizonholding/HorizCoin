from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime
import os

DB_URL = os.getenv('FIN_DB_URL', 'sqlite:///./financial_ledger.db')
engine = create_engine(DB_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine)
Base = declarative_base()

class Order(Base):
    __tablename__ = 'orders'
    id = Column(String, primary_key=True, index=True)
    asset = Column(String, index=True)
    amount = Column(Float)
    status = Column(String, index=True)
    metadata = Column(JSON)
    created_at = Column(DateTime, default=datetime.utcnow)

class Transaction(Base):
    __tablename__ = 'transactions'
    id = Column(String, primary_key=True, index=True)
    order_id = Column(String, index=True)
    tx_type = Column(String)
    amount = Column(Float)
    currency = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)


def init_db():
    Base.metadata.create_all(bind=engine)


def create_order(db, order_id, asset, amount, metadata=None):
    o = Order(id=order_id, asset=asset, amount=amount, status='created', metadata=metadata or {})
    db.add(o)
    db.commit()
    db.refresh(o)
    return o


def set_order_status(db, order_id, status):
    o = db.query(Order).filter(Order.id == order_id).first()
    if o:
        o.status = status
        db.commit()
    return o


def record_tx(db, tx_id, order_id, tx_type, amount, currency):
    t = Transaction(id=tx_id, order_id=order_id, tx_type=tx_type, amount=amount, currency=currency)
    db.add(t)
    db.commit()
    db.refresh(t)
    return t
