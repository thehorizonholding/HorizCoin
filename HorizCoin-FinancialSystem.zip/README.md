HorizCoin Advanced Financial System (Demo)

This package is a demo prototype of an advanced financial stack for HorizCoin integrating:
- FastAPI-based transaction router and API
- AI-driven pricing/pricing-acceleration stub (pluggable; can call local or cloud models)
- Swap helper integration (DEX aggregator helper)
- Mock fiat gateway adapter (demo)
- Accounting ledger (SQLite) and settlement worker
- Background job processing and basic reconciliation endpoints

Important: This is a **demo and research** artifact. It uses mock gateways and is NOT production-ready.
Do NOT use it with production private keys, real fiat providers, or live mainnet funds without audit and compliance.

Quick start (local):
1. Create a Python virtualenv and install dependencies:
   python3 -m venv venv && source venv/bin/activate
   pip install -r requirements.txt
2. Start the mock fiat gateway (optional):
   python -m financial_system.mock_fiat_gateway
3. Start the FastAPI app:
   uvicorn financial_system.api:app --reload --port 8000
4. Use the API (see endpoints below) to create orders, request AI price quotes, route swaps, and settle.

Endpoints (examples):
- POST /orders/create  -> create a new order (fiat or HZC)
- GET  /orders/{id}    -> fetch order status
- POST /quotes         -> get AI-accelerated price quote
- POST /swap/build     -> build swap transaction (via 1inch API helper)
- POST /settle/{id}    -> trigger settlement (fiat mock or mark settled)
