const hre = require('hardhat');

async function main() {
  const [deployer] = await hre.ethers.getSigners();
  console.log('Deploying contracts with account:', deployer.address);

  const DataToken = await hre.ethers.getContractFactory('HorizCoinDataToken');
  const dataToken = await DataToken.deploy('ipfs://{id}.json');
  await dataToken.deployed();
  console.log('HorizCoinDataToken deployed to:', dataToken.address);

  const PoB = await hre.ethers.getContractFactory('PoBVerifier');
  const pob = await PoB.deploy();
  await pob.deployed();
  console.log('PoBVerifier deployed to:', pob.address);

  const linkToken = process.env.LINK_TOKEN_ADDRESS;
  const oracle = process.env.CHAINLINK_ORACLE_ADDRESS;
  const jobId = process.env.CHAINLINK_JOB_ID;

  if (!linkToken || !oracle || !jobId) {
    console.log('Skipping DataValuationOracle deployment: missing env LINK_TOKEN_ADDRESS | CHAINLINK_ORACLE_ADDRESS | CHAINLINK_JOB_ID');
    return;
  }

  const DataVal = await hre.ethers.getContractFactory('DataValuationOracle');
  const dataVal = await DataVal.deploy(linkToken, oracle, jobId);
  await dataVal.deployed();
  console.log('DataValuationOracle deployed to:', dataVal.address);
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
