import json, os
try:
    import ipfshttpclient
except Exception:
    ipfshttpclient = None

def upload_to_ipfs(filepath: str, api_address: str = '/dns/localhost/tcp/5001/http'):
    if not os.path.exists(filepath):
        raise FileNotFoundError(filepath)

    if ipfshttpclient is None:
        print('ipfshttpclient not installed or not available — running simulated upload')
        data_cid = 'QmSimDataCID123'
        metadata_cid = 'QmSimMetadataCID456'
        return f'ipfs://{metadata_cid}'

    client = ipfshttpclient.connect(api_address)
    res = client.add(filepath)
    data_cid = res['Hash']

    filename = os.path.basename(filepath)
    file_size = os.path.getsize(filepath)
    metadata = {
        'name': f'HorizCoin Data Asset: {filename}',
        'description': 'A tokenized dataset for the HorizCoin ecosystem.',
        'image': f'ipfs://{data_cid}',
        'data_cid': data_cid,
        'attributes': [
            {'trait_type': 'File Type', 'value': filename.split('.')[-1]},
            {'trait_type': 'Size (bytes)', 'value': file_size}
        ]
    }

    metadata_json = json.dumps(metadata)
    metadata_res = client.add_str(metadata_json)
    metadata_cid = metadata_res

    metadata_uri = f'ipfs://{metadata_cid}'
    print(f'Data CID: {data_cid} -- Metadata URI: {metadata_uri}')
    return metadata_uri

if __name__ == '__main__':
    test_file = 'sample_dataset.csv'
    with open(test_file, 'w') as f:
        f.write('timestamp,sensor_id,value\n')
        f.write('1672531200,A,10.5\n')
        f.write('1672531201,B,98.2\n')
    print(upload_to_ipfs(test_file))
