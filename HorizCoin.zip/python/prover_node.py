from eth_account import Account
from eth_account.messages import encode_defunct
import time, hashlib

def solidity_keccak(types, values):
    packed = ''.join([f"{t}:{v}|" for t, v in zip(types, values)])
    return hashlib.sha3_256(packed.encode()).hexdigest()

private_key = '0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80'
acct = Account.from_key(private_key)

def sign_measurement(bandwidth_bps: int, timestamp: int) -> str:
    message_hash = solidity_keccak(['uint256', 'uint256'], [bandwidth_bps, timestamp])
    message = encode_defunct(text=message_hash)
    signed = acct.sign_message(message)
    return signed.signature.hex()

if __name__ == '__main__':
    bw = 500 * 10**6
    ts = int(time.time())
    sig = sign_measurement(bw, ts)
    print('Address:', acct.address)
    print('Bandwidth:', bw)
    print('Timestamp:', ts)
    print('Signature:', sig)
