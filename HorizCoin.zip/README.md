# HorizCoin

HorizCoin is an advanced blockchain and AI-driven platform designed to transform data, connectivity, and computation into a global, tokenized economy.
It allows data from Internet networks DePIN, IoT devices, and fiber-optic systems to be securely valued, exchanged, and monetized — turning digital infrastructure into a new form of currency.

## Quickstart
1. Install dependencies: `npm ci`, `forge install`, `pip install -r python/requirements.txt` (if used).
2. Start a local node: `npx hardhat node`.
3. Deploy locally: `npx hardhat run scripts/deploy.js --network localhost`.
4. Run tests: `npx hardhat test` and `forge test`.

## Security warnings
- Do not deploy to mainnet before a full security audit.
- Keep private keys and secrets out of the repository.
