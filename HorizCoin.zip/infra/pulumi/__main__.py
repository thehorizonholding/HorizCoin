import pulumi
import pulumi_aws as aws

config = pulumi.Config()
instance_type = config.get('instance_type') or 't3.large'
ami_id = config.get('ami_id') or 'ami-0c55b159cbfafe1f0'

sec_group = aws.ec2.SecurityGroup('horizcoin-node-sg',
    description='HorizCoin node security group',
    ingress=[
        aws.ec2.SecurityGroupIngressArgs(
            protocol='tcp',
            from_port=22,
            to_port=22,
            cidr_blocks=['10.0.0.0/16']
        ),
        aws.ec2.SecurityGroupIngressArgs(
            protocol='tcp',
            from_port=30303,
            to_port=30303,
            cidr_blocks=['0.0.0.0/0']
        ),
        aws.ec2.SecurityGroupIngressArgs(
            protocol='tcp',
            from_port=8545,
            to_port=8545,
            cidr_blocks=['10.0.0.0/16']
        )
    ],
    egress=[
        aws.ec2.SecurityGroupEgressArgs(
            from_port=0,
            to_port=0,
            protocol='-1',
            cidr_blocks=['0.0.0.0/0']
        )
    ]
)

user_data = """#!/bin/bash
apt-get update -y
apt-get install -y git curl build-essential
cd /opt
if [ ! -d /opt/HorizCoin ]; then
  git clone https://github.com/thehorizonholding/HorizCoin.git /opt/HorizCoin
fi
cd /opt/HorizCoin
if [ -f package.json ]; then
  npm ci
fi
"""

node_instance = aws.ec2.Instance('horizcoin-validator-node',
    instance_type=instance_type,
    ami=ami_id,
    vpc_security_group_ids=[sec_group.id],
    user_data=user_data,
    tags={ 'Name': 'HorizCoin-Validator', 'Project': 'HorizCoin' }
)

pulumi.export('public_ip', node_instance.public_ip)
pulumi.export('public_dns', node_instance.public_dns)
