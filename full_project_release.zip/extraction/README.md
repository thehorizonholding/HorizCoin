Cloud & Satellite extraction orchestrator (dry-run). See controller/orchestrator.py in full add-on.
