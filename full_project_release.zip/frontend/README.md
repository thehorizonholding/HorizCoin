Flutter frontend scaffold placeholder.
