CI notes: run dry-run tests and policy scans; do not enable execute.
