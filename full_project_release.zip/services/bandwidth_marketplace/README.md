Bandwidth marketplace (dry-run). API stubs included.
