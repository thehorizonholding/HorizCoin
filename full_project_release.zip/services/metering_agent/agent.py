import time, json
for i in range(2): print(json.dumps({'sample':i})); time.sleep(0.2)
