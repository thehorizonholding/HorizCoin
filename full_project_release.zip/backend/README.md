Backend FastAPI scaffold placeholder. Implement modules per docs.
