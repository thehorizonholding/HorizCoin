Legal & Compliance: obtain contracts, KYC, AML, respect ToS.
