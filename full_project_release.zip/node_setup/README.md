HorizCoin node setup scaffold. Legal node operations only. No mining booster.
