Tokenization examples for off-chain credits. Contracts illustrative only.
