AI Controller scaffold (chat-like). See ai_controller/app.py
