# Privacy & Single-User Deployment Checklist

Before you deploy, confirm each item:

- [ ] Legal: Confirm mining & data monetization are allowed by your cloud provider and jurisdiction.
- [ ] Secrets: All keys stored in KMS/Vault; no secrets in repo.
- [ ] Network: VPC/subnets private; no public IPs on instances unless via bastion.
- [ ] Access: Only you can access via VPN + bastion host. Disable password auth; use key-based SSH.
- [ ] Kubernetes: Ingress disabled; set NetworkPolicy to deny external ingress.
- [ ] Smart Contracts: Admin set to your address; disable public minting and governance UIs.
- [ ] Monitoring: Metrics accessible only inside VPN or private network.
- [ ] Backups: Secure offsite backups of critical keys and DB (encrypted).
- [ ] Audit: Code and security audits completed before holding real funds.
