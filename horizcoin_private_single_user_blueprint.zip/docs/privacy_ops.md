# Privacy Operations — How to operate the private deployment

Access:
- Use a dedicated admin workstation.
- Connect to cloud resources via VPN or jump host (bastion). Do not expose SSH to the Internet.

Secrets:
- Use cloud KMS (AWS KMS, GCP KMS, Oracle Vault) or HashiCorp Vault.
- Limit IAM roles: the deployment role should have least privilege to create the needed resources only.

Deployment:
- Use Terraform with remote state stored in a private backend (S3 + KMS, GCS + KMS).
- Apply Terraform from a secure CI runner or your admin workstation.
- For Kubernetes, set replicaCount=1 and disable automatic horizontal autoscaling unless you're monitoring costs.

Smart contracts:
- Deploy to a testnet first.
- Keep admin keys offline in a hardware wallet, use a Gnosis Safe if you want multi-sig later.

Disaster recovery:
- Keep an encrypted copy of your deployment keys and DB backups offsite.
- Test restores regularly.
