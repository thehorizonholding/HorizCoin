# HorizCoin — Private Single-User Deployment Blueprint

This package contains a privacy-first, single-user adaptation of the multi-cloud mining & data-market blueprint.
It is designed for *one operator only* (you). The templates minimize public exposure, disable public governance features, and harden networking defaults.

IMPORTANT:
- I WILL NOT assist with illegal activities. This blueprint is intended for lawful, compliant use only.
- You MUST review cloud provider Terms of Service before deploying (many providers restrict mining).
- Replace placeholders with your own values and store all secrets in a secure secret manager (KMS, Vault, etc.).

What changed for privacy / single-user:
- No public ingress / no external API endpoints by default.
- Kubernetes: replicas = 1, Ingress disabled, NetworkPolicy denies external ingress.
- Smart contracts: admin roles default to your wallet address; public minting / DAO interactions removed or disabled.
- Chainlink adapters / external adapters: set to localhost or removed by default.
- Terraform: example VPC configuration places resources in private subnets only.
- Monitoring: optional; ensure monitoring endpoints are inside private network or via VPN.

Files included:
- k8s/networkpolicy-deny-ingress.yaml
- helm/private-values.yaml (replicas=1, ingress disabled)
- smartcontracts/README_PRIVACY.md (instructions to set admin to your address)
- terraform/private-vpc-example.tf
- docs/privacy_checklist.md

Follow the checklist in docs/privacy_checklist.md before deploying.
