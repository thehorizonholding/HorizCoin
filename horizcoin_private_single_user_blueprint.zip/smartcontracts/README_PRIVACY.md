# Smart Contracts — Single-Admin Privacy Guidance

Before deploying smart contracts, apply these privacy-related modifications:

1. Set DEFAULT_ADMIN_ROLE to your address:
   - In deployment scripts, pass your wallet address (deployer) as the admin.
   - Ensure the constructor grants the DEFAULT_ADMIN_ROLE, PAUSER_ROLE, and MINTER_ROLE only to your address.

2. Remove or disable public minting:
   - If you want no further minting after initial supply, ensure mint() is protected and not callable by others.
   - Consider removing MINTER_ROLE after setup by revoking it.

3. Disable DAO / Governance pathways:
   - If there's any DAO or multisig integration, keep it disabled until you want to enable it.
   - Do not expose timelock or admin endpoints to public UIs.

4. Chainlink / External Adapters:
   - Configure Chainlink adapters to point to a private endpoint or remove them.
   - Avoid running public job specifications accepting arbitrary external requests.

5. Key Management:
   - Store private keys in an HSM, cloud KMS, or hardware wallet.
   - Avoid storing keys in plain text files or environment variables in code repos.

Example Hardhat deployment snippet:
```
const HZC_ADMIN = process.env.HZC_ADMIN_ADDRESS; // set to your address in CI secrets
await horizCoin.deploy(HZC_ADMIN);
```

Security reminder: single-admin reduces decentralization, increasing centralization risk. Use secure custody (HSM) and backups.
