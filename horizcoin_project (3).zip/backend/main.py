from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import hashlib, time, json

app = FastAPI(title="HorizCoin Oracle - Ingestion & Attestation")

class Contribution(BaseModel):
    device_id: str
    timestamp: int
    summary: dict
    signature: str = None  # optional device signature for attestation

# In-memory store (replace with DB in prod)
STORE = []

@app.post("/ingest")
async def ingest(c: Contribution):
    # Basic validation & fraud checks (placeholder)
    if not c.device_id or not c.summary:
        raise HTTPException(status_code=400, detail="invalid payload")
    # Compute a simple attestation hash (production: use TEE / SGX / KMS)
    payload = json.dumps({"device": c.device_id, "ts": c.timestamp, "s": c.summary}, sort_keys=True)
    attestation = hashlib.sha256(payload.encode()).hexdigest()
    record = {"id": len(STORE), "attestation": attestation, "payload": c.dict()}
    STORE.append(record)
    return {"status": "accepted", "attestation": attestation, "record_id": record["id"]}

@app.get("/attestation/{record_id}")
async def get_attestation(record_id: int):
    if record_id < 0 or record_id >= len(STORE):
        raise HTTPException(404, "not found")
    return STORE[record_id]

# Example valuation endpoint (for Chainlink Functions to call)
@app.post("/valuation")
async def valuation(request: dict):
    # request should contain record_id and simple pricing params
    recid = request.get("record_id")
    if recid is None:
        raise HTTPException(400, "missing record_id")
    if recid < 0 or recid >= len(STORE):
        raise HTTPException(404, "record not found")
    # Simple valuation: base + contributions
    base = 100  # base cents
    summary = STORE[recid]["payload"]["summary"]
    score = 0
    # Heuristic: more bandwidth and uptime = more value
    score += int(summary.get("wifi_rx", 0) / (1024*1024))
    score += int(summary.get("psim_rx", 0) / (1024*1024))
    value_cents = base + score
    return {"record_id": recid, "valuation_cents": value_cents}
