# Backend - FastAPI (Oracle / Ingestion / C2D Simulation)

This folder contains a minimal FastAPI server that:
- Accepts ingested contribution packets from mobile clients
- Runs a simulated verification pipeline
- Exposes an endpoint for Chainlink Functions or an off-chain oracle to query valuations

Run locally:
1. python -m venv .venv
2. source .venv/bin/activate
3. pip install -r requirements.txt
4. uvicorn main:app --reload --port 8000
