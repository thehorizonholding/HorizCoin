# HorizCoin - Project Skeleton (Production-ready templates)

This repository is a complete, production-oriented skeleton for the HorizCoin project:
- Smart contracts (Solidity, ERC-20 + DataNFT + Datatoken patterns)
- Backend API (FastAPI) with C2D/Oracle stubs
- Chainlink Functions example
- Android / iOS client README placeholders and guidance
- Dev tooling (Hardhat + Foundry example)
- Docker compose for local testing

**Important**: This skeleton provides secure templates and working deployment scripts but DOES NOT include private keys, real cloud credentials, or API secrets. You must add secrets via environment variables / secret manager before production use.

## Structure
- contracts/           Solidity smart contract templates
- backend/             FastAPI oracle / ingestion / c2d sim
- chainlink/           Chainlink Functions sample (source.js)
- android/             Android client README & notes (Kotlin implementation required)
- ios/                 iOS client README & notes (Swift implementation required)
- infra/               Hardhat + Foundry samples, docker-compose
- docs/                Design docs and deployment checklist
