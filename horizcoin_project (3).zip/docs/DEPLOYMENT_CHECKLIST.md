# Deployment Checklist (Production)

1. Finalize smart contract code and run unit tests (Foundry / Hardhat)
2. Prepare audit package; schedule audit with top-tier firm
3. Secure cloud accounts (GCP/AWS/Azure) and set up proxies for Chainlink Functions if using SigV4
4. Provision TEE / enclave nodes if using remote attestation
5. Set up secrets management (HashiCorp Vault / AWS Secrets Manager)
6. Prepare mobile app store submissions and permission justification videos (Android)
7. Prepare DAO governance and treasury multisigs
8. Run testnet deployment and integration tests
9. Perform bug bounty post-audit and harden infra
