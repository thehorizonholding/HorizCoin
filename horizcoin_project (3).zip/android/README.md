# Android Client - Notes & Integration Guide

This directory is a placeholder. For production:
- Implement Kotlin app with:
  - Foreground service for contribution batching
  - Usage of NetworkStatsManager (PACKAGE_USAGE_STATS) with user onboarding flow
  - If call logs needed: implement Default Dialer flow (user must accept)
  - Secure signing of contribution summaries (use device keystore or TEE)
- Endpoints:
  - POST /ingest  -> send summaries and receive attestation
- Use HTTPS, certificate pinning, and device attestation where possible.
