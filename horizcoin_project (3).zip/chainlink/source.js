// Chainlink Functions example source.js
// This is executed by the Chainlink Functions DON.
// It calls the HorizCoin valuation API and returns encoded uint256.

const recordId = args[0]; // first argument

if (!recordId) {
  throw Error("recordId required");
}

const res = await Functions.makeHttpRequest({
  url: "https://YOUR_ORACLE_HOST/valuation",
  method: "POST",
  headers: {"Content-Type":"application/json"},
  data: { record_id: recordId }
});

if (!res || !res.data || res.data.valuation_cents === undefined) {
  throw Error("invalid response");
}

return Functions.encodeUint256(res.data.valuation_cents);
