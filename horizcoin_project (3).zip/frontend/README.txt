frontend placeholder — replace with actual project files.
