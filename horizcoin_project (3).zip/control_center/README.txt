control_center placeholder — replace with actual project files.
