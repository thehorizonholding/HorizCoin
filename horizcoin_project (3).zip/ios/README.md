# iOS Client - Notes & Integration Guide

Because iOS has strict sandboxing:
- Implement sensor and VPN-based contributions only.
- Use NetworkExtension for legal bandwidth routing (requires entitlements).
- Use CoreMotion & CoreLocation for mobility contributions.
- Sign payloads with local Secure Enclave keys.
