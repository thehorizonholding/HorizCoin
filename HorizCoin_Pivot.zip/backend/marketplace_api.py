import os, json
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from web3 import Web3
from dotenv import load_dotenv

load_dotenv()
RPC_URL = os.getenv('RPC_URL', 'http://127.0.0.1:8545')
MARKETPLACE_ADDR = os.getenv('MARKETPLACE_ADDR')
ARTIFACT = os.path.join(os.path.dirname(__file__), 'marketplace_artifact.json')
PK = os.getenv('PRIVATE_KEY')

app = FastAPI()
w3 = Web3(Web3.HTTPProvider(RPC_URL))

class Listing(BaseModel):
    metadata_uri: str
    supply: int
    price_wei: int

def load_contract():
    if not MARKETPLACE_ADDR:
        raise RuntimeError('Set MARKETPLACE_ADDR in env')
    with open(ARTIFACT,'r') as f:
        iface = json.load(f)
    return w3.eth.contract(address=MARKETPLACE_ADDR, abi=iface['abi'])

@app.post('/list')
async def list_data(listing: Listing):
    contract = load_contract()
    acct = w3.eth.account.from_key(PK)
    tx = contract.functions.mintDataToken(acct.address, listing.supply, listing.metadata_uri, listing.price_wei).build_transaction({
        'from': acct.address,
        'nonce': w3.eth.get_transaction_count(acct.address),
        'gas': 3000000,
        'gasPrice': w3.eth.gas_price
    })
    signed = w3.eth.account.sign_transaction(tx, PK)
    txh = w3.eth.send_raw_transaction(signed.rawTransaction)
    receipt = w3.eth.wait_for_transaction_receipt(txh)
    return {'tx_hash': txh.hex(), 'receipt': dict(receipt)}

if __name__ == '__main__':
    import uvicorn
    uvicorn.run(app, host='0.0.0.0', port=8009)
