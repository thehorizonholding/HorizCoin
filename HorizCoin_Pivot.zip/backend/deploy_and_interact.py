import os, json
from web3 import Web3
from solcx import compile_source, install_solc
from dotenv import load_dotenv

load_dotenv()
RPC_URL = os.getenv('RPC_URL', 'http://127.0.0.1:8545')
PRIVATE_KEY = os.getenv('PRIVATE_KEY')
CONTRACT_SOURCE = os.path.join(os.path.dirname(__file__), '..', 'contracts', 'DataMarketplace.sol')
ARTIFACT = os.path.join(os.path.dirname(__file__), 'marketplace_artifact.json')
DEPLOYED = os.path.join(os.path.dirname(__file__), 'marketplace_address.txt')

def compile_contract():
    print('Installing solc...')
    install_solc('0.8.19')
    with open(CONTRACT_SOURCE, 'r') as f:
        src = f.read()
    compiled = compile_source(src, output_values=['abi','bin'])
    _, contract_interface = compiled.popitem()
    with open(ARTIFACT, 'w') as fh:
        json.dump(contract_interface, fh)
    print('Compiled. ABI saved to', ARTIFACT)
    return contract_interface

def deploy():
    w3 = Web3(Web3.HTTPProvider(RPC_URL))
    acct = w3.eth.account.from_key(PRIVATE_KEY)
    iface = compile_contract()
    Contract = w3.eth.contract(abi=iface['abi'], bytecode=iface['bin'])
    tx = Contract.constructor().build_transaction({
        'from': acct.address,
        'nonce': w3.eth.get_transaction_count(acct.address),
        'gas': 5000000,
        'gasPrice': w3.eth.gas_price
    })
    signed = w3.eth.account.sign_transaction(tx, private_key=PRIVATE_KEY)
    txh = w3.eth.send_raw_transaction(signed.rawTransaction)
    print('Deploy tx sent:', txh.hex())
    receipt = w3.eth.wait_for_transaction_receipt(txh)
    address = receipt.contractAddress
    with open(DEPLOYED, 'w') as f:
        f.write(address)
    print('Deployed at', address)
    return address

if __name__ == '__main__':
    if not PRIVATE_KEY:
        raise SystemExit('Set PRIVATE_KEY in .env')
    deploy()
