# HorizCoin Pivot - Privacy-Preserving Data Marketplace (C2D)

This repository is a privacy-first pivot of the HorizCoin concept.
It implements a legal, ethical, and practical marketplace for Compute-to-Data (C2D)
and datatokens (ERC-1155-like access tokens). It explicitly does NOT implement
any global surveillance or bulk data collection features.

## Contents
- contracts/
  - DataMarketplace.sol  (ERC-1155 marketplace + C2D events)
  - DataRegistry.sol     (simple on-chain record registry)
- backend/
  - marketplace_api.py   (FastAPI interface to mint/list/subscribe datatokens)
  - c2d_executor.py      (simulated enclave that runs algorithms locally - no data exfil)
  - deploy_and_interact.py (compile/deploy helper using web3.py + solcx)
- .env.example
- requirements.txt
- LICENSE (MIT)

## Quickstart (macOS)
1. Install dependencies:
   - Python 3.9+
   - `pip install -r requirements.txt`
   - `npm install -g hardhat` (optional for local EVM)
2. Fill `.env` from `.env.example`
3. Start local node (optional):
   - `npx hardhat node`
4. Deploy & interact (example):
   - `python backend/deploy_and_interact.py`
5. Start APIs:
   - `python backend/marketplace_api.py`
   - `python backend/c2d_executor.py`

## Important Ethics & Legal Note
This code intentionally avoids any capability to capture private network traffic, perform bulk scraping, or bypass user consent. Use only in compliance with local laws and with explicit consent of data owners/providers.
