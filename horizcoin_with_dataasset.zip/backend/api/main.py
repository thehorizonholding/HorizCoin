from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List

app = FastAPI(
    title="HorizCoin Marketplace API",
    description="Live API for the HorizCoin Data Marketplace, providing dataset information and transaction endpoints.",
    version="1.0.0",
)

# --- Pydantic Models ---
class Dataset(BaseModel):
    id: str
    name: str
    description: str
    price_hzc: float
    source: str
    ddvo_score: int


class PurchaseRequest(BaseModel):
    buyer_wallet: str
    amount: int


# --- Mock Database (in production, connects to PostgreSQL) ---
mock_db_datasets: List[Dataset] = [
    Dataset(
        id="satellite001",
        name="Landsat-8 Imagery",
        description="High-resolution satellite images for environmental analysis.",
        price_hzc=120.5,
        source="NASA",
        ddvo_score=95,
    ),
    Dataset(
        id="weather002",
        name="Global Weather Patterns 2025",
        description="Historical and forecast weather data for global analytics.",
        price_hzc=80.75,
        source="NOAA",
        ddvo_score=89,
    ),
    Dataset(
        id="finance003",
        name="Financial Market Signals",
        description="Real-time and historical trading data aggregated from multiple exchanges.",
        price_hzc=300.0,
        source="Bloomberg",
        ddvo_score=92,
    ),
]


@app.get("/")
def read_root():
    return {"status": "HorizCoin Marketplace API is online"}


@app.get("/datasets", response_model=List[Dataset])
async def get_available_datasets():
    return mock_db_datasets


@app.get("/datasets/{dataset_id}", response_model=Dataset)
async def get_dataset_details(dataset_id: str):
    for ds in mock_db_datasets:
        if ds.id == dataset_id:
            return ds
    raise HTTPException(status_code=404, detail="Dataset not found")


@app.post("/purchase/{dataset_id}")
async def purchase_dataset(dataset_id: str, request: PurchaseRequest):
    dataset = await get_dataset_details(dataset_id)
    print(
        f"TRANSACTION INITIATED: Wallet {request.buyer_wallet} is purchasing "
        f"{request.amount} access token(s) for {dataset.name}"
    )
    return {
        "status": "purchase_initiated",
        "dataset_id": dataset.id,
        "buyer": request.buyer_wallet,
        "tx_hash_placeholder": f"0x{abs(hash(f'{dataset.id}{request.buyer_wallet}')):x}",
    }
