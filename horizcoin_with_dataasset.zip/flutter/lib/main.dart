import 'package:flutter/material.dart';
import 'services/api_service.dart';
import 'models/dataset_model.dart';

void main() {
  runApp(const HorizCoinApp());
}

class HorizCoinApp extends StatelessWidget {
  const HorizCoinApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'HorizCoin Data Marketplace',
      theme: ThemeData.dark().copyWith(
        useMaterial3: true,
        colorScheme: const ColorScheme.dark(
          primary: Colors.tealAccent,
          secondary: Colors.teal,
          surface: Color(0xFF121212),
        ),
        scaffoldBackgroundColor: const Color(0xFF121212),
      ),
      home: const MarketplaceScreen(),
    );
  }
}

class MarketplaceScreen extends StatefulWidget {
  const MarketplaceScreen({super.key});

  @override
  State<MarketplaceScreen> createState() => _MarketplaceScreenState();
}

class _MarketplaceScreenState extends State<MarketplaceScreen> {
  late Future<List<Dataset>> futureDatasets;
  final ApiService apiService = ApiService();

  @override
  void initState() {
    super.initState();
    futureDatasets = apiService.fetchDatasets();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Live Data Marketplace"),
        backgroundColor: Colors.tealAccent.withOpacity(0.1),
        elevation: 0,
      ),
      body: Center(
        child: FutureBuilder<List<Dataset>>(
          future: futureDatasets,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const CircularProgressIndicator();
            } else if (snapshot.hasError) {
                return Text('Failed to load data: ${snapshot.error}');
            } else if (snapshot.hasData && snapshot.data!.isNotEmpty) {
              return ListView.builder(
                itemCount: snapshot.data!.length,
                itemBuilder: (context, index) {
                  final dataset = snapshot.data![index];
                  return Card(
                    color: const Color(0xFF1E1E1E),
                    margin:
                        const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    child: ListTile(
                      leading: CircleAvatar(
                        backgroundColor: Colors.tealAccent.withOpacity(0.2),
                        child: Text(
                          dataset.ddvoScore.toString(),
                          style: const TextStyle(color: Colors.tealAccent),
                        ),
                      ),
                      title: Text(dataset.name,
                          style: const TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 16)),
                      subtitle: Text(
                        dataset.description,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      trailing: Text(
                        "\${dataset.priceHZC.toStringAsFixed(0)} HZC",
                        style: const TextStyle(
                            color: Colors.tealAccent,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                  );
                },
              );
            } else {
              return const Text('No datasets found.');
            }
          },
        ),
      ),
    );
  }
}
